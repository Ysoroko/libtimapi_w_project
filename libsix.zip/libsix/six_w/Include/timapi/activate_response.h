/**
 * \file
 * \brief Activate Response.
 * \details Object type \em activate_response.
 */

#ifndef TA_ACTIVATE_RESPONSE_H
#define TA_ACTIVATE_RESPONSE_H

#include "common/object.h"
#include "common/boolean.h"


#ifdef __cplusplus
extern "C" {
#endif


/**
 * \brief Print information for merchant receipt.
 * 
 * \param[in] response Object instance of type [activate_response](\ref activate_response.h).
 * \param[out] print_data Pointer to variable to write object instance to. Object instance
 *                        is of type [print_data](\ref print_data.h) and is not retained. Object instance
 *                        is \em ta_object_invalid if value is not set in \em response.
 * 
 * \retval ta_c_rc_ok Object instance written to \em print_data.
 * \retval ta_c_rc_invalid_argument \em response is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em response is not of type [activate_response](\ref activate_response.h).
 * \retval ta_c_rc_invalid_argument \em print_data is \em null-pointer.
 */
extern ta_e_result_code_t ta_activate_response_get_print_data(
	ta_object_t response,
	ta_object_t *print_data );

/**
 * \brief Activation sequence counter.
 * 
 * \param[in] response Object instance of type [activate_response](\ref activate_response.h).
 * \param[out] acq_seq_counter Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Value written to \em acq_seq_counter.
 * \retval ta_c_rc_invalid_argument \em response is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em response is not of type [activate_response](\ref activate_response.h).
 * \retval ta_c_rc_invalid_argument \em acq_seq_counter is \em null-pointer.
 */
extern ta_e_result_code_t ta_activate_response_get_act_seq_counter(
	ta_object_t response,
	int *acq_seq_counter );


#ifdef __cplusplus
}
#endif

#endif
