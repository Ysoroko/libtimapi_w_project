/**
 * \file
 * \brief Amount.
 * \details Object type \em amount.
 */

#ifndef TA_AMOUNT_H
#define TA_AMOUNT_H

#include <stdint.h>

#include "common/object.h"
#include "constants/currency.h"


#ifdef __cplusplus
extern "C" {
#endif


/**
 * \brief Create object of type [amount](\ref amount.h).
 * 
 * \param[out] amount Pointer to variable to write created object instance to.
 *                    Created object instance is retained.
 * \param[in] value Value of amount in minor units. The currency selected by \em currency
 *                  defines the used exponent. For example with \em ta_c_currency_chf the
 *                  exponent is 2. To create an amount equal to 1 CHF use a value of 100.
 * \param[in] currency Currency of amount.
 * 
 * \retval ta_c_rc_ok Object instance has been created and written to \em amount.
 * \retval ta_c_rc_invalid_argument \em amount is \em null-pointer.
 * \retval ta_c_rc_invalid_argument \em currency is not a valid value from \em ta_e_currency_t.
 * \retval ta_c_rc_invalid_argument \em value is less than 0.
 * \retval ta_c_rc_out_of_memory Failed allocating memory.
 */
extern ta_e_result_code_t ta_amount_create(
	ta_object_t *amount,
	int64_t value,
	ta_e_currency_t currency );

/**
 * \brief Create object of type [amount](\ref amount.h) using double precision floating point value.
 * 
 * \note Double precision floating point values can not provide the same level of numerical
 *       accuracy as int64_t. It is recommended to use the integer based methods.
 * 
 * \param[out] amount Pointer to variable to write created object instance to.
 *                    Created object instance is retained.
 * \param[in] value Value of amount in major units. The currency selected by \em currency
 *                  defines the used exponent. For example with \em ta_c_currency_chf the
 *                  exponent is 2. Values with more than 2 digits after the period will be
 *                  rounded according to regular mathematical rounding rules.
 * \param[in] currency Currency of amount.
 * 
 * \retval ta_c_rc_ok Object instance has been created and written to \em amount.
 * \retval ta_c_rc_invalid_argument \em amount is \em null-pointer.
 * \retval ta_c_rc_invalid_argument \em currency is not a valid value from \em ta_e_currency_t.
 * \retval ta_c_rc_invalid_argument \em value is less than 0.
 * \retval ta_c_rc_out_of_memory Failed allocating memory.
 */
extern ta_e_result_code_t ta_amount_create_decimal(
	ta_object_t *amount,
	double value,
	ta_e_currency_t currency );

/**
 * \brief Create object of type [amount](\ref amount.h) using custom exponent.
 * 
 * \param[out] amount Pointer to variable to write created object instance to.
 *                    Created object instance is retained.
 * \param[in] value Value of amount in minor units. The value of \em exponent overrides the
 *                  exponent defined by the currency selected by \em currency. For example
 *                  with an exponent of 3 to create an amount equal to 1 CHF use a value of 1000.
 * \param[in] currency Currency of amount.
 * \param[in] exponent Exponent to use instead of the exponent defined by the currency.
 * 
 * \retval ta_c_rc_ok Object instance has been created and written to \em amount.
 * \retval ta_c_rc_invalid_argument \em amount is \em null-pointer.
 * \retval ta_c_rc_invalid_argument \em currency is not a valid value from \em ta_e_currency_t.
 * \retval ta_c_rc_invalid_argument \em value is less than 0.
 * \retval ta_c_rc_invalid_argument \em exponent is less than 0.
 * \retval ta_c_rc_out_of_memory Failed allocating memory.
 */
extern ta_e_result_code_t ta_amount_create_exponent(
	ta_object_t *amount,
	int64_t value,
	ta_e_currency_t currency,
	int exponent );

/**
 * \brief Create object of type [amount](\ref amount.h) using custom exponent and double precision value.
 * 
 * \note Double precision floating point values can not provide the same level of numerical
 *       accuracy as int64_t. It is recommended to use the integer based methods.
 * 
 * \param[out] amount Pointer to variable to write created object instance to.
 *                    Created object instance is retained.
 * \param[in] value Value of amount in minor units. The value of \em exponent overrides the
 *                  exponent defined by the currency selected by \em currency. For example
 *                  with an exponent of 3 values with more than 3 digits after the period will
 *                  be rounded according to regular mathematical rounding rules.
 * \param[in] currency Currency of amount.
 * \param[in] exponent Exponent to use instead of the exponent defined by the currency.
 * 
 * \retval ta_c_rc_ok Object instance has been created and written to \em amount.
 * \retval ta_c_rc_invalid_argument \em amount is \em null-pointer.
 * \retval ta_c_rc_invalid_argument \em currency is not a valid value from \em ta_e_currency_t.
 * \retval ta_c_rc_invalid_argument \em value is less than 0.
 * \retval ta_c_rc_invalid_argument \em exponent is less than 0.
 * \retval ta_c_rc_out_of_memory Failed allocating memory.
 */
extern ta_e_result_code_t ta_amount_create_decimal_exponent(
	ta_object_t *amount,
	double value,
	ta_e_currency_t currency,
	int exponent );



/**
 * \brief Amount in minor units.
 * 
 * \param[in] amount Object instance of type [amount](\ref amount.h).
 * \param[out] value Pointer to variable to write value to. Use \em ta_amount_get_exponent
 *                   to get the used exponent. This can be a different exponent than the
 *                   one defined by the used currency.
 * 
 * \retval ta_c_rc_ok Value written to \em value.
 * \retval ta_c_rc_invalid_argument \em amount is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em amount is not of type [amount](\ref amount.h).
 * \retval ta_c_rc_invalid_argument \em value is \em null-pointer.
 */
extern ta_e_result_code_t ta_amount_get_value(
	ta_object_t amount,
	int64_t *value );

/**
 * \brief Set amount in minor units.
 * 
 * \param[in] amount Object instance of type [amount](\ref amount.h).
 * \param[in] value Value to set. Use \em ta_amount_get_exponent to get the used exponent.
 *                  This can be a different exponent than the one defined by the used currency.
 *                  For example with an exponent of 2 to set an amount equal to 1 CHF you
 *                  have to use a value of 100.
 * 
 * \retval ta_c_rc_ok Value assigned to \em amount.
 * \retval ta_c_rc_invalid_argument \em amount is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em amount is not of type [amount](\ref amount.h).
 * \retval ta_c_rc_invalid_argument \em value is less than 0.
 */
extern ta_e_result_code_t ta_amount_set_value(
	ta_object_t amount,
	int64_t value );



/**
 * \brief Amount in major units as double precision floating point value.
 * 
 * \note Double precision floating point values can not provide the same level of numerical
 *       accuracy as int64_t. It is recommended to use the integer based methods.
 * 
 * \param[in] amount Object instance of type [amount](\ref amount.h).
 * \param[out] value Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Value written to \em value.
 * \retval ta_c_rc_invalid_argument \em amount is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em amount is not of type [amount](\ref amount.h).
 * \retval ta_c_rc_invalid_argument \em value is \em null-pointer.
 */
extern ta_e_result_code_t ta_amount_get_decimal_value(
	ta_object_t amount,
	double *value );

/**
 * \brief Set amount in major units as double precision floating point value.
 * 
 * \note Double precision floating point values can not provide the same level of numerical
 *       accuracy as int64_t. It is recommended to use the integer based methods.
 * 
 * \param[in] amount Object instance of type [amount](\ref amount.h).
 * \param[in] value Value to set. Use \em ta_amount_get_exponent to get the used exponent. For
 *                  example with an exponent of 2 values with more than 2 digits after the
 *                  period will be rounded according to regular mathematical rounding rules.
 * 
 * \retval ta_c_rc_ok Value written to \em value.
 * \retval ta_c_rc_invalid_argument \em amount is 0 pointer.
 * \retval ta_c_rc_out_of_memory Memory allocation required but failed.
 */
extern ta_e_result_code_t ta_amount_set_decimal_value(
	ta_object_t amount,
	double value );



/**
 * \brief Currency.
 * 
 * \param[in] amount Object instance of type [amount](\ref amount.h).
 * \param[out] currency Pointer to variable to write currency to.
 * 
 * \retval ta_c_rc_ok Value written to \em currency.
 * \retval ta_c_rc_invalid_argument \em amount is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em amount is not of type [amount](\ref amount.h).
 * \retval ta_c_rc_invalid_argument \em currency is \em null-pointer.
 */
extern ta_e_result_code_t ta_amount_get_currency(
	ta_object_t amount,
	ta_e_currency_t *currency );

/**
 * \brief Set currency.
 * 
 * \param[in] amount Object instance of type [amount](\ref amount.h).
 * \param[in] currency Currency to set.
 * 
 * \retval ta_c_rc_ok Value assigned to \em amount.
 * \retval ta_c_rc_invalid_argument \em amount is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em amount is not of type [amount](\ref amount.h).
 * \retval ta_c_rc_invalid_argument \em currency is not a valid value from \em ta_e_currency_t.
 */
extern ta_e_result_code_t ta_amount_set_currency(
	ta_object_t amount,
	ta_e_currency_t currency );



/**
 * \brief Exponent.
 * 
 * \param[in] amount Object instance of type [amount](\ref amount.h).
 * \param[out] exponent Pointer to variable to write exponent to.
 * 
 * \retval ta_c_rc_ok Value written to \em exponent.
 * \retval ta_c_rc_invalid_argument \em amount is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em amount is not of type [amount](\ref amount.h).
 * \retval ta_c_rc_invalid_argument \em exponent is \em null-pointer.
 */
extern ta_e_result_code_t ta_amount_get_exponent(
	ta_object_t amount,
	int *exponent );

/**
 * \brief Set exponent.
 * 
 * \param[in] amount Object instance of type [amount](\ref amount.h).
 * \param[in] exponent Exponent to set.
 * 
 * \retval ta_c_rc_ok Value assigned to \em amount.
 * \retval ta_c_rc_invalid_argument \em amount is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em amount is not of type [amount](\ref amount.h).
 * \retval ta_c_rc_invalid_argument \em exponent is less than 0.
 */
extern ta_e_result_code_t ta_amount_set_exponent(
	ta_object_t amount,
	int exponent );


#ifdef __cplusplus
}
#endif

#endif
