/**
 * \file
 * \brief DCC Amount.
 * \details Object type \em amount_dcc.
 */

#ifndef TA_AMOUNT_DCC_H
#define TA_AMOUNT_DCC_H

#include <stdint.h>

#include "common/object.h"
#include "constants/currency.h"


#ifdef __cplusplus
extern "C" {
#endif


/**
 * \brief DCC Amount in minor units.
 * 
 * \param[in] amount Object instance of type [amount_dcc](\ref amount_dcc.h).
 * \param[out] value Pointer to variable to write value to. Use \em ta_amount_dcc_get_exponent
 *                   to get the used exponent. This can be a different exponent than the
 *                   one defined by the used currency.
 * 
 * \retval ta_c_rc_ok Value written to \em value.
 * \retval ta_c_rc_invalid_argument \em amount is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em amount is not of type [amount_dcc](\ref amount_dcc.h).
 * \retval ta_c_rc_invalid_argument \em value is \em null-pointer.
 */
extern ta_e_result_code_t ta_amount_dcc_get_value(
	ta_object_t amount,
	int64_t *value );

/**
 * \brief DCC Amount in major units as double precision floating point value.
 * 
 * \note Double precision floating point values can not provide the same level of numerical
 *       accuracy as int64_t. It is recommended to use the integer based methods.
 * 
 * \param[in] amount Object instance of type [amount_dcc](\ref amount_dcc.h).
 * \param[out] value Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Value written to \em value.
 * \retval ta_c_rc_invalid_argument \em amount is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em amount is not of type [amount_dcc](\ref amount_dcc.h).
 * \retval ta_c_rc_invalid_argument \em value is \em null-pointer.
 */
extern ta_e_result_code_t ta_amount_dcc_get_decimal_value(
	ta_object_t amount,
	double *value );

/**
 * \brief DCC Currency.
 * 
 * \param[in] amount Object instance of type [amount_dcc](\ref amount_dcc.h).
 * \param[out] currency Pointer to variable to write currency to.
 * 
 * \retval ta_c_rc_ok Value written to \em currency.
 * \retval ta_c_rc_invalid_argument \em amount is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em amount is not of type [amount_dcc](\ref amount_dcc.h).
 * \retval ta_c_rc_invalid_argument \em currency is \em null-pointer.
 */
extern ta_e_result_code_t ta_amount_dcc_get_currency(
	ta_object_t amount,
	ta_e_currency_t *currency );

/**
 * \brief DCC Exponent.
 * 
 * \param[in] amount Object instance of type [amount_dcc](\ref amount_dcc.h).
 * \param[out] exponent Pointer to variable to write exponent to.
 * 
 * \retval ta_c_rc_ok Value written to \em exponent.
 * \retval ta_c_rc_invalid_argument \em amount is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em amount is not of type [amount_dcc](\ref amount_dcc.h).
 * \retval ta_c_rc_invalid_argument \em exponent is \em null-pointer.
 */
extern ta_e_result_code_t ta_amount_dcc_get_exponent(
	ta_object_t amount,
	int *exponent );

/**
 * \brief DCC Rate in minor units.
 * 
 * \param[in] amount Object instance of type [amount_dcc](\ref amount_dcc.h).
 * \param[out] rate Pointer to variable to write rate to.
 * 
 * \retval ta_c_rc_ok Value written to \em rate.
 * \retval ta_c_rc_invalid_argument \em amount is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em amount is not of type [amount_dcc](\ref amount_dcc.h).
 * \retval ta_c_rc_invalid_argument \em rate is \em null-pointer.
 */
extern ta_e_result_code_t ta_amount_dcc_get_rate(
	ta_object_t amount,
	int *rate );

/**
 * \brief DCC rate exponent.
 * 
 * \param[in] amount Object instance of type [amount_dcc](\ref amount_dcc.h).
 * \param[out] exponent Pointer to variable to write rate exponent to.
 * 
 * \retval ta_c_rc_ok Value written to \em exponent.
 * \retval ta_c_rc_invalid_argument \em amount is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em amount is not of type [amount_dcc](\ref amount_dcc.h).
 * \retval ta_c_rc_invalid_argument \em exponent is \em null-pointer.
 */
extern ta_e_result_code_t ta_amount_dcc_get_rate_exponent(
	ta_object_t amount,
	int *exponent );

/**
 * \brief DCC Rate in major units as double precision floating point value.
 * 
 * DCC rate exponent has been applied already to the value. Returned value can be used
 * as-is without the need to adjust for the exponent.
 * 
 * \note Double precision floating point values can not provide the same level of numerical
 *       accuracy as int64_t. It is recommended to use the integer based methods.
 * 
 * \param[in] amount Object instance of type [amount_dcc](\ref amount_dcc.h).
 * \param[out] rate Pointer to variable to write rate to.
 * 
 * \retval ta_c_rc_ok Value written to \em rate.
 * \retval ta_c_rc_invalid_argument \em amount is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em amount is not of type [amount_dcc](\ref amount_dcc.h).
 * \retval ta_c_rc_invalid_argument \em rate is \em null-pointer.
 */
extern ta_e_result_code_t ta_amount_dcc_get_rate_decimal(
	ta_object_t amount,
	double *rate );

/**
 * \brief DCC Markup in minor units.
 * 
 * \param[in] amount Object instance of type [amount_dcc](\ref amount_dcc.h).
 * \param[out] markup Pointer to variable to write markup to.
 * 
 * \retval ta_c_rc_ok Value written to \em markup.
 * \retval ta_c_rc_invalid_argument \em amount is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em amount is not of type [amount_dcc](\ref amount_dcc.h).
 * \retval ta_c_rc_invalid_argument \em markup is \em null-pointer.
 */
extern ta_e_result_code_t ta_amount_dcc_get_markup(
	ta_object_t amount,
	int *markup );

/**
 * \brief DCC Markup exponent.
 * 
 * \param[in] amount Object instance of type [amount_dcc](\ref amount_dcc.h).
 * \param[out] exponent Pointer to variable to write markup exponent to.
 * 
 * \retval ta_c_rc_ok Value written to \em exponent.
 * \retval ta_c_rc_invalid_argument \em amount is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em amount is not of type [amount_dcc](\ref amount_dcc.h).
 * \retval ta_c_rc_invalid_argument \em exponent is \em null-pointer.
 */
extern ta_e_result_code_t ta_amount_dcc_get_markup_exponent(
	ta_object_t amount,
	int *exponent );

/**
 * \brief DCC Markup in major units as double precision floating point value.
 * 
 * DCC markup exponent has been applied already to the value. Returned value can be used
 * as-is without the need to adjust for the exponent.
 * 
 * \note Double precision floating point values can not provide the same level of numerical
 *       accuracy as int64_t. It is recommended to use the integer based methods.
 * 
 * \param[in] amount Object instance of type [amount_dcc](\ref amount_dcc.h).
 * \param[out] markup Pointer to variable to write markup to.
 * 
 * \retval ta_c_rc_ok Value written to \em markup.
 * \retval ta_c_rc_invalid_argument \em amount is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em amount is not of type [amount_dcc](\ref amount_dcc.h).
 * \retval ta_c_rc_invalid_argument \em markup is \em null-pointer.
 */
extern ta_e_result_code_t ta_amount_dcc_get_markup_decimal(
	ta_object_t amount,
	double *markup );

/**
 * \brief DCC Rate in minor units.
 * 
 * \param[in] amount Object instance of type [amount_dcc](\ref amount_dcc.h).
 * \param[out] rate Pointer to variable to write rate to.
 * 
 * \retval ta_c_rc_ok Value written to \em rate.
 * \retval ta_c_rc_invalid_argument \em amount is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em amount is not of type [amount_dcc](\ref amount_dcc.h).
 * \retval ta_c_rc_invalid_argument \em rate is \em null-pointer.
 */
extern ta_e_result_code_t ta_amount_dcc_get_rate_regulated(
	ta_object_t amount,
	int *rate );

/**
 * \brief DCC rate exponent.
 * 
 * \param[in] amount Object instance of type [amount_dcc](\ref amount_dcc.h).
 * \param[out] exponent Pointer to variable to write rate exponent to.
 * 
 * \retval ta_c_rc_ok Value written to \em exponent.
 * \retval ta_c_rc_invalid_argument \em amount is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em amount is not of type [amount_dcc](\ref amount_dcc.h).
 * \retval ta_c_rc_invalid_argument \em exponent is \em null-pointer.
 */
extern ta_e_result_code_t ta_amount_dcc_get_rate_exponent_regulated(
	ta_object_t amount,
	int *exponent );

/**
 * \brief DCC Rate in major units as double precision floating point value.
 * 
 * DCC rate exponent has been applied already to the value. Returned value can be used
 * as-is without the need to adjust for the exponent.
 * 
 * \note Double precision floating point values can not provide the same level of numerical
 *       accuracy as int64_t. It is recommended to use the integer based methods.
 * 
 * \param[in] amount Object instance of type [amount_dcc](\ref amount_dcc.h).
 * \param[out] rate Pointer to variable to write rate to.
 * 
 * \retval ta_c_rc_ok Value written to \em rate.
 * \retval ta_c_rc_invalid_argument \em amount is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em amount is not of type [amount_dcc](\ref amount_dcc.h).
 * \retval ta_c_rc_invalid_argument \em rate is \em null-pointer.
 */
extern ta_e_result_code_t ta_amount_dcc_get_rate_decimal_regulated(
	ta_object_t amount,
	double *rate );

/**
 * \brief DCC Markup in minor units.
 * 
 * \param[in] amount Object instance of type [amount_dcc](\ref amount_dcc.h).
 * \param[out] markup Pointer to variable to write markup to.
 * 
 * \retval ta_c_rc_ok Value written to \em markup.
 * \retval ta_c_rc_invalid_argument \em amount is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em amount is not of type [amount_dcc](\ref amount_dcc.h).
 * \retval ta_c_rc_invalid_argument \em markup is \em null-pointer.
 */
extern ta_e_result_code_t ta_amount_dcc_get_markup_regulated(
	ta_object_t amount,
	int *markup );

/**
 * \brief DCC Markup exponent.
 * 
 * \param[in] amount Object instance of type [amount_dcc](\ref amount_dcc.h).
 * \param[out] exponent Pointer to variable to write markup exponent to.
 * 
 * \retval ta_c_rc_ok Value written to \em exponent.
 * \retval ta_c_rc_invalid_argument \em amount is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em amount is not of type [amount_dcc](\ref amount_dcc.h).
 * \retval ta_c_rc_invalid_argument \em exponent is \em null-pointer.
 */
extern ta_e_result_code_t ta_amount_dcc_get_markup_exponent_regulated(
	ta_object_t amount,
	int *exponent );

/**
 * \brief DCC Markup in major units as double precision floating point value.
 * 
 * DCC markup exponent has been applied already to the value. Returned value can be used
 * as-is without the need to adjust for the exponent.
 * 
 * \note Double precision floating point values can not provide the same level of numerical
 *       accuracy as int64_t. It is recommended to use the integer based methods.
 * 
 * \param[in] amount Object instance of type [amount_dcc](\ref amount_dcc.h).
 * \param[out] markup Pointer to variable to write markup to.
 * 
 * \retval ta_c_rc_ok Value written to \em markup.
 * \retval ta_c_rc_invalid_argument \em amount is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em amount is not of type [amount_dcc](\ref amount_dcc.h).
 * \retval ta_c_rc_invalid_argument \em markup is \em null-pointer.
 */
extern ta_e_result_code_t ta_amount_dcc_get_markup_decimal_regulated(
	ta_object_t amount,
	double *markup );

#ifdef __cplusplus
}
#endif

#endif

