/**
 * \file
 * \brief Information about a supported application.
 * \details Object type \em application.
 */

#ifndef TA_APPLICATION_H
#define TA_APPLICATION_H

#include "common/object.h"
#include "common/boolean.h"


#ifdef __cplusplus
extern "C" {
#endif

	
/**
 * \brief Acquirer identifier. Uniquely identifies the acquirer.
 * 
 * \param[in] application Object instance of type [application](\ref application.h).
 * \param[out] aid Pointer to variable to write object instance to. Object instance
 *                 is of type [string](\ref string.h) and is not retained. Object instance is
 *                 \em ta_object_invalid if value is not set in \em application.
 * 
 * \retval ta_c_rc_ok Object instance written to \em aid.
 * \retval ta_c_rc_invalid_argument \em application is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em application is not of type [application](\ref application.h).
 * \retval ta_c_rc_invalid_argument \em aid is \em ta_object_invalid.
 */
extern ta_e_result_code_t ta_application_get_aid(
	ta_object_t application,
	ta_object_t *aid );

/**
 * \brief Contains the application label of the currently used application.
 * 
 * \param[in] application Object instance of type [application](\ref application.h).
 * \param[out] label Pointer to variable to write object instance to. Object instance
 *                   is of type [string](\ref string.h) and is not retained. Object instance is
 *                   \em ta_object_invalid if value is not set in \em application.
 * 
 * \retval ta_c_rc_ok Object instance written to \em label.
 * \retval ta_c_rc_invalid_argument \em application is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em application is not of type [application](\ref application.h).
 * \retval ta_c_rc_invalid_argument \em label is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em label is not of type [integer](\ref integer.h).
 */
extern ta_e_result_code_t ta_application_get_label(
	ta_object_t application,
	ta_object_t *label );

#ifdef __cplusplus
}
#endif

#endif
