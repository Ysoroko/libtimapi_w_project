/**
 * \file
 * \brief Basket.
 * \details Object type \em basket.
 */

#ifndef TA_BASKET_H
#define TA_BASKET_H

#include "common/object.h"
#include "common/boolean.h"


#ifdef __cplusplus
extern "C" {
#endif


/**
 * \brief Create object of type [basket](\ref basket.h).
 * 
 * \param[out] basket Pointer to variable to write created object instance to.
 *                    Created object instance is retained.
 * 
 * \retval ta_c_rc_ok Object instance has been created and written to \em basket.
 * \retval ta_c_rc_invalid_argument \em basket is \em null-pointer.
 * \retval ta_c_rc_out_of_memory Failed allocating memory.
 */
extern ta_e_result_code_t ta_basket_create(
	ta_object_t *basket );

/**
 * \brief Create deep copy of object instance of type [basket](\ref basket.h).
 * 
 * \param[out] basket Pointer to variable to write created object instance to.
 *                    Created object instance is retained.
 * \param[in] source_basket Object of type [basket](\ref basket.h) to create copy of.
 * 
 * \retval ta_c_rc_ok Object instance has been created and written to \em basket.
 * \retval ta_c_rc_invalid_argument \em basket is \em null-pointer.
 * \retval ta_c_rc_invalid_argument \em source_basket is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em source_basket is not of type [basket](\ref basket.h).
 * \retval ta_c_rc_out_of_memory Failed allocating memory.
 */
extern ta_e_result_code_t ta_basket_copy(
	ta_object_t* basket,
	const ta_object_t* source_basket );


/**
 * \brief Get list of basket items.
 * 
 * \param[in] basket Object instance of type [basket](\ref basket.h).
 * \param[out] items Pointer to variable to write object instance to. Object instance
 *                   is of type [list](\ref list.h) and is not retained. The list contains elements
 *                   of type [basket_item](\ref basket_item.h).
 * 
 * \retval ta_c_rc_ok Object instance written to \em items.
 * \retval ta_c_rc_invalid_argument \em basket is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em basket is not of type [basket](\ref basket.h).
 * \retval ta_c_rc_invalid_argument \em items is \em null-pointer.
 */
extern ta_e_result_code_t ta_basket_get_items(
	ta_object_t basket,
	ta_object_t *items );

/**
 * \brief Set list of basket items.
 * 
 * \param[in] basket Object instance of type [basket](\ref basket.h).
 * \param[in] items Object instance to set. Object instance has to be of type [list](\ref list.h).
 *                  The list has to contain elements of type [basket_item](\ref basket_item.h).
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em basket.
 * \retval ta_c_rc_invalid_argument \em basket is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em basket is not of type [basket](\ref basket.h).
 * \retval ta_c_rc_invalid_argument \em items is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em items is not of type [list](\ref list.h).
 * \retval ta_c_rc_invalid_argument Element in \em items is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument Element in \em items is not of type [basket_item](\ref basket_item.h).
 */
extern ta_e_result_code_t ta_basket_set_items(
	ta_object_t basket,
	ta_object_t items );

/**
 * \brief Optional loyalty auth result.
 * 
 * \param[in] basket Object instance of type [basket](\ref basket.h).
 * \param[out] loyalty_auth_result Pointer to variable to write object instance to. Object
 *                                 instance is of type [integer](\ref integer.h) and is not retained. Object
 *                                 instance is \em ta_object_invalid if value is not set
 *                                 in \em basket.
 * 
 * \retval ta_c_rc_ok Object instance written to \em loyalty_auth_result.
 * \retval ta_c_rc_invalid_argument \em basket is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em basket is not of type [basket](\ref basket.h).
 * \retval ta_c_rc_invalid_argument \em loyalty_auth_result is \em null-pointer.
 */
extern ta_e_result_code_t ta_basket_get_loyalty_auth_result(
	ta_object_t basket,
	ta_object_t *loyalty_auth_result );

/**
 * \brief Set optional loyalty auth result.
 * 
 * \param[in] basket Object instance of type [basket](\ref basket.h).
 * \param[in] loyalty_auth_result Object instance to set. Object instance can be
 *                                \em ta_object_invalid to clear the value in \em basket. If
 *                                object instance is not ta_object_invalid is has to be of
 *                                type \em integer.
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em basket.
 * \retval ta_c_rc_invalid_argument \em basket is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em basket is not of type [basket](\ref basket.h).
 * \retval ta_c_rc_invalid_argument \em loyalty_auth_result is not \em ta_object_invalid and
 *                                  is not of type [integer](\ref integer.h).
 */
extern ta_e_result_code_t ta_basket_set_loyalty_auth_result(
	ta_object_t basket,
	ta_object_t loyalty_auth_result );

#ifdef __cplusplus
}
#endif

#endif
