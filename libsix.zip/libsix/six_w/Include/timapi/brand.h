/**
 * \file
 * \brief Contains information about a brand available on the terminal.
 * 
 * Object type \em brand.
 * 
 * It is available after ta_terminal_login() or ta_terminal_login_async has been performed
 * or brands have been manually retrieved by ta_terminal_application_information() or
 * ta_terminal_application_information_async().
 */

#ifndef TA_BRAND_H
#define TA_BRAND_H

#include "common/object.h"
#include "common/boolean.h"
#include "common/integer.h"
#include "common/timedate.h"
#include "constants/payment_protocol.h"


#ifdef __cplusplus
extern "C" {
#endif


/**
 * \brief Brand name of a card.
 * 
 * \param[in] brand Object instance of type [brand](\ref brand.h).
 * \param[out] name Pointer to variable to write object instance to. Object instance is of
 *                  type \em string and is not retained.
 * 
 * \retval ta_c_rc_ok Object instance written to \em name.
 * \retval ta_c_rc_invalid_argument \em brand is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em brand is not of type [brand](\ref brand.h).
 * \retval ta_c_rc_invalid_argument \em name is \em null-pointer.
 */
extern ta_e_result_code_t ta_brand_get_name(
	ta_object_t brand,
	ta_object_t* name );

/**
 * \brief DCC is available for this brand.
 * 
 * \param[in] brand Object instance of type [brand](\ref brand.h).
 * \param[out] dcc_available Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Object instance written to \em dcc_available.
 * \retval ta_c_rc_invalid_argument \em brand is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em brand is not of type [brand](\ref brand.h).
 * \retval ta_c_rc_invalid_argument \em dcc_available is \em null-pointer.
 */
extern ta_e_result_code_t ta_brand_get_dcc_available(
	ta_object_t brand,
	ta_e_boolean_t* dcc_available );

/**
 * \brief Payment protocol used.
 * 
 * \param[in] brand Object instance of type [brand](\ref brand.h).
 * \param[out] payment_protocol Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Object instance written to \em payment_protocol.
 * \retval ta_c_rc_invalid_argument \em brand is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em brand is not of type [brand](\ref brand.h).
 * \retval ta_c_rc_invalid_argument \em payment_protocol is \em null-pointer.
 */
extern ta_e_result_code_t ta_brand_get_payment_protocol(
	ta_object_t brand,
	ta_e_payment_protocol_t* payment_protocol );

/**
 * \brief Acquirer identifier. Uniquely identifies the acquirer.
 * 
 * \param[in] brand Object instance of type [brand](\ref brand.h).
 * \param[out] acq_id Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Object instance written to \em acq_id.
 * \retval ta_c_rc_invalid_argument \em brand is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em brand is not of type [brand](\ref brand.h).
 * \retval ta_c_rc_invalid_argument \em acq_id is \em null-pointer.
 */
extern ta_e_result_code_t ta_brand_get_acq_id(
	ta_object_t brand,
	int64_t* acq_id );

/**
 * \brief Last time a defined acquirer was successfully initialized on the terminal.
 * 
 * \param[in] brand Object instance of type [brand](\ref brand.h).
 * \param[out] last_init_date Pointer to variable to write object instance to. Object
 *                            instance is of type [timedate](\ref timedate.h) and is not retained.
 * 
 * \retval ta_c_rc_ok Object instance written to \em last_init_date.
 * \retval ta_c_rc_invalid_argument \em brand is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em brand is not of type [brand](\ref brand.h).
 * \retval ta_c_rc_invalid_argument \em last_init_date is \em null-pointer.
 */
extern ta_e_result_code_t ta_brand_get_last_init_date(
	ta_object_t brand,
	ta_object_t* last_init_date );

/**
 * \brief List of applications supported by the brand.
 * 
 * \param[in] brand Object instance of type [brand](\ref brand.h).
 * \param[out] applications Pointer to variable to write object instance to. Object instance
 *                          is of type [list](\ref list.h) and is not retained. The list contains elements
 *                          of type [application](\ref application.h).
 * 
 * \retval ta_c_rc_ok Object instance written to \em applications.
 * \retval ta_c_rc_invalid_argument \em brand is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em brand is not of type [brand](\ref brand.h).
 * \retval ta_c_rc_invalid_argument \em applications is \em null-pointer.
 */
extern ta_e_result_code_t ta_brand_get_applications(
	ta_object_t brand,
	ta_object_t* applications );

/**
 * \brief List of currencies supported by the brand.
 * 
 * \param[in] brand Object instance of type [brand](\ref brand.h).
 * \param[out] currencies Pointer to variable to write object instance to. Object instance
 *                        is of type [list](\ref list.h) and is not retained. The list contains elements
 *                        of type [currency_item](\ref currency_item.h).
 * 
 * \retval ta_c_rc_ok Object instance written to \em currencies.
 * \retval ta_c_rc_invalid_argument \em brand is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em brand is not of type [brand](\ref brand.h).
 * \retval ta_c_rc_invalid_argument \em currencies is \em null-pointer.
 */
extern ta_e_result_code_t ta_brand_get_currencies(
	ta_object_t brand,
	ta_object_t* currencies );


#ifdef __cplusplus
}
#endif

#endif
