/**
 * \file
 * \brief Card data.
 * \details Object type \em card_data.
 */

#ifndef TA_CARD_DATA_H
#define TA_CARD_DATA_H

#include "common/object.h"
#include "constants/account_type.h"
#include "constants/pos_entry_mode.h"
#include "constants/processing_disposition.h"
#include "constants/card_product_type.h"
#include "constants/token_pan_type.h"


#ifdef __cplusplus
extern "C" {
#endif


/**
 * \brief POS entry mode.
 * 
 * \param[in] card_data Object instance of type [card_data](\ref card_data.h).
 * \param[out] pos_entry_mode Pointer to variable to write value to. Value is
 *                            \em ta_c_pem_undefined if value is not set in \em card_data.
 * 
 * \retval ta_c_rc_ok Object instance written to \em pos_entry_mode.
 * \retval ta_c_rc_invalid_argument \em card_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em card_data is not of type [card_data](\ref card_data.h).
 * \retval ta_c_rc_invalid_argument \em pos_entry_mode is \em null-pointer.
 */
extern ta_e_result_code_t ta_card_data_get_pos_entry_mode(
	ta_object_t card_data,
	ta_e_pos_entry_mode_t *pos_entry_mode );

/**
 * \brief Application identifier.
 * 
 * \param[in] card_data Object instance of type [card_data](\ref card_data.h).
 * \param[out] aid Pointer to variable to write object instance to. Object instance is of
 *                 type \em string and is not retained. Object instance is
 *                 \em ta_object_invalid if value is not set in \em card_data.
 * 
 * \retval ta_c_rc_ok Object instance written to \em aid.
 * \retval ta_c_rc_invalid_argument \em card_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em card_data is not of type [card_data](\ref card_data.h).
 * \retval ta_c_rc_invalid_argument \em aid is \em null-pointer.
 */
extern ta_e_result_code_t ta_card_data_get_aid(
	ta_object_t card_data,
	ta_object_t *aid );

/**
 * \brief Application currency code.
 * 
 * \param[in] card_data Object instance of type [card_data](\ref card_data.h).
 * \param[out] acc Pointer to variable to write object instance to. Object instance is of
 *                 type \em string and is not retained. Object instance is
 *                 \em ta_object_invalid if value is not set in \em card_data.
 * 
 * \retval ta_c_rc_ok Object instance written to \em acc.
 * \retval ta_c_rc_invalid_argument \em card_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em card_data is not of type [card_data](\ref card_data.h).
 * \retval ta_c_rc_invalid_argument \em acc is \em null-pointer.
 */
extern ta_e_result_code_t ta_card_data_get_acc(
	ta_object_t card_data,
	ta_object_t *acc );

/**
 * \brief Card number.
 * 
 * Only for Non-PCI applications and if available to the terminal.
 * 
 * \param[in] card_data Object instance of type [card_data](\ref card_data.h).
 * \param[out] card_number Pointer to variable to write object instance to. Object instance
 *                         is of type [string](\ref string.h) and is not retained. Object instance is
 *                         \em ta_object_invalid if value is not set in \em card_data.
 * 
 * \retval ta_c_rc_ok Object instance written to \em card_number.
 * \retval ta_c_rc_invalid_argument \em card_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em card_data is not of type [card_data](\ref card_data.h).
 * \retval ta_c_rc_invalid_argument \em card_number is \em null-pointer.
 */
extern ta_e_result_code_t ta_card_data_get_card_number(
	ta_object_t card_data,
	ta_object_t *card_number );

/**
 * \brief Card number that should be printed on a merchant receipt.
 * 
 * \param[in] card_data Object instance of type [card_data](\ref card_data.h).
 * \param[out] card_number_printable Pointer to variable to write object instance to. Object
 *                                   instance is of type [string](\ref string.h) and is not retained. Object
 *                                   instance is \em ta_object_invalid if value is not set
 *                                   in \em card_data.
 * 
 * \retval ta_c_rc_ok Object instance written to \em card_number_printable.
 * \retval ta_c_rc_invalid_argument \em card_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em card_data is not of type [card_data](\ref card_data.h).
 * \retval ta_c_rc_invalid_argument \em card_number_printable is \em null-pointer.
 */
extern ta_e_result_code_t ta_card_data_get_card_number_printable(
	ta_object_t card_data,
	ta_object_t *card_number_printable );

/**
 * \brief Card number that should be printed on a cardholder receipt.
 * 
 * \param[in] card_data Object instance of type [card_data](\ref card_data.h).
 * \param[out] card_number_printable_cardholder Pointer to variable to write object instance to.
 *                                              Object instance is of type [string](\ref string.h) and is not
 *                                              retained. Object instance is \em ta_object_invalid
 *                                              if value is not set in \em card_data.
 * 
 * \retval ta_c_rc_ok Object instance written to \em card_number_printable_cardholder.
 * \retval ta_c_rc_invalid_argument \em card_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em card_data is not of type [card_data](\ref card_data.h).
 * \retval ta_c_rc_invalid_argument \em card_number_printable_cardholder is \em null-pointer.
 */
extern ta_e_result_code_t ta_card_data_get_card_number_printable_cardholder(
	ta_object_t card_data,
	ta_object_t *card_number_printable_cardholder );

/**
 * \brief Encrypted card number.
 * 
 * \param[in] card_data Object instance of type [card_data](\ref card_data.h).
 * \param[out] card_number_enc Pointer to variable to write object instance to. Object instance
 *                             is of type [string](\ref string.h) and is not retained. Object instance is
 *                             \em ta_object_invalid if value is not set in \em card_data.
 * 
 * \retval ta_c_rc_ok Object instance written to \em card_number_enc.
 * \retval ta_c_rc_invalid_argument \em card_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em card_data is not of type [card_data](\ref card_data.h).
 * \retval ta_c_rc_invalid_argument \em card_number_enc is \em null-pointer.
 */
extern ta_e_result_code_t ta_card_data_get_card_number_enc(
	ta_object_t card_data,
	ta_object_t *card_number_enc );

/**
 * \brief Card number encryption key index.
 * 
 * \param[in] card_data Object instance of type [card_data](\ref card_data.h).
 * \param[out] card_number_enc_key_index Pointer to variable to write value to. Value is 0 if
 *                                       value is not set in \em card_data.
 * 
 * \retval ta_c_rc_ok Object instance written to \em card_number_enc_key_index.
 * \retval ta_c_rc_invalid_argument \em card_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em card_data is not of type [card_data](\ref card_data.h).
 * \retval ta_c_rc_invalid_argument \em card_number_enc_key_index is \em null-pointer.
 */
extern ta_e_result_code_t ta_card_data_get_card_number_enc_key_index(
	ta_object_t card_data,
	int *card_number_enc_key_index );

/**
 * \brief Card expiration date.
 * 
 * Only for Non-PCI applications and if available to the terminal.
 * 
 * \param[in] card_data Object instance of type [card_data](\ref card_data.h).
 * \param[out] card_expiry_date Pointer to variable to write object instance to. Object instance
 *                              is of type [timedate](\ref timedate.h) and is not retained. Object instance is
 *                              \em ta_object_invalid if value is not set in \em card_data.
 * 
 * \retval ta_c_rc_ok Object instance written to \em card_expiry_date.
 * \retval ta_c_rc_invalid_argument \em card_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em card_data is not of type [card_data](\ref card_data.h).
 * \retval ta_c_rc_invalid_argument \em card_expiry_date is \em null-pointer.
 */
extern ta_e_result_code_t ta_card_data_get_card_expiry_date(
	ta_object_t card_data,
	ta_object_t *card_expiry_date );

/**
 * \brief Card brand name.
 * 
 * \param[in] card_data Object instance of type [card_data](\ref card_data.h).
 * \param[out] brand_name Pointer to variable to write object instance to. Object instance
 *                        is of type [string](\ref string.h) and is not retained. Object instance is
 *                        \em ta_object_invalid if value is not set in \em card_data.
 * 
 * \retval ta_c_rc_ok Object instance written to \em brand_name.
 * \retval ta_c_rc_invalid_argument \em card_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em card_data is not of type [card_data](\ref card_data.h).
 * \retval ta_c_rc_invalid_argument \em brand_name is \em null-pointer.
 */
extern ta_e_result_code_t ta_card_data_get_brand_name(
	ta_object_t card_data,
	ta_object_t *brand_name );

/**
 * \brief Card tender name.
 * 
 * \param[in] card_data Object instance of type [card_data](\ref card_data.h).
 * \param[out] tender_name Pointer to variable to write object instance to. Object instance
 *                         is of type [string](\ref string.h) and is not retained. Object instance is
 *                         \em ta_object_invalid if value is not set in \em card_data.
 * 
 * \retval ta_c_rc_ok Object instance written to \em tender_name.
 * \retval ta_c_rc_invalid_argument \em card_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em card_data is not of type [card_data](\ref card_data.h).
 * \retval ta_c_rc_invalid_argument \em tender_name is \em null-pointer.
 */
extern ta_e_result_code_t ta_card_data_get_tender_name(
	ta_object_t card_data,
	ta_object_t *tender_name );

/**
 * \brief List of card track data if present.
 * 
 * \param[in] card_data Object instance of type [card_data](\ref card_data.h).
 * \param[out] card_track_datas Pointer to variable to write object instance to. Object instance
 *                              is of type [list](\ref list.h) and is not retained. The list contains
 *                              elements of type [card_track_data](\ref card_track_data.h).
 * 
 * \retval ta_c_rc_ok Object instance written to \em card_track_datas.
 * \retval ta_c_rc_invalid_argument \em card_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em card_data is not of type [card_data](\ref card_data.h).
 * \retval ta_c_rc_invalid_argument \em card_track_datas is \em null-pointer.
 */
extern ta_e_result_code_t ta_card_data_get_card_track_datas(
	ta_object_t card_data,
	ta_object_t *card_track_datas );

/**
 * \brief Loyalty information if present. Keyed by loyalty type string.
 * 
 * \param[in] card_data Object instance of type [card_data](\ref card_data.h).
 * \param[out] loyalty_information Pointer to variable to write object instance to. Object
 *                                  instance is of type [map](\ref map.h) and is not retained. The map
 *                                  contains keys and values both of type [string](\ref string.h).
 * 
 * \retval ta_c_rc_ok Object instance written to \em loyalty_information.
 * \retval ta_c_rc_invalid_argument \em card_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em card_data is not of type [card_data](\ref card_data.h).
 * \retval ta_c_rc_invalid_argument \em loyalty_information is \em null-pointer.
 */
extern ta_e_result_code_t ta_card_data_get_loyalty_information (
	ta_object_t card_data,
	ta_object_t *loyalty_information );

/**
 * \brief Petrol: Reference from the card.
 * 
 * \param[in] card_data Object instance of type [card_data](\ref card_data.h).
 * \param[out] card_ref Pointer to variable to write object instance to. Object instance
 *                      is of type [string](\ref string.h) and is not retained. Object instance is
 *                      \em ta_object_invalid if value is not set in \em card_data.
 * 
 * \retval ta_c_rc_ok Object instance written to \em card_ref.
 * \retval ta_c_rc_invalid_argument \em card_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em card_data is not of type [card_data](\ref card_data.h).
 * \retval ta_c_rc_invalid_argument \em card_ref is \em null-pointer.
 */
extern ta_e_result_code_t ta_card_data_get_card_ref(
	ta_object_t card_data,
	ta_object_t *card_ref );

/**
 * \brief Petrol: Defines if the ECR or EFT is responsible for further trx handling.
 * 
 * \param[in] card_data Object instance of type [card_data](\ref card_data.h).
 * \param[out] processing_disposition Pointer to variable to write value to. Value is
 *                      \em ta_c_pd_undefined if value is not set in \em card_data.
 * 
 * \retval ta_c_rc_ok Object instance written to \em processing_disposition.
 * \retval ta_c_rc_invalid_argument \em card_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em card_data is not of type [card_data](\ref card_data.h).
 * \retval ta_c_rc_invalid_argument \em processing_disposition is \em null-pointer.
 */
extern ta_e_result_code_t ta_card_data_get_processing_disposition(
	ta_object_t card_data,
	ta_e_processing_disposition_t *processing_disposition );

/**
 * \brief Card language.
 * 
 * \param[in] card_data Object instance of type [card_data](\ref card_data.h).
 * \param[out] language Pointer to variable to write object instance to. Object instance
 *                      is of type [string](\ref string.h) and is not retained. Object instance is
 *                      \em ta_object_invalid if value is not set in \em card_data.
 * 
 * \retval ta_c_rc_ok Object instance written to \em language.
 * \retval ta_c_rc_invalid_argument \em card_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em card_data is not of type [card_data](\ref card_data.h).
 * \retval ta_c_rc_invalid_argument \em language is \em null-pointer.
 */
extern ta_e_result_code_t ta_card_data_get_language(
	ta_object_t card_data,
	ta_object_t *language );

/**
 * \brief Card country code.
 * 
 * \param[in] card_data Object instance of type [card_data](\ref card_data.h).
 * \param[out] country_code Pointer to variable to write object instance to. Object instance
 *                          is of type [integer](\ref integer.h) and is not retained. Object
 *                          instance is \em ta_object_invalid if value is not set in \em card_data.
 * 
 * \retval ta_c_rc_ok Object instance written to \em country_code.
 * \retval ta_c_rc_invalid_argument \em card_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em card_data is not of type [card_data](\ref card_data.h).
 * \retval ta_c_rc_invalid_argument \em country_code is \em null-pointer.
 */
extern ta_e_result_code_t ta_card_data_get_card_country_code(
	ta_object_t card_data,
	ta_object_t *country_code );

/**
 * \brief Terminal country code.
 * 
 * \param[in] card_data Object instance of type [card_data](\ref card_data.h).
 * \param[out] country_code Pointer to variable to write object instance to. Object instance
 *                          is of type [integer](\ref integer.h) and is not retained. Object
 *                          instance is \em ta_object_invalid if value is not set in \em card_data.
 * 
 * \retval ta_c_rc_ok Object instance written to \em country_code.
 * \retval ta_c_rc_invalid_argument \em card_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em card_data is not of type [card_data](\ref card_data.h).
 * \retval ta_c_rc_invalid_argument \em country_code is \em null-pointer.
 */
extern ta_e_result_code_t ta_card_data_get_terminal_country_code(
	ta_object_t card_data,
	ta_object_t *country_code );

/**
 * \brief Uid of the contactless card.
 * 
 * \param[in] card_data Object instance of type [card_data](\ref card_data.h).
 * \param[out] uid Pointer to variable to write object instance to. Object instance is of type
 *                 [string](\ref string.h) and is not retained. Object instance is
 *                 \em ta_object_invalid if value is not set in \em card_data.
 * 
 * \retval ta_c_rc_ok Object instance written to \em uid.
 * \retval ta_c_rc_invalid_argument \em card_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em card_data is not of type [card_data](\ref card_data.h).
 * \retval ta_c_rc_invalid_argument \em uid is \em null-pointer.
 */
extern ta_e_result_code_t ta_card_data_get_uid(
	ta_object_t card_data,
	ta_object_t *uid );

/**
 * \brief Asrpd.
 * 
 * \param[in] card_data Object instance of type [card_data](\ref card_data.h).
 * \param[out] asrpd Pointer to variable to write object instance to. Object instance is of type
 *                   [string](\ref string.h) and is not retained. Object instance is
 *                   \em ta_object_invalid if value is not set in \em card_data.
 * 
 * \retval ta_c_rc_ok Object instance written to \em asrpd.
 * \retval ta_c_rc_invalid_argument \em card_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em card_data is not of type [card_data](\ref card_data.h).
 * \retval ta_c_rc_invalid_argument \em asrpd is \em null-pointer.
 */
extern ta_e_result_code_t ta_card_data_get_asrpd(
	ta_object_t card_data,
	ta_object_t *asrpd );

/**
 * \brief Card product type.
 * 
 * \param[in] card_data Object instance of type [card_data](\ref card_data.h).
 * \param[out] card_product_type Pointer to variable to write object instance to.
 * 
 * \retval ta_c_rc_ok Object instance written to \em card_product_type.
 * \retval ta_c_rc_invalid_argument \em card_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em card_data is not of type [card_data](\ref card_data.h).
 * \retval ta_c_rc_invalid_argument \em card_product_type is \em null-pointer.
 */
extern ta_e_result_code_t ta_card_data_get_card_product_type(
	ta_object_t card_data,
	ta_e_card_product_type_t *card_product_type );

/**
 * \brief Petrol: Card type.
 * 
 * \param[in] card_data Object instance of type [card_data](\ref card_data.h).
 * \param[out] card_type Pointer to variable to write object instance to. Object instance is of
 *                       type [integer](\ref integer.h) and is not retained. Object instance is
 *                       \em ta_object_invalid if value is not set in \em card_data.
 * 
 * \retval ta_c_rc_ok Object instance written to \em card_type.
 * \retval ta_c_rc_invalid_argument \em card_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em card_data is not of type [card_data](\ref card_data.h).
 * \retval ta_c_rc_invalid_argument \em card_type is \em null-pointer.
 */
extern ta_e_result_code_t ta_card_data_get_card_type(
	ta_object_t card_data,
	ta_object_t *card_type );

/**
 * \brief Petrol: Cardholder.
 * 
 * \param[in] card_data Object instance of type [card_data](\ref card_data.h).
 * \param[out] cardholder Pointer to variable to write object instance to. Object instance is of type
 *                        [string](\ref string.h) and is not retained. Object instance is
 *                        \em ta_object_invalid if value is not set in \em card_data.
 * 
 * \retval ta_c_rc_ok Object instance written to \em asrpd.
 * \retval ta_c_rc_invalid_argument \em card_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em card_data is not of type [card_data](\ref card_data.h).
 * \retval ta_c_rc_invalid_argument \em cardholder is \em null-pointer.
 */
extern ta_e_result_code_t ta_card_data_get_cardholder(
	ta_object_t card_data,
	ta_object_t *cardholder );

/**
 * \brief Account
 * \param[in] card_data Object instance of type [card_data](\ref card_data.h).
 * \param[out] account_type Pointer to variable to write object instance to.
 * 
 * \retval ta_c_rc_ok Object instance written to \em card_product_type.
 * \retval ta_c_rc_invalid_argument \em card_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em card_data is not of type [card_data](\ref card_data.h).
 * \retval ta_c_rc_invalid_argument \em account_type is \em null-pointer.
 */
extern ta_e_result_code_t ta_card_data_get_account_type(
	ta_object_t card_data,
	ta_e_account_type_t *account_type );

/**
 * \brief EMV PAR.
 * 
 * The EMV PAR "may be used to link transactions initiated on Payment Tokens with transactions
 * initiated on the underlying PAN", which can be used in a transaction response to be able the
 * identify if the transaction e.g. with a used token PAN is related to a previous transaction
 * performed with the underlying PAN. If so, both transaction responses will contain the same
 * value in the EmvPar field.
 * 
 * \param[in] card_data Object instance of type [card_data](\ref card_data.h).
 * \param[out] emv_par Pointer to variable to write object instance to. Object instance is of type
 *                     [string](\ref string.h) and is not retained. Object instance is
 *                     \em ta_object_invalid if value is not set in \em card_data.
 * 
 * \retval ta_c_rc_ok Object instance written to \em asrpd.
 * \retval ta_c_rc_invalid_argument \em card_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em card_data is not of type [card_data](\ref card_data.h).
 * \retval ta_c_rc_invalid_argument \em emv_par is \em null-pointer.
 */
extern ta_e_result_code_t ta_card_data_get_emv_par(
	ta_object_t card_data,
	ta_object_t *emv_par );

/**
 * \brief Token PAN.
 * 
 * The token PAN is a tokenized version for an underlaying card PAN. If the underlaying payment
 * protocol supports it, a payment transaction can be initiated with the token PAN instead of
 * using a card. A token PAN is normally generated by a tokenization service either form the
 * acquirer host or the issuer host.
 * 
 * The TokenPan field is used in a SIXml request message as part of the sixml:TransactionData
 * container to trigger a token-based transaction and in a SIXml response message as part of
 * the sixml:CardData container for returning token PANs to the ECR.
 * 
 * The TokenPan field always must be accompanied by a corresponding TokenPanType field.
 * 
 * \param[in] card_data Object instance of type [card_data](\ref card_data.h).
 * \param[out] token_pan Pointer to variable to write object instance to. Object instance is of type
 *                       [string](\ref string.h) and is not retained. Object instance is
 *                       \em ta_object_invalid if value is not set in \em card_data.
 * 
 * \retval ta_c_rc_ok Object instance written to \em asrpd.
 * \retval ta_c_rc_invalid_argument \em card_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em card_data is not of type [card_data](\ref card_data.h).
 * \retval ta_c_rc_invalid_argument \em token_pan is \em null-pointer.
 */
extern ta_e_result_code_t ta_card_data_get_token_pan(
	ta_object_t card_data,
	ta_object_t *token_pan );

/**
 * \brief Token PAN type.
 * 
 * To differ the source of a token PAN, the TokenPanType field is used in a SIXml request
 * message as part of the sixml:TransactionData container and in a SIXml response message
 * as part of the sixml:CardData container.
 * 
 * The TokenPanType field always is transmitted if a TokenPan field is transmitted but must
 * not be transmitted alone.
 * 
 * \param[in] card_data Object instance of type [card_data](\ref card_data.h).
 * \param[out] token_pan_type Pointer to variable to write object instance to.
 * 
 * \retval ta_c_rc_ok Object instance written to \em card_product_type.
 * \retval ta_c_rc_invalid_argument \em card_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em card_data is not of type [card_data](\ref card_data.h).
 * \retval ta_c_rc_invalid_argument \em token_pan_type is \em null-pointer.
 */
extern ta_e_result_code_t ta_card_data_get_token_pan_type(
	ta_object_t card_data,
	ta_e_token_pan_type_t *token_pan_type );


#ifdef __cplusplus
}
#endif

#endif
