/**
 * \file
 * \brief Card track data.
 * \details Object type \em card_track_data.
 */

#ifndef TA_CARD_TRACK_DATA_H
#define TA_CARD_TRACK_DATA_H

#include "common/object.h"
#include "common/boolean.h"


#ifdef __cplusplus
extern "C" {
#endif


/**
 * \brief Track number.
 * 
 * Track number is 1, 2 or 3.
 * 
 * \param[in] track_data Object instance of type [card_track_data](\ref card_track_data.h).
 * \param[out] track_number Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Object instance written to \em track_number.
 * \retval ta_c_rc_invalid_argument \em track_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em track_data is not of type [card_track_data](\ref card_track_data.h).
 * \retval ta_c_rc_invalid_argument \em track_number is \em null-pointer.
 */
extern ta_e_result_code_t ta_card_track_data_get_track_number(
	ta_object_t track_data,
	int *track_number );

/**
 * \brief Track data.
 * 
 * \param[in] track_data Object instance of type [card_track_data](\ref card_track_data.h).
 * \param[out] data Pointer to variable to write object instance to. Object instance is of
 *                  type \em string and is not retained.
 * 
 * \retval ta_c_rc_ok Object instance written to \em data.
 * \retval ta_c_rc_invalid_argument \em track_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em track_data is not of type [card_track_data](\ref card_track_data.h).
 * \retval ta_c_rc_invalid_argument \em data is \em null-pointer.
 */
extern ta_e_result_code_t ta_card_track_data_get_data(
	ta_object_t track_data,
	ta_object_t *data );


#ifdef __cplusplus
}
#endif

#endif
