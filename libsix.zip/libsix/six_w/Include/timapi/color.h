/**
 * \file
 * \brief Color.
 * 
 * Represented as 3-component colors (red, green, blue) in the range from 0 to 255.
 */

#ifndef TA_COLOR_H
#define TA_COLOR_H

#include <stdint.h>

#include "common/boolean.h"
#include "constants/feature_support.h"
#include "constants/protocol_level.h"


#ifdef __cplusplus
extern "C" {
#endif


/**
 * \brief Color.
 */
typedef struct ta_s_color {
	/**
	 * \brief Red color component in the range from 0 to 255.
	 */
	uint8_t red;
	
	/**
	 * \brief Green color component in the range from 0 to 255.
	 */
	uint8_t green;
	
	/**
	 * \brief Blue color component in the range from 0 to 255.
	 */
	uint8_t blue;
} ta_s_color_t;


#ifdef __cplusplus
}
#endif

#endif

