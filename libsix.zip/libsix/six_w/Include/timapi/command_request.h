/**
 * \file
 * \brief Command request.
 * \details Object type \em command_request.
 */

#ifndef TA_COMMAND_REQUEST_H
#define TA_COMMAND_REQUEST_H

#include <stdint.h>

#include "common/object.h"
#include "constants/card_reader.h"
#include "constants/resource_id.h"


#ifdef __cplusplus
extern "C" {
#endif


/**
 * \brief Create object of type [command_request](\ref command_request.h).
 * 
 * \param[out] request Pointer to variable to write created object instance to.
 *                     Created object instance is retained.
 * 
 * \retval ta_c_rc_ok Object instance has been created and written to \em request.
 * \retval ta_c_rc_invalid_argument \em request is \em null-pointer.
 * \retval ta_c_rc_out_of_memory Failed allocating memory.
 */
extern ta_e_result_code_t ta_command_request_create( ta_object_t *request );



/**
 * \brief Defines that shall be used for the card commands.
 * 
 * \param[in] request Object instance of type [command_request](\ref command_request.h).
 * \param[out] card_reader Pointer to variable to write value to. Value is \em ta_c_cr_undefined
 *                         if value is not set in \em request.
 * 
 * \retval ta_c_rc_ok Object instance written to \em card_reader.
 * \retval ta_c_rc_invalid_argument \em request is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em request is not of type [command_request](\ref command_request.h).
 * \retval ta_c_rc_invalid_argument \em card_reader is \em null-pointer.
 */
extern ta_e_result_code_t ta_command_request_get_card_reader(
	ta_object_t request,
	ta_e_card_reader_t *card_reader );

/**
 * \brief Defines that shall be used for the card commands.
 * 
 * \param[in] request Object instance of type [command_request](\ref command_request.h).
 * \param[in] card_reader Value to set. Value can be \em ta_c_cr_undefined to clear the value
 *                        in \em request.
 * 
 * \retval ta_c_rc_ok Value assigned to \em request.
 * \retval ta_c_rc_invalid_argument \em request is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em request is not of type [command_request](\ref command_request.h).
 */
extern ta_e_result_code_t ta_command_request_set_card_reader(
	ta_object_t request,
	ta_e_card_reader_t card_reader );



/**
 * \brief Specifies the order of a CommandRequest in CommandRequestList.
 * 
 * \param[in] request Object instance of type [command_request](\ref command_request.h).
 * \param[out] order Pointer to variable to write value to. Value is 0 if value is not set
 *                   in \em request.
 * 
 * \retval ta_c_rc_ok Object instance written to \em order.
 * \retval ta_c_rc_invalid_argument \em request is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em request is not of type [command_request](\ref command_request.h).
 * \retval ta_c_rc_invalid_argument \em order is \em null-pointer.
 */
extern ta_e_result_code_t ta_command_request_get_order(
	ta_object_t request,
	int *order );

/**
 * \brief Specifies the order of a CommandRequest in CommandRequestList.
 * 
 * \param[in] request Object instance of type [command_request](\ref command_request.h).
 * \param[in] order Value to set.
 * 
 * \retval ta_c_rc_ok Value assigned to \em request.
 * \retval ta_c_rc_invalid_argument \em request is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em request is not of type [command_request](\ref command_request.h).
 */
extern ta_e_result_code_t ta_command_request_set_order(
	ta_object_t request,
	int order );



/**
 * \brief Command to send to card.
 * 
 * \param[in] request Object instance of type [command_request](\ref command_request.h).
 * \param[out] card_command Pointer to variable to write object instance to. Object
 *                                 instance is of type [string](\ref string.h) and is not retained. Object
 *                                 instance is \em ta_object_invalid if value is not set
 *                                 in \em request.
 * 
 * \retval ta_c_rc_ok Object instance written to \em card_command.
 * \retval ta_c_rc_invalid_argument \em request is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em request is not of type [command_request](\ref command_request.h).
 * \retval ta_c_rc_invalid_argument \em card_command is \em null-pointer.
 */
extern ta_e_result_code_t ta_command_request_get_card_command(
	ta_object_t request,
	ta_object_t *card_command );

/**
 * \brief Command to send to card.
 * 
 * \param[in] request Object instance of type [command_request](\ref command_request.h).
 * \param[in] card_command Object instance to set. Object instance can be
 *                         \em ta_object_invalid to clear the value in \em request. If
 *                         object instance is not ta_object_invalid is has to be of
 *                         type \em string.
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em request.
 * \retval ta_c_rc_invalid_argument \em request is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em request is not of type [command_request](\ref command_request.h).
 * \retval ta_c_rc_invalid_argument \em card_command is not \em ta_object_invalid and
 *                                  is not of type [string](\ref string.h).
 */
extern ta_e_result_code_t ta_command_request_set_card_command(
	ta_object_t request,
	ta_object_t card_command );



/**
 * \brief If a dialog shall be shown in case of a positive command response.
 * 
 * \param[in] request Object instance of type [command_request](\ref command_request.h).
 * \param[out] positive_resource Pointer to variable to write value to. Value is
 *                               \em ta_c_rid_undefined if value is not set in \em request.
 * 
 * \retval ta_c_rc_ok Object instance written to \em positive_resource.
 * \retval ta_c_rc_invalid_argument \em request is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em request is not of type [command_request](\ref command_request.h).
 * \retval ta_c_rc_invalid_argument \em positive_resource is \em null-pointer.
 */
extern ta_e_result_code_t ta_command_request_get_positive_resource(
	ta_object_t request,
	ta_e_resource_id_t *positive_resource );

/**
 * \brief If a dialog shall be shown in case of a positive command response.
 * 
 * \param[in] request Object instance of type [command_request](\ref command_request.h).
 * \param[in] positive_resource Value to set. Value can be \em ta_c_rid_undefined to clear
 *                              the value in \em request.
 * 
 * \retval ta_c_rc_ok Value assigned to \em request.
 * \retval ta_c_rc_invalid_argument \em request is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em request is not of type [command_request](\ref command_request.h).
 */
extern ta_e_result_code_t ta_command_request_set_positive_resource(
	ta_object_t request,
	ta_e_resource_id_t positive_resource );



/**
 * \brief If a dialog shall be shown in case of a negative command response.
 * 
 * \param[in] request Object instance of type [command_request](\ref command_request.h).
 * \param[out] negative_resource Pointer to variable to write value to. Value is
 *                               \em ta_c_rid_undefined if value is not set in \em request.
 * 
 * \retval ta_c_rc_ok Object instance written to \em negative_resource.
 * \retval ta_c_rc_invalid_argument \em request is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em request is not of type [command_request](\ref command_request.h).
 * \retval ta_c_rc_invalid_argument \em negative_resource is \em null-pointer.
 */
extern ta_e_result_code_t ta_command_request_get_negative_resource(
	ta_object_t request,
	ta_e_resource_id_t *negative_resource );

/**
 * \brief If a dialog shall be shown in case of a negative command response.
 * 
 * \param[in] request Object instance of type [command_request](\ref command_request.h).
 * \param[in] negative_resource Value to set. Value can be \em ta_c_rid_undefined to clear
 *                              the value in \em request.
 * 
 * \retval ta_c_rc_ok Value assigned to \em request.
 * \retval ta_c_rc_invalid_argument \em request is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em request is not of type [command_request](\ref command_request.h).
 */
extern ta_e_result_code_t ta_command_request_set_negative_resource(
	ta_object_t request,
	ta_e_resource_id_t negative_resource );



/**
 * \brief If a dialog shall be shown during the execution of a command.
 * 
 * \param[in] request Object instance of type [command_request](\ref command_request.h).
 * \param[out] execution_resource Pointer to variable to write value to. Value is
 *                                \em ta_c_rid_undefined if value is not set in \em request.
 * 
 * \retval ta_c_rc_ok Object instance written to \em execution_resource.
 * \retval ta_c_rc_invalid_argument \em request is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em request is not of type [command_request](\ref command_request.h).
 * \retval ta_c_rc_invalid_argument \em execution_resource is \em null-pointer.
 */
extern ta_e_result_code_t ta_command_request_get_execution_resource(
	ta_object_t request,
	ta_e_resource_id_t *execution_resource );

/**
 * \brief If a dialog shall be shown during the execution of a command.
 * 
 * \param[in] request Object instance of type [command_request](\ref command_request.h).
 * \param[in] execution_resource Value to set. Value can be \em ta_c_rid_undefined to clear
 *                               the value in \em request.
 * 
 * \retval ta_c_rc_ok Value assigned to \em request.
 * \retval ta_c_rc_invalid_argument \em request is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em request is not of type [command_request](\ref command_request.h).
 */
extern ta_e_result_code_t ta_command_request_set_execution_resource(
	ta_object_t request,
	ta_e_resource_id_t execution_resource );



/**
 * \brief If a dialog shall be shown before sending a card command.
 * 
 * \param[in] request Object instance of type [command_request](\ref command_request.h).
 * \param[out] pre_resource Pointer to variable to write value to. Value is
 *                          \em ta_c_rid_undefined if value is not set in \em request.
 * 
 * \retval ta_c_rc_ok Object instance written to \em execution_resource.
 * \retval ta_c_rc_invalid_argument \em request is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em request is not of type [command_request](\ref command_request.h).
 * \retval ta_c_rc_invalid_argument \em pre_resource is \em null-pointer.
 */
extern ta_e_result_code_t ta_command_request_get_pre_resource(
	ta_object_t request,
	ta_e_resource_id_t *pre_resource );

/**
 * \brief If a dialog shall be shown before sending a card command.
 * 
 * \param[in] request Object instance of type [command_request](\ref command_request.h).
 * \param[in] pre_resource Value to set. Value can be \em ta_c_rid_undefined to clear
 *                               the value in \em request.
 * 
 * \retval ta_c_rc_ok Value assigned to \em request.
 * \retval ta_c_rc_invalid_argument \em request is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em request is not of type [command_request](\ref command_request.h).
 */
extern ta_e_result_code_t ta_command_request_set_pre_resource(
	ta_object_t request,
	ta_e_resource_id_t pre_resource );



/**
 * \brief Possible positive answers for a CommandRequest.
 * 
 * \param[in] request Object instance of type [command_request](\ref command_request.h).
 * \param[out] positive_answers Pointer to variable to write object instance to. Object instance
 *                              is of type [list](\ref list.h) and is not retained. The list contains
 *                              elements of type [string](\ref string.h).
 * 
 * \retval ta_c_rc_ok Object instance written to \em positive_answers.
 * \retval ta_c_rc_invalid_argument \em request is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em request is not of type [command_request](\ref command_request.h).
 * \retval ta_c_rc_invalid_argument \em positive_answers is \em null-pointer.
 */
extern ta_e_result_code_t ta_command_request_get_positive_answers(
	ta_object_t request,
	ta_object_t *positive_answers );

/**
 * \brief Set possible positive answers for a CommandRequest.
 * 
 * \param[in] request Object instance of type [command_request](\ref command_request.h).
 * \param[in] positive_answers Object instance to set. Object instance has to be of type [list](\ref list.h).
 *                             The list has to contain elements of type [string](\ref string.h).
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em request.
 * \retval ta_c_rc_invalid_argument \em request is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em request is not of type [command_request](\ref command_request.h).
 * \retval ta_c_rc_invalid_argument \em positive_answers is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em positive_answers is not of type [list](\ref list.h).
 * \retval ta_c_rc_invalid_argument Element in \em positive_answers is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument Element in \em positive_answers is not of type [string](\ref string.h).
 */
extern ta_e_result_code_t ta_command_request_set_positive_answers(
	ta_object_t request,
	ta_object_t positive_answers );


#ifdef __cplusplus
}
#endif

#endif
