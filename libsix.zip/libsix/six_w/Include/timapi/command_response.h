/**
 * \file
 * \brief Command response.
 * \details Object type \em command_response.
 */

#ifndef TA_COMMAND_RESPONSE_H
#define TA_COMMAND_RESPONSE_H

#include <stdint.h>

#include "common/object.h"
#include "constants/response_type.h"


#ifdef __cplusplus
extern "C" {
#endif


/**
 * \brief Specifies the order of a CommandResponse in the CommandResponseList.
 * 
 * \param[in] response Object instance of type [command_response](\ref command_response.h).
 * \param[out] order Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Object instance written to \em order.
 * \retval ta_c_rc_invalid_argument \em response is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em response is not of type [command_response](\ref command_response.h).
 * \retval ta_c_rc_invalid_argument \em order is \em null-pointer.
 */
extern ta_e_result_code_t ta_command_response_get_order(
	ta_object_t response,
	int *order );

/**
 * \brief Defines the outcome type of the command response.
 * 
 * \param[in] response Object instance of type [command_response](\ref command_response.h).
 * \param[out] response_type Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Object instance written to \em response_type.
 * \retval ta_c_rc_invalid_argument \em response is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em response is not of type [command_response](\ref command_response.h).
 * \retval ta_c_rc_invalid_argument \em response_type is \em null-pointer.
 */
extern ta_e_result_code_t ta_command_response_get_response_type(
	ta_object_t response,
	ta_e_response_type_t *response_type );

/**
 * \brief Response received from card.
 * 
 * \param[in] response Object instance of type [command_response](\ref command_response.h).
 * \param[out] card_response Pointer to variable to write object instance to. Object instance
 *                           is of type [string](\ref string.h) and is not retained. Object instance is
 *                           \em ta_object_invalid if value is not set in \em response.
 * 
 * \retval ta_c_rc_ok Object instance written to \em card_response.
 * \retval ta_c_rc_invalid_argument \em response is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em response is not of type [command_response](\ref command_response.h).
 * \retval ta_c_rc_invalid_argument \em card_response is \em null-pointer.
 */
extern ta_e_result_code_t ta_command_response_get_card_response(
	ta_object_t response,
	ta_object_t *card_response );

/**
 * \brief UID of the card.
 * 
 * \param[in] response Object instance of type [command_response](\ref command_response.h).
 * \param[out] uid Pointer to variable to write object instance to. Object instance
 *                 is of type [string](\ref string.h) and is not retained. Object instance is
 *                 \em ta_object_invalid if value is not set in \em response.
 * 
 * \retval ta_c_rc_ok Object instance written to \em uid.
 * \retval ta_c_rc_invalid_argument \em response is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em response is not of type [command_response](\ref command_response.h).
 * \retval ta_c_rc_invalid_argument \em uid is \em null-pointer.
 */
extern ta_e_result_code_t ta_command_response_get_uid(
	ta_object_t response,
	ta_object_t *uid );

/**
 * \brief Answer to reset information received from the card.
 * 
 * \param[in] response Object instance of type [command_response](\ref command_response.h).
 * \param[out] atr Pointer to variable to write object instance to. Object instance
 *                 is of type [string](\ref string.h) and is not retained. Object instance is
 *                 \em ta_object_invalid if value is not set in \em response.
 * 
 * \retval ta_c_rc_ok Object instance written to \em atr.
 * \retval ta_c_rc_invalid_argument \em response is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em response is not of type [command_response](\ref command_response.h).
 * \retval ta_c_rc_invalid_argument \em atr is \em null-pointer.
 */
extern ta_e_result_code_t ta_command_response_get_atr(
	ta_object_t response,
	ta_object_t *atr );

#ifdef __cplusplus
}
#endif

#endif
