/**
 * \file
 * \brief List value.
 * \details Object type \em list.
 */

#ifndef TA_LIST_H
#define TA_LIST_H

#include <stddef.h>

#include "boolean.h"
#include "../constants/result_code.h"



#ifdef __cplusplus
extern "C" {
#endif


/**
 * \brief Create empty list.
 * 
 * Caller retains a reference to the created list. Different users can
 * individually retain the list instance themselves by calling
 * ta_object_retain. Each call to \ref ta_object_retain and \ref ta_list_create
 * has to be matched with a call to \ref ta_object_release. The list instance
 * is destroyed once nobody retains the list instance anymore.
 * 
 * Lists can be read-only. In this case all functions trying to modify
 * the list return an error.
 * 
 * \param[out] list Pointer to variable to write created object instance to.
 *                  Created object instance is retained.
 * 
 * \retval ta_c_rc_ok Object instance has been created and written to \em list.
 * \retval ta_c_rc_invalid_argument \em list is \em null-pointer.
 * \retval ta_c_rc_out_of_memory Failed allocating memory.
 */
extern ta_e_result_code_t ta_list_create(
	ta_object_t *list );

/**
 * \brief Add element to list.
 * 
 * Added element is retained if not \em null-pointer. Adding \em null-pointers to list
 * is allowed. The user is responsible to verify no \em null-pointers are added
 * to the list if desired.
 * 
 * \param[in] list Object instance of type [list](\ref list.h).
 * \param[in] element Object instance to add. Object instance can be \em ta_object_invalid.
 * 
 * \retval ta_c_rc_ok Object instance added to \em list.
 * \retval ta_c_rc_invalid_argument \em list is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em list is not of type [list](\ref list.h).
 * \retval ta_c_rc_invalid_argument \em list is read-only.
 */
extern ta_e_result_code_t ta_list_add(
	ta_object_t list,
	ta_object_t element );

/**
 * \brief Remove element from list.
 * 
 * Removed element is release if not \em null-pointer.
 * 
 * \param[in] list Object instance of type [list](\ref list.h).
 * \param[in] index Index of element to remove.
 * 
 * \retval ta_c_rc_ok Object instance removed from \em list.
 * \retval ta_c_rc_invalid_argument \em list is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em list is not of type [list](\ref list.h).
 * \retval ta_c_rc_invalid_argument \em list is read-only.
 * \retval ta_c_rc_invalid_argument \em index is less than 0.
 * \retval ta_c_rc_invalid_argument \em index is larger than or equal to element count.
 */
extern ta_e_result_code_t ta_list_remove(
	ta_object_t list,
	size_t index );

/**
 * \brief Remove all elements from list.
 * 
 * Removed element are release if not \em null-pointer.
 * 
 * \param[in] list Object instance of type [list](\ref list.h).
 * 
 * \retval ta_c_rc_ok All object instances removed from \em list.
 * \retval ta_c_rc_invalid_argument \em list is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em list is not of type [list](\ref list.h).
 * \retval ta_c_rc_invalid_argument \em list is read-only.
 */
extern ta_e_result_code_t ta_list_remove_all(
	ta_object_t list );

/**
 * \brief Element is present in list.
 * 
 * \param[in] list Object instance of type [list](\ref list.h).
 * \param[in] element Object instance to find. Object instance can be \em ta_object_invalid.
 * \param[out] is_present Pointer to variable to write result to. Set to \em ta_c_b_true
 *                        if element is present in list. Set to \em ta_c_b_false if
 *                        element is absent from list.
 * 
 * \retval ta_c_rc_ok Result written to to \em is_present.
 * \retval ta_c_rc_invalid_argument \em list is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em list is not of type [list](\ref list.h).
 * \retval ta_c_rc_invalid_argument \em is_present is \em null-pointer.
 */
extern ta_e_result_code_t ta_list_has(
	ta_object_t list,
	ta_object_t element,
	ta_e_boolean_t *is_present );

/**
 * \brief Get number of elements in list.
 * 
 * \param[in] list Object instance of type [list](\ref list.h).
 * \param[out] count Pointer to variable to write count to.
 * 
 * \retval ta_c_rc_ok Count written to to \em count.
 * \retval ta_c_rc_invalid_argument \em list is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em list is not of type [list](\ref list.h).
 * \retval ta_c_rc_invalid_argument \em is_present is \em null-pointer.
 */
extern ta_e_result_code_t ta_list_get_count(
	ta_object_t list,
	size_t *count );

/**
 * \brief Get element at index in list.
 * 
 * Returned element is not retained. User has to call ta_object_retain to hold the
 * returned object outside of the list.
 * 
 * \param[in] list Object instance of type [list](\ref list.h).
 * \param[in] index Index of element to get.
 * \param[out] element Pointer to variable to write object instance to. Written object
 *                     instance can be \em ta_object_invalid. Written object instance
 *                     is not retained.
 * 
 * \retval ta_c_rc_ok Object instance written to to \em element.
 * \retval ta_c_rc_invalid_argument \em list is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em list is not of type [list](\ref list.h).
 * \retval ta_c_rc_invalid_argument \em element is \em null-pointer.
 * \retval ta_c_rc_invalid_argument \em index is less than 0.
 * \retval ta_c_rc_invalid_argument \em index is larger than or equal to element count.
 */
extern ta_e_result_code_t ta_list_get_at(
	ta_object_t list,
	size_t index,
	ta_object_t *element );

/**
 * \brief Get index of first occurance of element or -1 if absent.
 * 
 * \param[in] list Object instance of type [list](\ref list.h).
 * \param[in] element Object instance to search for. Object instance can be \em ta_object_invalid.
 * \param[out] index Pointer to variable to write index to. Index is -1 if element is absent.
 * 
 * \retval ta_c_rc_ok Object instance written to to \em element.
 * \retval ta_c_rc_invalid_argument \em list is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em list is not of type [list](\ref list.h).
 * \retval ta_c_rc_invalid_argument \em index is \em null-pointer.
 */
extern ta_e_result_code_t ta_list_index_of(
	ta_object_t list,
	ta_object_t element,
	int *index );


#ifdef __cplusplus
}
#endif

#endif
