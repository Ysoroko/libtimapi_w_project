/**
 * \file
 * \brief Map value.
 * \details Object type \em map.
 */

#ifndef TA_MAP_H
#define TA_MAP_H

#include <stddef.h>

#include "boolean.h"
#include "../constants/result_code.h"



#ifdef __cplusplus
extern "C" {
#endif


/**
 * \brief Create empty map.
 * 
 * Caller retains a reference to the created map. Different users can
 * individually retain the map instance themselves by calling
 * ta_object_retain. Each call to \ref ta_object_retain and \ref ta_map_create
 * has to be matched with a call to \ref ta_object_release. The map instance
 * is destroyed once nobody retains the map instance anymore.
 * 
 * Maps can be read-only. In this case all functions trying to modify
 * the map return an error.
 * 
 * \param[out] map Pointer to variable to write created object instance to.
 *                 Created object instance is retained.
 * 
 * \retval ta_c_rc_ok Object instance has been created and written to \em map.
 * \retval ta_c_rc_invalid_argument \em map is \em null-pointer.
 * \retval ta_c_rc_out_of_memory Failed allocating memory.
 */
extern ta_e_result_code_t ta_map_create(
	ta_object_t *map );

/**
 * \brief Set entry in map.
 * 
 * If entry is added the key and value are retained if not \em null-pointer. Adding
 * \em null-pointers as value to map is allowed. The user is responsible to verify no
 * \em null-pointers are added to the map if desired.
 * 
 * \param[in] map Object instance of type [map](\ref map.h).
 * \param[in] key Object instance to use as key.
 * \param[in] value Object instance to use as value. Object instance can be \em ta_object_invalid.
 * 
 * \retval ta_c_rc_ok Entry with key and value object instance added to \em map.
 * \retval ta_c_rc_invalid_argument \em map is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em map is not of type [map](\ref map.h).
 * \retval ta_c_rc_invalid_argument \em map is read-only.
 * \retval ta_c_rc_invalid_argument \em key is \em ta_object_invalid.
 */
extern ta_e_result_code_t ta_map_set(
	ta_object_t map,
	ta_object_t key,
	ta_object_t value );

/**
 * \brief Remove entry from map.
 * 
 * Entry key and value are release if not \em null-pointer.
 * 
 * \param[in] map Object instance of type [map](\ref map.h).
 * \param[in] key Object instance to use as key.
 * 
 * \retval ta_c_rc_ok Entry with key object instance removed from \em map. Key object
 *                    instance has been released. If value object instance is not
 *                    ta_object_invalid value object instance has been released.
 * \retval ta_c_rc_invalid_argument \em map is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em map is not of type [map](\ref map.h).
 * \retval ta_c_rc_invalid_argument \em map is read-only.
 * \retval ta_c_rc_invalid_argument \em key is not present in the map.
 */
extern ta_e_result_code_t ta_map_remove(
	ta_object_t map,
	ta_object_t key );

/**
 * \brief Remove all entries from map.
 * 
 * Keys and values of removed entries are release if not \em null-pointer.
 * 
 * \param[in] map Object instance of type [map](\ref map.h).
 * 
 * \retval ta_c_rc_ok All entries removed from \em map. All key object instance have been
 *                    released. All value object instance that are not ta_object_invalid
 *                    have been released.
 * \retval ta_c_rc_invalid_argument \em map is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em map is not of type [map](\ref map.h).
 * \retval ta_c_rc_invalid_argument \em map is read-only.
 */
extern ta_e_result_code_t ta_map_remove_all(
	ta_object_t map );

/**
 * \brief Entry is present in map.
 * 
 * \param[in] map Object instance of type [map](\ref map.h).
 * \param[in] key Key object instance to find.
 * \param[out] is_present Pointer to variable to write result to. Set to \em ta_c_b_true
 *                        if key is present in map. Set to \em ta_c_b_false if key is
 *                        absent from map.
 * 
 * \retval ta_c_rc_ok Result written to to \em is_present.
 * \retval ta_c_rc_invalid_argument \em map is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em map is not of type [map](\ref map.h).
 * \retval ta_c_rc_invalid_argument \em is_present is \em null-pointer.
 */
extern ta_e_result_code_t ta_map_has(
	ta_object_t map,
	ta_object_t key,
	ta_e_boolean_t *is_present );

/**
 * \brief Get number of entries in map.
 * 
 * \param[in] map Object instance of type [map](\ref map.h).
 * \param[out] count Pointer to variable to write count to.
 * 
 * \retval ta_c_rc_ok Count written to to \em count.
 * \retval ta_c_rc_invalid_argument \em map is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em map is not of type [map](\ref map.h).
 * \retval ta_c_rc_invalid_argument \em is_present is \em null-pointer.
 */
extern ta_e_result_code_t ta_map_get_count(
	ta_object_t map,
	size_t *count );

/**
 * \brief Get value for key in map.
 * 
 * Value is not retained. User has to call ta_object_retain to hold the
 * returned object outside of the map.
 * 
 * \param[in] map Object instance of type [map](\ref map.h).
 * \param[in] key Key object instance to get value object instance for.
 * \param[out] value Pointer to variable to write value object instance to. Written object
 *                   instance can be \em ta_object_invalid. Written object instance
 *                   is not retained.
 * 
 * \retval ta_c_rc_ok Object instance written to to \em value.
 * \retval ta_c_rc_invalid_argument \em map is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em map is not of type [map](\ref map.h).
 * \retval ta_c_rc_invalid_argument \em key is not present in the map.
 * \retval ta_c_rc_invalid_argument \em value is \em null-pointer.
 */
extern ta_e_result_code_t ta_map_get(
	ta_object_t map,
	ta_object_t key,
	ta_object_t *value );

/**
 * \brief Get value for key in map or default value if absent.
 * 
 * Value is not retained. User has to call ta_object_retain to hold the
 * returned object outside of the map.
 * 
 * \param[in] map Object instance of type [map](\ref map.h).
 * \param[in] key Key object instance to get value object instance for.
 * \param[out] value Pointer to variable to write value object instance to. Written object
 *                   instance can be \em ta_object_invalid. Written object instance
 *                   is not retained.
 * \param[in] default_value Default object instance to use if key object instance is absent
 *                          from map. Object instance can be \em ta_object_invalid.
 * 
 * \retval ta_c_rc_ok Object instance written to to \em value.
 * \retval ta_c_rc_invalid_argument \em map is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em map is not of type [map](\ref map.h).
 * \retval ta_c_rc_invalid_argument \em value is \em null-pointer.
 */
extern ta_e_result_code_t ta_map_get_default(
	ta_object_t map,
	ta_object_t key,
	ta_object_t *value,
	ta_object_t default_value );

/**
 * \brief Get key and value by index from map.
 * 
 * \warning This is for iteration purpose only. The order of entries in the map can change
 *          with any call to ta_map_set and ta_map_remove.
 * 
 * Key and value are not retained. User has to call ta_object_retain to hold the
 * returned objects outside of the map.
 * 
 * \param[in] map Object instance of type [map](\ref map.h).
 * \param[in] index Index of entry to retrieve.
 * \param[out] key Pointer to variable to write key object instance to. Written object instance
 *                 is not retained.
 * \param[out] value Pointer to variable to write value object instance to. Written object
 *                   instance can be \em ta_object_invalid. Written object instance
 *                   is not retained.
 * 
 * \retval ta_c_rc_ok Object instance written to to \em value.
 * \retval ta_c_rc_invalid_argument \em map is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em map is not of type [map](\ref map.h).
 * \retval ta_c_rc_invalid_argument \em index is less than 0 or greater than or equal to ta_map_count.
 * \retval ta_c_rc_invalid_argument \em key is \em null-pointer.
 * \retval ta_c_rc_invalid_argument \em value is \em null-pointer.
 */
extern ta_e_result_code_t ta_map_get_at(
	ta_object_t map,
	size_t index,
	ta_object_t *key,
	ta_object_t *value );


#ifdef __cplusplus
}
#endif

#endif
