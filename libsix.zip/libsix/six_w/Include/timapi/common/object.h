/**
 * \file
 * \brief Base object.
 */

#ifndef TA_OBJECT_H
#define TA_OBJECT_H


#include "../constants/result_code.h"


#ifdef __cplusplus
extern "C" {
#endif



/** \brief Opaque object handler. */
typedef struct _ta_object * ta_object_t;

/** \brief Invalid object (\em null-pointer). */
#define ta_object_invalid ((ta_object_t)0)



/**
 * \brief Retain object instance.
 * 
 * Retain object instance ensures the instance is keep alive as long as the user
 * requires working with the object instance. Call ta_object_release if the user
 * does not access the object instance anymore in the future. The object instance
 * is destroyed once nobody retains the object instance anymore. 
 * 
 * \param[in] object Object instance to retain.
 * 
 * \retval ta_c_rc_ok Object instance retained.
 * \retval ta_c_rc_invalid_argument \em object is \em ta_object_invalid.
 */
extern ta_e_result_code_t ta_object_retain(
	ta_object_t object );

/**
 * \brief Release object instance.
 * 
 * Object instance is destroyed once nobody retains the object instance anymore.
 * 
 * \param[in] object Object instance to release.
 * 
 * \retval ta_c_rc_ok Object instance has been released.
 * \retval ta_c_rc_invalid_argument \em object is \em ta_object_invalid.
 * \retval ta_c_rc_* Last object instance released but failed disposing of object.
 */
extern ta_e_result_code_t ta_object_release(
	ta_object_t object );

/**
 * \brief Release object instance if object is not \em ta_object_invalid.
 * 
 * Convenience method to clean up object instance which are potentially not created
 * yet. If you use this method make sure to always initialize \em ta_object_t with
 * \em ta_object_invalid.
 * 
 * \param[in] object Object instance to release. Object instance can be \em ta_object_invalid.
 * 
 * \retval ta_c_rc_ok If object instance is not ta_object_invalid object instance
 *                    has been released.
 * \retval ta_c_rc_* Last object instance released but failed disposing of object.
 */
extern ta_e_result_code_t ta_object_release_if_valid(
	ta_object_t object );

/**
 * \brief String representation of object instance.
 * 
 * For debugging use. Object instance produces a string representing the object instance
 * content. Depending on the object instance this can be a short or long string.
 * 
 * \note Object is allowed to be \em ta_object_invalid. In this case a string with
 *       content "(null)" is produced.
 * 
 * \param[in] object Object instance to get string representation for.
 * \param[out] string Pointer to variable to write object instance to. Object instance is retained.
 * 
 * \retval ta_c_rc_ok Object instance written to \em string. Object instance has been retained.
 * \retval ta_c_rc_invalid_argument \em string is \em null-pointer.
 * \retval ta_c_rc_out_of_memory Failed allocating memory.
 */
extern ta_e_result_code_t ta_object_to_string(
	ta_object_t object,
	ta_object_t* string );


#ifdef __cplusplus
}
#endif

#endif


