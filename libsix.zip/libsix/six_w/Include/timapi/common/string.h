/**
 * \file
 * \brief String value.
 * 
 * Object type \em string.
 * 
 * String objects are 0-terminated but have an explicit length parameter.
 * 
 * String objects have no defined content encoding. They can contain any kind
 * of encoding depending from where the string object originates.
 */

#ifndef TA_STRING_H
#define TA_STRING_H

#include <stdarg.h>
#include <string.h>

#include "object.h"
#include "../constants/result_code.h"


#ifdef __cplusplus
extern "C" {
#endif


/**
 * \brief Create 0-terminated string instance.
 * 
 * String is 0-terminated but has an explicit length parameter.
 * 
 * Caller retains a reference to the created string. Different users can
 * individually retain the string instance themselves by calling
 * ta_object_retain. Each call to \ref ta_object_retain and \ref ta_string_create
 * has to be matched with a call to \ref ta_object_release. The string instance
 * is destroyed once nobody retains the string instance anymore.
 * 
 * \param[out] string Pointer to variable to write created object instance to.
 *                    Created object instance is retained.
 * \param[in] content String content. 0-bytes are allowed. String is not required
 *                    to be 0-terminated.
 * \param[in] length String length in bytes.
 * 
 * \retval ta_c_rc_ok Object instance has been created and written to \em string.
 * \retval ta_c_rc_invalid_argument \em string is \em null-pointer.
 * \retval ta_c_rc_invalid_argument \em content is \em null-pointer.
 * \retval ta_c_rc_out_of_memory Failed allocating memory.
 */
extern ta_e_result_code_t ta_string_create(
	ta_object_t *string,
	const char *content,
	size_t length );

/**
 * \brief Create 0-terminated formatted string instance.
 * 
 * String is 0-terminated but has an explicit length parameter.
 * 
 * Caller retains a reference to the created string. Different users can
 * individually retain the string instance themselves by calling
 * ta_object_retain. Each call to \ref ta_object_retain and \ref ta_string_create
 * has to be matched with a call to \ref ta_object_release. The string instance
 * is destroyed once nobody retains the string instance anymore.
 * 
 * \param[out] string Pointer to variable to write created object instance to.
 *                    Created object instance is retained.
 * \param[in] format Format string. String is required to be 0-terminated.
 * 
 * \retval ta_c_rc_ok Object instance has been created and written to \em string.
 * \retval ta_c_rc_invalid_argument \em string is \em null-pointer.
 * \retval ta_c_rc_invalid_argument \em format is \em null-pointer.
 * \retval ta_c_rc_out_of_memory Failed allocating memory.
 */
extern ta_e_result_code_t ta_string_format(
	ta_object_t *string,
	const char *format, ... )
		#ifdef __GCC__
		__attribute__ ((format (printf, 2, 3)))
		#endif
	;

/**
 * \brief Create 0-terminated formatted string instance.
 * 
 * String is 0-terminated but has an explicit length parameter.
 * 
 * Caller retains a reference to the created string. Different users can
 * individually retain the string instance themselves by calling
 * ta_object_retain. Each call to \ref ta_object_retain and \ref ta_string_create
 * has to be matched with a call to \ref ta_object_release. The string instance
 * is destroyed once nobody retains the string instance anymore.
 * 
 * \param[out] string Pointer to variable to write created object instance to.
 *                    Created object instance is retained.
 * \param[in] format Format string. String is required to be 0-terminated.
 * \param[in] args Arguments used for formatting.
 * 
 * \retval ta_c_rc_ok Object instance has been created and written to \em string.
 * \retval ta_c_rc_invalid_argument \em string is \em null-pointer.
 * \retval ta_c_rc_invalid_argument \em format is \em null-pointer.
 * \retval ta_c_rc_out_of_memory Failed allocating memory.
 */
extern ta_e_result_code_t ta_string_format_args(
	ta_object_t *string,
	const char *format,
	va_list args );

/**
 * \brief Get 0-terminated string pointer stored in the string object.
 * 
 * The returned string pointer is only valid as long as the string object
 * itself is held and not changed. Use this pointer only for short term
 * direct access to the content like copying the content to user specific
 * data structures outside the reach of Tim API.
 * 
 * \param[in] string Object instance of type [string](\ref string.h).
 * \param[out] pointer Pointer to variable to write string pointer to.
 * 
 * \retval ta_c_rc_ok Object instance written to \em pointer.
 * \retval ta_c_rc_invalid_argument \em string is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em string is not of type [string](\ref string.h).
 * \retval ta_c_rc_invalid_argument \em pointer is \em null-pointer.
 */
extern ta_e_result_code_t ta_string_get_pointer(
	ta_object_t string,
	const char **pointer );

/**
 * \brief Get length of string content in bytes.
 * 
 * \param[in] string Object instance of type [string](\ref string.h).
 * \param[out] length Pointer to variable to write string length to.
 * 
 * \retval ta_c_rc_ok Object instance written to \em length.
 * \retval ta_c_rc_invalid_argument \em string is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em string is not of type [string](\ref string.h).
 * \retval ta_c_rc_invalid_argument \em length is \em null-pointer.
 */
extern ta_e_result_code_t ta_string_get_length(
	ta_object_t string,
	size_t *length );

#ifdef __cplusplus
}
#endif

#endif
