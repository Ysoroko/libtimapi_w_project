/**
 * \file
 * \brief Config data.
 * \details Object type \em config_data.
 */

#ifndef TA_CONFIG_DATA_H
#define TA_CONFIG_DATA_H

#include "common/object.h"
#include "common/boolean.h"


#ifdef __cplusplus
extern "C" {
#endif


/**
 * \brief List of text lines forming the receipt header.
 * 
 * \param[in] config_data Object instance of type [config_data](\ref config_data.h).
 * \param[out] receipt_header Pointer to variable to write object instance to. Object instance
 *                            is of type [list](\ref list.h) and is not retained. The list contains elements
 *                            of type [string](\ref string.h).
 * 
 * \retval ta_c_rc_ok Object instance written to \em receipt_header.
 * \retval ta_c_rc_invalid_argument \em config_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em config_data is not of type [config_data](\ref config_data.h).
 * \retval ta_c_rc_invalid_argument \em receipt_header is \em null-pointer.
 */
extern ta_e_result_code_t ta_config_data_get_receipt_header(
	ta_object_t config_data,
	ta_object_t* receipt_header );

/**
 * \brief Language to use for printing receipts.
 * 
 * \param[in] config_data Object instance of type [config_data](\ref config_data.h).
 * \param[out] language Pointer to variable to write object instance to. Object instance
 *                      is of type [string](\ref string.h) and is not retained.
 * 
 * \retval ta_c_rc_ok Object instance written to \em language.
 * \retval ta_c_rc_invalid_argument \em config_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em config_data is not of type [config_data](\ref config_data.h).
 * \retval ta_c_rc_invalid_argument \em language is \em null-pointer.
 */
extern ta_e_result_code_t ta_config_data_get_language(
	ta_object_t config_data,
	ta_object_t* language );

#ifdef __cplusplus
}
#endif

#endif
