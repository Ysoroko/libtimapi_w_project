/**
 * \file
 * \brief Additional info item constant.
 */

#ifndef ADDITIONAL_INFO_ITEM_H
#define ADDITIONAL_INFO_ITEM_H


/** \brief Additional info item. */
typedef enum ta_e_additional_info_item {
	ta_c_aii_undefined = 0,
	ta_c_aii_mileage = 1,
	ta_c_aii_car_number = 2,
	ta_c_aii_driver_code = 3,
	ta_c_aii_fleet_id = 4,
	ta_c_aii_additional_information = 5,
	ta_c_aii_employee_no = 6,
	ta_c_aii_cost_center = 7,
	ta_c_aii_project_no = 8,
	ta_c_aii_license_plate = 9,
	ta_c_aii_reference = 10
} ta_e_additional_info_item_t;

#endif
