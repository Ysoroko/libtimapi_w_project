/**
 * \file constants/adjustment_result.h
 *
 * <p>Specifies if an amount adjustment notification was handled correctly. 0 for success.</p>
 * <p>This field is returned in a standard TerminalStatus notification from terminal to ECR in case
 * an AmtAdjustment notification as been sent from ECR to terminal.</p>
 * <p>The following values are valid:</p>
 *
 * Copyright: Worldline.
 */

#ifndef TA_ADJUSTMENT_RESULT_H
#define TA_ADJUSTMENT_RESULT_H


/**
 * <p><p>Specifies if an amount adjustment notification was handled correctly. 0 for success.</p>
 * <p>This field is returned in a standard TerminalStatus notification from terminal to ECR in case
 * an AmtAdjustment notification as been sent from ECR to terminal.</p>
 * <p>The following values are valid:</p></p>
 * <p>Specification: unattended.</p>
 */
typedef enum ta_e_adjustment_result{
    /**
     * Undefined/invalid value.
     */
    ta_c_ar_undefined = 0,
    
    /**
     * The amount adjustment was successful
     */
    ta_c_ar_ok = 1,
    
    /**
     * The amount adjustment failed because adjustment notification was sent to late
     */
    ta_c_ar_fail_request_to_late = 2,
    
    /**
     * The amount adjustment failed because adjusted amount is to high
     */
    ta_c_ar_fail_amount_to_high = 3
    
} ta_e_adjustment_result_t;

#endif // TA_ADJUSTMENT_RESULT_H
