/**
 * \file constants/admin_functions.h
 *
 * Flag constants for FeatureType and OptionType sixml:AdminFunctions value.
 *
 * Copyright: Worldline.
 */

#ifndef TA_ADMIN_FUNCTIONS_H
#define TA_ADMIN_FUNCTIONS_H


/**
 * <p>Flag constants for FeatureType and OptionType sixml:AdminFunctions value.</p>
 * <p>Specification: retail.</p>
 */
typedef enum ta_e_admin_functions{
    /**
     * Undefined/invalid value.
     */
    ta_c_af_undefined = 0,
    
    /**
     * <p>Login function supported.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_af_login = 1 << 0,
    
    /**
     * <p>Logout function supported.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_af_logout = 1 << 1,
    
    /**
     * <p>Reconfigurate function supported.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_af_reconfig = 1 << 2,
    
    /**
     * <p>Reboot function supported.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_af_reboot = 1 << 3,
    
    /**
     * <p>Software update function supported.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_af_software_update = 1 << 4,
    
    /**
     * <p>Activate function supported.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_af_activate = 1 << 5,
    
    /**
     * <p>Deactivate function supported.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_af_deactivate = 1 << 6,
    
    /**
     * <p>Counter request function supported.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_af_counter_request = 1 << 7,
    
    /**
     * <p>Reconciliation function supported.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_af_reconciliation = 1 << 8,
    
    /**
     * <p>Balance function supported.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_af_balance = 1 << 9,
    
    /**
     * <p>Open dialog mode function supported.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_af_open_dialog_mode = 1 << 10,
    
    /**
     * <p>Close dialog mode function supported.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_af_close_dialog_mode = 1 << 11,
    
    /**
     * <p>Transmit log function supported.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_af_transmit_log = 1 << 12,
    
    /**
     * <p>Start reader cleaning function supported. DEPRECATED DO NOT USE.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_af_start_reader_cleaning = 1 << 13,
    
    /**
     * <p>Dcc rates function supported.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_af_dcc_rates = 1 << 14,
    
    /**
     * <p>Change settings function supported.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_af_change_settings = 1 << 15,
    
    /**
     * <p>Receipt request function supported.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_af_receipt_request = 1 << 16,
    
    /**
     * <p>Close reader request function supported.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_af_close_reader = 1 << 17,
    
    /**
     * <p>Open reader request function supported.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_af_open_reader = 1 << 18,
    
    /**
     * <p>Eject card request function supported.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_af_eject_card = 1 << 19,
    
    /**
     * <p>Open maintenance window request function supported.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_af_open_maintenance_window = 1 << 20,
    
    /**
     * <p>Close maintenance window request function supported.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_af_close_maintenance_window = 1 << 21,
    
    /**
     * <p>Open service menu function supported.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_af_activate_service_menu = 1 << 22,
    
    /**
     * <p>Retreive issuer-value-combinations for MobileTopup.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_af_mobile_topup_issuer_info = 1 << 23
    
} ta_e_admin_functions_t;

#endif // TA_ADMIN_FUNCTIONS_H
