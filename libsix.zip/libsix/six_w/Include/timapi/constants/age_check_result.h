/**
 * \file constants/age_check_result.h
 *
 * Outcome of age verification.
 *
 * Copyright: Worldline.
 */

#ifndef TA_AGE_CHECK_RESULT_H
#define TA_AGE_CHECK_RESULT_H


/**
 * <p>Outcome of age verification.</p>
 * <p>Specification: retail.</p>
 */
typedef enum ta_e_age_check_result{
    /**
     * Undefined/invalid value.
     */
    ta_c_acr_undefined = 0,
    
    /**
     * OK
     */
    ta_c_acr_ok = 1,
    
    /**
     * NOK
     */
    ta_c_acr_nok = 2,
    
    /**
     * No AgeCheck performed
     */
    ta_c_acr_no_age_check_performed = 3,
    
    /**
     * Not supported by bank
     */
    ta_c_acr_not_supported_by_bank = 4
    
} ta_e_age_check_result_t;

#endif // TA_AGE_CHECK_RESULT_H
