/**
 * \file constants/brand_bar_brand.h
 *
 * Brands that can be used in the BrandBar tag.
 *
 * Copyright: Worldline.
 */

#ifndef TA_BRAND_BAR_BRAND_H
#define TA_BRAND_BAR_BRAND_H


/**
 * <p>Brands that can be used in the BrandBar tag.</p>
 * <p>Specification: dialog.</p>
 */
typedef enum ta_e_brand_bar_brand{
    /**
     * Undefined/invalid value.
     */
    ta_c_bbb_undefined = 0,
    
    /**
     * Specification: dialog.
     */
    ta_c_bbb_alipay = 1,
    
    /**
     * Specification: dialog.
     */
    ta_c_bbb_amex = 2,
    
    /**
     * Specification: dialog.
     */
    ta_c_bbb_aral_routex = 3,
    
    /**
     * Specification: dialog.
     */
    ta_c_bbb_aurora = 4,
    
    /**
     * Specification: dialog.
     */
    ta_c_bbb_austro_card = 5,
    
    /**
     * Specification: dialog.
     */
    ta_c_bbb_bancomat = 6,
    
    /**
     * Specification: dialog.
     */
    ta_c_bbb_bcmc = 7,
    
    /**
     * Specification: dialog.
     */
    ta_c_bbb_boncard_pay = 8,
    
    /**
     * Specification: dialog.
     */
    ta_c_bbb_boncard_points = 9,
    
    /**
     * Specification: dialog.
     */
    ta_c_bbb_bonus = 10,
    
    /**
     * Specification: dialog.
     */
    ta_c_bbb_bonuscard = 11,
    
    /**
     * Specification: dialog.
     */
    ta_c_bbb_bp_routex = 12,
    
    /**
     * Specification: dialog.
     */
    ta_c_bbb_brunschwig = 13,
    
    /**
     * Specification: dialog.
     */
    ta_c_bbb_business_card = 14,
    
    /**
     * Specification: dialog.
     */
    ta_c_bbb_cash = 15,
    
    /**
     * Specification: dialog.
     */
    ta_c_bbb_co2neutral_card = 16,
    
    /**
     * Specification: dialog.
     */
    ta_c_bbb_conforama = 17,
    
    /**
     * Specification: dialog.
     */
    ta_c_bbb_coop_ekz = 18,
    
    /**
     * Specification: dialog.
     */
    ta_c_bbb_coop_mobile = 19,
    
    /**
     * Specification: dialog.
     */
    ta_c_bbb_coop_pronto_card = 20,
    
    /**
     * Specification: dialog.
     */
    ta_c_bbb_cosy_card = 21,
    
    /**
     * Specification: dialog.
     */
    ta_c_bbb_cup = 22,
    
    /**
     * Specification: dialog.
     */
    ta_c_bbb_diners = 23,
    
    /**
     * Specification: dialog.
     */
    ta_c_bbb_diner_club = 24,
    
    /**
     * Specification: dialog.
     */
    ta_c_bbb_diplomatkarte = 25,
    
    /**
     * Specification: dialog.
     */
    ta_c_bbb_dkv = 26,
    
    /**
     * Specification: dialog.
     */
    ta_c_bbb_eni_routex = 27,
    
    /**
     * Specification: dialog.
     */
    ta_c_bbb_eshell_prepaid = 28,
    
    /**
     * Specification: dialog.
     */
    ta_c_bbb_esso = 29,
    
    /**
     * Specification: dialog.
     */
    ta_c_bbb_euro_shell = 30,
    
    /**
     * Specification: dialog.
     */
    ta_c_bbb_fnac = 31,
    
    /**
     * Specification: dialog.
     */
    ta_c_bbb_frei_und_flott = 32,
    
    /**
     * Specification: dialog.
     */
    ta_c_bbb_giftc = 33,
    
    /**
     * Specification: dialog.
     */
    ta_c_bbb_gift_card = 34,
    
    /**
     * Specification: dialog.
     */
    ta_c_bbb_group_card = 35,
    
    /**
     * Specification: dialog.
     */
    ta_c_bbb_ip_routex = 36,
    
    /**
     * Specification: dialog.
     */
    ta_c_bbb_iq = 37,
    
    /**
     * Specification: dialog.
     */
    ta_c_bbb_jcb = 38,
    
    /**
     * Specification: dialog.
     */
    ta_c_bbb_jelmoli_paycard = 39,
    
    /**
     * Specification: dialog.
     */
    ta_c_bbb_jet = 40,
    
    /**
     * Specification: dialog.
     */
    ta_c_bbb_jgeschenkkarte = 41,
    
    /**
     * Specification: dialog.
     */
    ta_c_bbb_jubin_card_petrol = 42,
    
    /**
     * Specification: dialog.
     */
    ta_c_bbb_lebara = 43,
    
    /**
     * Specification: dialog.
     */
    ta_c_bbb_loeb = 44,
    
    /**
     * Specification: dialog.
     */
    ta_c_bbb_log_pay = 45,
    
    /**
     * Specification: dialog.
     */
    ta_c_bbb_lunch_check_card = 46,
    
    /**
     * Specification: dialog.
     */
    ta_c_bbb_lyca_mobile = 47,
    
    /**
     * Specification: dialog.
     */
    ta_c_bbb_maestro = 48,
    
    /**
     * Specification: dialog.
     */
    ta_c_bbb_maestro_ch = 49,
    
    /**
     * Specification: dialog.
     */
    ta_c_bbb_master_card = 50,
    
    /**
     * Specification: dialog.
     */
    ta_c_bbb_mbudget_mc = 51,
    
    /**
     * Specification: dialog.
     */
    ta_c_bbb_mcard = 52,
    
    /**
     * Specification: dialog.
     */
    ta_c_bbb_media_markt = 53,
    
    /**
     * Specification: dialog.
     */
    ta_c_bbb_merger_card = 54,
    
    /**
     * Specification: dialog.
     */
    ta_c_bbb_migrolcard = 55,
    
    /**
     * Specification: dialog.
     */
    ta_c_bbb_migros = 56,
    
    /**
     * Specification: dialog.
     */
    ta_c_bbb_moveri = 57,
    
    /**
     * Specification: dialog.
     */
    ta_c_bbb_mscompany_card = 58,
    
    /**
     * Specification: dialog.
     */
    ta_c_bbb_my_one = 59,
    
    /**
     * Specification: dialog.
     */
    ta_c_bbb_novofleet = 60,
    
    /**
     * Specification: dialog.
     */
    ta_c_bbb_omv_routex = 61,
    
    /**
     * Specification: dialog.
     */
    ta_c_bbb_paycard = 62,
    
    /**
     * Specification: dialog.
     */
    ta_c_bbb_paycard_f = 63,
    
    /**
     * Specification: dialog.
     */
    ta_c_bbb_paycard_app = 64,
    
    /**
     * Specification: dialog.
     */
    ta_c_bbb_pay_pal = 65,
    
    /**
     * Specification: dialog.
     */
    ta_c_bbb_pay_sys_giftcard = 66,
    
    /**
     * Specification: dialog.
     */
    ta_c_bbb_pharmacard = 67,
    
    /**
     * Specification: dialog.
     */
    ta_c_bbb_phonecard = 68,
    
    /**
     * Specification: dialog.
     */
    ta_c_bbb_post_card = 69,
    
    /**
     * Specification: dialog.
     */
    ta_c_bbb_power_card = 70,
    
    /**
     * Specification: dialog.
     */
    ta_c_bbb_reka = 71,
    
    /**
     * Specification: dialog.
     */
    ta_c_bbb_reka_lunch = 72,
    
    /**
     * Specification: dialog.
     */
    ta_c_bbb_reka_rail = 73,
    
    /**
     * Specification: dialog.
     */
    ta_c_bbb_salt = 74,
    
    /**
     * Specification: dialog.
     */
    ta_c_bbb_sbbkarte = 75,
    
    /**
     * Specification: dialog.
     */
    ta_c_bbb_shell_mca = 76,
    
    /**
     * Specification: dialog.
     */
    ta_c_bbb_staedtekarte = 77,
    
    /**
     * Specification: dialog.
     */
    ta_c_bbb_statoil_routex = 78,
    
    /**
     * Specification: dialog.
     */
    ta_c_bbb_sunrise = 79,
    
    /**
     * Specification: dialog.
     */
    ta_c_bbb_supercard_plus = 80,
    
    /**
     * Specification: dialog.
     */
    ta_c_bbb_supercard_visa = 81,
    
    /**
     * Specification: dialog.
     */
    ta_c_bbb_swiss_bonus_card = 82,
    
    /**
     * Specification: dialog.
     */
    ta_c_bbb_swisscom = 83,
    
    /**
     * Specification: dialog.
     */
    ta_c_bbb_twint = 84,
    
    /**
     * Specification: dialog.
     */
    ta_c_bbb_uta_full_service = 85,
    
    /**
     * Specification: dialog.
     */
    ta_c_bbb_uta_select_card = 86,
    
    /**
     * Specification: dialog.
     */
    ta_c_bbb_valuemaster = 87,
    
    /**
     * Specification: dialog.
     */
    ta_c_bbb_visa = 88,
    
    /**
     * Specification: dialog.
     */
    ta_c_bbb_visa_electron = 89,
    
    /**
     * Specification: dialog.
     */
    ta_c_bbb_vorteils_card = 90,
    
    /**
     * Specification: dialog.
     */
    ta_c_bbb_vpay = 91,
    
    /**
     * Specification: dialog.
     */
    ta_c_bbb_we_chat = 92,
    
    /**
     * Specification: dialog.
     */
    ta_c_bbb_wir_card = 93,
    
    /**
     * Specification: dialog.
     */
    ta_c_bbb_yallo = 94
    
} ta_e_brand_bar_brand_t;

#endif // TA_BRAND_BAR_BRAND_H
