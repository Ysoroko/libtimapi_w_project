/**
 * \file constants/card_product_type.h
 *
 * <p>Gives the type of card product if this can be determined (e.g. from ASRPD).</p>
 * <p>The following values are valid:</p>
 *
 * Copyright: Worldline.
 */

#ifndef TA_CARD_PRODUCT_TYPE_H
#define TA_CARD_PRODUCT_TYPE_H


/**
 * <p><p>Gives the type of card product if this can be determined (e.g. from ASRPD).</p>
 * <p>The following values are valid:</p></p>
 * <p>Specification: retail.</p>
 */
typedef enum ta_e_card_product_type{
    /**
     * Undefined/invalid value.
     */
    ta_c_cpt_undefined = 0,
    
    /**
     * <p>The card is a debit product</p>
     * <p>Specification: retail.</p>
     */
    ta_c_cpt_debit = 1,
    
    /**
     * <p>The card is a credit product</p>
     * <p>Specification: retail.</p>
     */
    ta_c_cpt_credit = 2,
    
    /**
     * <p>The card is a commercial product</p>
     * <p>Specification: retail.</p>
     */
    ta_c_cpt_commercial = 3,
    
    /**
     * <p>The card is a pre-paid product</p>
     * <p>Specification: retail.</p>
     */
    ta_c_cpt_prepaid = 4
    
} ta_e_card_product_type_t;

#endif // TA_CARD_PRODUCT_TYPE_H
