/**
 * \file constants/card_reader_status.h
 *
 * <p>The CardReaderStatus tag is used to transport information about the current card reader
 * activity.</p>
 * <p>The following values are valid:</p>
 *
 * Copyright: Worldline.
 */

#ifndef TA_CARD_READER_STATUS_H
#define TA_CARD_READER_STATUS_H


/**
 * <p><p>The CardReaderStatus tag is used to transport information about the current card reader
 * activity.</p>
 * <p>The following values are valid:</p></p>
 * <p>Specification: retail.</p>
 */
typedef enum ta_e_card_reader_status{
    /**
     * Undefined/invalid value.
     */
    ta_c_crs_undefined = 0,
    
    /**
     * <p>The shutter of the card reader is closed. No cards can be inserted.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_crs_card_reader_closed = 1,
    
    /**
     * <p>Card information has been manually entered. Valid for Manual-Pan-Key.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_crs_card_manually_entered = 2,
    
    /**
     * <p>Card has been swiped. Valid for Mag-Stripe.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_crs_card_swiped = 3,
    
    /**
     * <p>Card has not been removed by the cardholder despite being prompted to do so (timeout: 15s).
     * Valid for ICC.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_crs_card_not_removed = 4,
    
    /**
     * <p>Contactless card has been presented. Only for ICC contactless transactions. Valid for
     * Contactless.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_crs_card_presented = 5,
    
    /**
     * <p>The card reader is empty and accepts cards.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_crs_card_reader_empty = 6,
    
    /**
     * <p>Card in the chip reader.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_crs_card_inserted = 7,
    
    /**
     * <p>Card has been ejected by the application.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_crs_card_ejected = 8
    
} ta_e_card_reader_status_t;

#endif // TA_CARD_READER_STATUS_H
