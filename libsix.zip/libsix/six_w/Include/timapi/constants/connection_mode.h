/**
 * \file
 * \brief Connection mode constant.
 */

#ifndef CONNECTION_MODE_H
#define CONNECTION_MODE_H


/** \brief Connection mode. */
typedef enum ta_e_connection_mode {
	/**
	 * \brief ECR and EFT Terminal exchange connection parameters using broadcasting before connecting.
	 */
	ta_c_cm_broadcast = 0,
	
	/**
	 * \brief ECR and EFT Terminal connect directly using pre-configured connection parameters.
	 */
	ta_c_cm_on_fix_ip = 1,
	
	/**
	 * \brief Using only Saferpay. No ECR attached.
	 */
	ta_c_cm_none = 2
} ta_e_connection_mode_t;

#endif
