/**
 * \file constants/connection_status.h
 *
 * <p>The sixml:ConnectionStatus tag is used to transport information about the current connection
 * between the ECR and the terminal.</p>
 * <p>All status information tags always contain the current status of the terminal, not the
 * ECR.</p>
 * <p>The following values are valid:</p>
 *
 * Copyright: Worldline.
 */

#ifndef TA_CONNECTION_STATUS_H
#define TA_CONNECTION_STATUS_H


/**
 * <p><p>The sixml:ConnectionStatus tag is used to transport information about the current connection
 * between the ECR and the terminal.</p>
 * <p>All status information tags always contain the current status of the terminal, not the
 * ECR.</p>
 * <p>The following values are valid:</p></p>
 * <p>Specification: retail.</p>
 */
typedef enum ta_e_connection_status{
    /**
     * Undefined/invalid value.
     */
    ta_c_cs_undefined = 0,
    
    /**
     * Specification: retail.
     */
    ta_c_cs_disconnected = 1,
    
    /**
     * Specification: retail.
     */
    ta_c_cs_logged_out = 2,
    
    /**
     * Specification: retail.
     */
    ta_c_cs_logged_in = 3
    
} ta_e_connection_status_t;

#endif // TA_CONNECTION_STATUS_H
