/**
 * \file constants/counter_type.h
 *
 * <p>Identifies the type of transaction counter.</p>
 * <p>This type identifier is used to define what kind of counters shall be returned in the
 * "CounterRequest" response.</p>
 * <p>The following values are valid:</p>
 *
 * Copyright: Worldline.
 */

#ifndef TA_COUNTER_TYPE_H
#define TA_COUNTER_TYPE_H


/**
 * <p><p>Identifies the type of transaction counter.</p>
 * <p>This type identifier is used to define what kind of counters shall be returned in the
 * "CounterRequest" response.</p>
 * <p>The following values are valid:</p></p>
 * <p>Specification: retail.</p>
 */
typedef enum ta_e_counter_type{
    /**
     * Undefined/invalid value.
     */
    ta_c_cntt_undefined = 0,
    
    /**
     * <p>Shift counters.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_cntt_shift = 1,
    
    /**
     * <p>Final balance / Daily closing counters.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_cntt_balance = 2
    
} ta_e_counter_type_t;

#endif // TA_COUNTER_TYPE_H
