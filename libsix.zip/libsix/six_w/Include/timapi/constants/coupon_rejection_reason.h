/**
 * \file constants/coupon_rejection_reason.h
 *
 * <p>Defines why a coupon has been rejected.</p>
 * <p>The following values are valid:</p>
 *
 * Copyright: Worldline.
 */

#ifndef TA_COUPON_REJECTION_REASON_H
#define TA_COUPON_REJECTION_REASON_H


/**
 * <p><p>Defines why a coupon has been rejected.</p>
 * <p>The following values are valid:</p></p>
 * <p>Specification: valueAddedServices.</p>
 */
typedef enum ta_e_coupon_rejection_reason{
    /**
     * Undefined/invalid value.
     */
    ta_c_crr_undefined = 0,
    
    /**
     * <p>Already redeemed</p>
     * <p>Specification: valueAddedServices.</p>
     */
    ta_c_crr_already_redeemed = 1,
    
    /**
     * <p>Article delisted.</p>
     * <p>Specification: valueAddedServices.</p>
     */
    ta_c_crr_article_delisted = 2,
    
    /**
     * <p>Campaign expired.</p>
     * <p>Specification: valueAddedServices.</p>
     */
    ta_c_crr_campaign_expired = 3,
    
    /**
     * <p>Campaig cancelled.</p>
     * <p>Specification: valueAddedServices.</p>
     */
    ta_c_crr_campaign_cancelled = 4,
    
    /**
     * <p>Other rejection reason.</p>
     * <p>Specification: valueAddedServices.</p>
     */
    ta_c_crr_other = 5
    
} ta_e_coupon_rejection_reason_t;

#endif // TA_COUPON_REJECTION_REASON_H
