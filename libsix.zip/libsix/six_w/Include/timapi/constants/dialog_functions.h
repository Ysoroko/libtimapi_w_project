/**
 * \file constants/dialog_functions.h
 *
 * Flag constants for FeatureType and OptionType sixml:DialogFunctions value.
 *
 * Copyright: Worldline.
 */

#ifndef TA_DIALOG_FUNCTIONS_H
#define TA_DIALOG_FUNCTIONS_H


/**
 * <p>Flag constants for FeatureType and OptionType sixml:DialogFunctions value.</p>
 * <p>Specification: retail.</p>
 */
typedef enum ta_e_dialog_functions{
    /**
     * Undefined/invalid value.
     */
    ta_c_df_undefined = 0,
    
    /**
     * <p>Show signature capture function supported.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_df_show_signature_capture = 1 << 0,
    
    /**
     * <p>Show dialog function supported.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_df_show_dialog = 1 << 1,
    
    /**
     * <p>Send card command function supported.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_df_send_card_command = 1 << 2,
    
    /**
     * <p>Print on terminal function supported.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_df_print_on_terminal = 1 << 3
    
} ta_e_dialog_functions_t;

#endif // TA_DIALOG_FUNCTIONS_H
