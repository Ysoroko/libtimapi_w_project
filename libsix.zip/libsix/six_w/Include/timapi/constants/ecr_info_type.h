/**
 * \file constants/ecr_info_type.h
 *
 * <p>The EcrInfoType attribute is used to specify what kind of information is sent in the
 * sixml:EcrInfo tag.</p>
 * <p>The following values are valid:</p>
 *
 * Copyright: Worldline.
 */

#ifndef TA_ECR_INFO_TYPE_H
#define TA_ECR_INFO_TYPE_H


/**
 * <p><p>The EcrInfoType attribute is used to specify what kind of information is sent in the
 * sixml:EcrInfo tag.</p>
 * <p>The following values are valid:</p></p>
 * <p>Specification: retail.</p>
 */
typedef enum ta_e_ecr_info_type{
    /**
     * Undefined/invalid value.
     */
    ta_c_eit_undefined = 0,
    
    /**
     * Specification: retail.
     */
    ta_c_eit_os = 1,
    
    /**
     * Specification: retail.
     */
    ta_c_eit_ecr_application = 2,
    
    /**
     * Specification: retail.
     */
    ta_c_eit_eft_api = 3,
    
    /**
     * Specification: retail.
     */
    ta_c_eit_eft_module = 4
    
} ta_e_ecr_info_type_t;

#endif // TA_ECR_INFO_TYPE_H
