/**
 * \file constants/enum_string_maps/connection_status.h
 *
 * \warning This file is generated. Do not edit.
 *
 * Copyright: Worldline.
 */

#ifndef TA_CONNECTION_STATUS_ENUM_STRING_MAP_H
#define TA_CONNECTION_STATUS_ENUM_STRING_MAP_H

#include "../connection_status.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * Get String for Enum value.
 * 
 * \param[in] value Enum value to get string for
 * 
 * \returns String value.
 */
extern const char * ta_connection_status_e2s(ta_e_connection_status_t value);
#ifdef __cplusplus
}
#endif

#endif // TA_CONNECTION_STATUS_ENUM_STRING_MAP_H
