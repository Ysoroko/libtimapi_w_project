/**
 * \file constants/enum_string_maps/customer_data_type.h
 *
 * \warning This file is generated. Do not edit.
 *
 * Copyright: Worldline.
 */

#ifndef TA_CUSTOMER_DATA_TYPE_ENUM_STRING_MAP_H
#define TA_CUSTOMER_DATA_TYPE_ENUM_STRING_MAP_H

#include "../customer_data_type.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * Get String for Enum value.
 * 
 * \param[in] value Enum value to get string for
 * 
 * \returns String value.
 */
extern const char * ta_customer_data_type_e2s(ta_e_customer_data_type_t value);
#ifdef __cplusplus
}
#endif

#endif // TA_CUSTOMER_DATA_TYPE_ENUM_STRING_MAP_H
