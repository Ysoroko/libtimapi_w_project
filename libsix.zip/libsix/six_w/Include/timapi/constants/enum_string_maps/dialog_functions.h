/**
 * \file constants/enum_string_maps/dialog_functions.h
 *
 * \warning This file is generated. Do not edit.
 *
 * Copyright: Worldline.
 */

#ifndef TA_DIALOG_FUNCTIONS_ENUM_STRING_MAP_H
#define TA_DIALOG_FUNCTIONS_ENUM_STRING_MAP_H

#include "../dialog_functions.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * Get String for Enum value.
 * 
 * \param[in] value Enum value to get string for
 * 
 * \returns String value.
 */
extern const char * ta_dialog_functions_e2s(int value);
#ifdef __cplusplus
}
#endif

#endif // TA_DIALOG_FUNCTIONS_ENUM_STRING_MAP_H
