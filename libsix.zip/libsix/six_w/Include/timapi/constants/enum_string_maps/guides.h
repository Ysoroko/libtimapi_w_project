/**
 * \file constants/enum_string_maps/guides.h
 *
 * \warning This file is generated. Do not edit.
 *
 * Copyright: Worldline.
 */

#ifndef TA_GUIDES_ENUM_STRING_MAP_H
#define TA_GUIDES_ENUM_STRING_MAP_H

#include "../guides.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * Get String for Enum value.
 * 
 * \param[in] value Enum value to get string for
 * 
 * \returns String value.
 */
extern const char * ta_guides_e2s(int value);
#ifdef __cplusplus
}
#endif

#endif // TA_GUIDES_ENUM_STRING_MAP_H
