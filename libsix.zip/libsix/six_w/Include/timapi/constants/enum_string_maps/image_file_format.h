/**
 * \file constants/enum_string_maps/image_file_format.h
 *
 * \warning This file is generated. Do not edit.
 *
 * Copyright: Worldline.
 */

#ifndef TA_IMAGE_FILE_FORMAT_ENUM_STRING_MAP_H
#define TA_IMAGE_FILE_FORMAT_ENUM_STRING_MAP_H

#include "../image_file_format.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * Get String for Enum value.
 * 
 * \param[in] value Enum value to get string for
 * 
 * \returns String value.
 */
extern const char * ta_image_file_format_e2s(ta_e_image_file_format_t value);
#ifdef __cplusplus
}
#endif

#endif // TA_IMAGE_FILE_FORMAT_ENUM_STRING_MAP_H
