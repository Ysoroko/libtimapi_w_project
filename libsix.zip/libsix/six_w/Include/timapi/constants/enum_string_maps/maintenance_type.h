/**
 * \file constants/enum_string_maps/maintenance_type.h
 *
 * \warning This file is generated. Do not edit.
 *
 * Copyright: Worldline.
 */

#ifndef TA_MAINTENANCE_TYPE_ENUM_STRING_MAP_H
#define TA_MAINTENANCE_TYPE_ENUM_STRING_MAP_H

#include "../maintenance_type.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * Get String for Enum value.
 * 
 * \param[in] value Enum value to get string for
 * 
 * \returns String value.
 */
extern const char * ta_maintenance_type_e2s(ta_e_maintenance_type_t value);
#ifdef __cplusplus
}
#endif

#endif // TA_MAINTENANCE_TYPE_ENUM_STRING_MAP_H
