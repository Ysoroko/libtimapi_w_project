/**
 * \file constants/enum_string_maps/merchant_option_type.h
 *
 * \warning This file is generated. Do not edit.
 *
 * Copyright: Worldline.
 */

#ifndef TA_MERCHANT_OPTION_TYPE_ENUM_STRING_MAP_H
#define TA_MERCHANT_OPTION_TYPE_ENUM_STRING_MAP_H

#include "../merchant_option_type.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * Get String for Enum value.
 * 
 * \param[in] value Enum value to get string for
 * 
 * \returns String value.
 */
extern const char * ta_merchant_option_type_e2s(ta_e_merchant_option_type_t value);
#ifdef __cplusplus
}
#endif

#endif // TA_MERCHANT_OPTION_TYPE_ENUM_STRING_MAP_H
