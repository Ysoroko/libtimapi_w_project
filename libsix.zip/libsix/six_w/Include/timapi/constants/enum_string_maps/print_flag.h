/**
 * \file constants/enum_string_maps/print_flag.h
 *
 * \warning This file is generated. Do not edit.
 *
 * Copyright: Worldline.
 */

#ifndef TA_PRINT_FLAG_ENUM_STRING_MAP_H
#define TA_PRINT_FLAG_ENUM_STRING_MAP_H

#include "../print_flag.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * Get String for Enum value.
 * 
 * \param[in] value Enum value to get string for
 * 
 * \returns String value.
 */
extern const char * ta_print_flag_e2s(int value);
#ifdef __cplusplus
}
#endif

#endif // TA_PRINT_FLAG_ENUM_STRING_MAP_H
