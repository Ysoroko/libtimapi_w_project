/**
 * \file constants/enum_string_maps/recipient.h
 *
 * \warning This file is generated. Do not edit.
 *
 * Copyright: Worldline.
 */

#ifndef TA_RECIPIENT_ENUM_STRING_MAP_H
#define TA_RECIPIENT_ENUM_STRING_MAP_H

#include "../recipient.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * Get String for Enum value.
 * 
 * \param[in] value Enum value to get string for
 * 
 * \returns String value.
 */
extern const char * ta_recipient_e2s(ta_e_recipient_t value);
#ifdef __cplusplus
}
#endif

#endif // TA_RECIPIENT_ENUM_STRING_MAP_H
