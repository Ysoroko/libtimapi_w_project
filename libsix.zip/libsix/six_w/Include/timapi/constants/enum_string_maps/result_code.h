/**
 * \file constants/enum_string_maps/result_code.h
 *
 * \warning This file is generated. Do not edit.
 *
 * Copyright: Worldline.
 */

#ifndef TA_RESULT_CODE_ENUM_STRING_MAP_H
#define TA_RESULT_CODE_ENUM_STRING_MAP_H

#include "../result_code.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * Get String for Enum value.
 * 
 * \param[in] value Enum value to get string for
 * 
 * \returns String value.
 */
extern const char * ta_result_code_e2s(ta_e_result_code_t value);
#ifdef __cplusplus
}
#endif

#endif // TA_RESULT_CODE_ENUM_STRING_MAP_H
