/**
 * \file constants/enum_string_maps/sleep_mode_status.h
 *
 * \warning This file is generated. Do not edit.
 *
 * Copyright: Worldline.
 */

#ifndef TA_SLEEP_MODE_STATUS_ENUM_STRING_MAP_H
#define TA_SLEEP_MODE_STATUS_ENUM_STRING_MAP_H

#include "../sleep_mode_status.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * Get String for Enum value.
 * 
 * \param[in] value Enum value to get string for
 * 
 * \returns String value.
 */
extern const char * ta_sleep_mode_status_e2s(ta_e_sleep_mode_status_t value);
#ifdef __cplusplus
}
#endif

#endif // TA_SLEEP_MODE_STATUS_ENUM_STRING_MAP_H
