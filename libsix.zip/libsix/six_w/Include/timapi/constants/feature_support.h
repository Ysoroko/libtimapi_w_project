/**
 * \file constants/feature_support.h
 *
 *
 * Copyright: Worldline.
 */


#ifndef TA_FEATURE_SUPPORT_H
#define TA_FEATURE_SUPPORT_H


/** 
 * \brief Feature support. 
 */
typedef enum ta_e_feature_support {
	/** \brief Feature is not supported. */
	ta_c_fs_disabled = 0,
	
	/** \brief Feature is supported but not mandatory. */
	ta_c_fs_supported = 1,
	
	/** \brief Feature is supported and mandatory. */
	ta_c_fs_mandatory = 2
} ta_e_feature_support_t;

#endif // TA_FEATURE_SUPPORT_H
