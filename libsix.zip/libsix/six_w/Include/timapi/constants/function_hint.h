/**
 * \file constants/function_hint.h
 *
 * <p>Hint to the subsequent Finacial Transaction Function that will be called in the
 * “WaitForProceed”-state following an InitTransaction.</p>
 * <p>The value shall be used to initialize the contact less kernels and to determine if a certain
 * POS entry mode is even possible. The ECR is allowed to not follow this indication and send
 * another transaction type. This may lead the terminal application to do require a double tap or
 * even terminate the transaction.</p>
 * <p>The following values area valid:</p>
 *
 * Copyright: Worldline.
 */

#ifndef TA_FUNCTION_HINT_H
#define TA_FUNCTION_HINT_H


/**
 * <p><p>Hint to the subsequent Finacial Transaction Function that will be called in the
 * “WaitForProceed”-state following an InitTransaction.</p>
 * <p>The value shall be used to initialize the contact less kernels and to determine if a certain
 * POS entry mode is even possible. The ECR is allowed to not follow this indication and send
 * another transaction type. This may lead the terminal application to do require a double tap or
 * even terminate the transaction.</p>
 * <p>The following values area valid:</p></p>
 * <p>Guides: petrol, advancedRetail, banking, hospitality, valueAddedServices.</p>
 */
typedef enum ta_e_function_hint{
    /**
     * Undefined/invalid value.
     */
    ta_c_fh_undefined = 0,
    
    /**
     * <p>Purchase function.</p>
     * <p>Specification: petrol.</p>
     */
    ta_c_fh_purchase = 1,
    
    /**
     * <p>Credit function.</p>
     * <p>Specification: petrol.</p>
     */
    ta_c_fh_credit = 2,
    
    /**
     * <p>Reversal function.</p>
     * <p>Specification: petrol.</p>
     */
    ta_c_fh_reversal = 3,
    
    /**
     * <p>PreAuthorization function.</p>
     * <p>Specification: petrol.</p>
     */
    ta_c_fh_pre_authorization = 4,
    
    /**
     * <p>Finalize purchase / Online advice function.</p>
     * <p>Specification: petrol.</p>
     */
    ta_c_fh_finalize_purchase = 5,
    
    /**
     * <p>Cash advance function.</p>
     * <p>Specification: advancedRetail.</p>
     */
    ta_c_fh_cash_advance = 6,
    
    /**
     * <p>Purchase function with forced acceptance.</p>
     * <p>Specification: advancedRetail.</p>
     */
    ta_c_fh_purchase_forced_acceptance = 7,
    
    /**
     * <p>Purchase function with cashback amount.</p>
     * <p>Specification: advancedRetail.</p>
     */
    ta_c_fh_purchase_with_cashback = 8,
    
    /**
     * <p>Purchase function phone authorized.</p>
     * <p>Specification: advancedRetail.</p>
     */
    ta_c_fh_purchase_phone_authorized = 9,
    
    /**
     * <p>Purchase function phone ordered.</p>
     * <p>Specification: advancedRetail.</p>
     */
    ta_c_fh_purchase_phone_ordered = 10,
    
    /**
     * <p>Purchase function mail ordered.</p>
     * <p>Specification: advancedRetail.</p>
     */
    ta_c_fh_purchase_mail_ordered = 11,
    
    /**
     * <p>Giro function.</p>
     * <p>Specification: banking.</p>
     */
    ta_c_fh_giro = 12,
    
    /**
     * <p>Combined function.</p>
     * <p>Specification: banking.</p>
     */
    ta_c_fh_combined = 13,
    
    /**
     * <p>Authorize credit function.</p>
     * <p>Specification: banking.</p>
     */
    ta_c_fh_authorize_credit = 14,
    
    /**
     * <p>Authorize deposit function.</p>
     * <p>Specification: banking.</p>
     */
    ta_c_fh_authorize_deposit = 15,
    
    /**
     * <p>Reservation function.</p>
     * <p>Specification: hospitality.</p>
     */
    ta_c_fh_reservation = 16,
    
    /**
     * <p>Load Voucher function.</p>
     * <p>Specification: valueAddedServices.</p>
     */
    ta_c_fh_load_voucher = 17,
    
    /**
     * <p>Collect Points function.</p>
     * <p>Specification: valueAddedServices.</p>
     */
    ta_c_fh_collect_points = 18
    
} ta_e_function_hint_t;

#endif // TA_FUNCTION_HINT_H
