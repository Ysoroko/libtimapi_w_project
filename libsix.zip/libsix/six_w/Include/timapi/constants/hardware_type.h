/**
 * \file constants/hardware_type.h
 *
 * <p>HardwareTypes are used to label hardware related data in the HardwareInformation response.</p>
 * <p>The following values are valid:</p>
 *
 * Copyright: Worldline.
 */

#ifndef TA_HARDWARE_TYPE_H
#define TA_HARDWARE_TYPE_H


/**
 * <p><p>HardwareTypes are used to label hardware related data in the HardwareInformation response.</p>
 * <p>The following values are valid:</p></p>
 * <p>Specification: retail.</p>
 */
typedef enum ta_e_hardware_type{
    /**
     * Undefined/invalid value.
     */
    ta_c_ht_undefined = 0,
    
    /**
     * <p>Terminal device related, not the secure part.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_ht_terminal = 1,
    
    /**
     * <p>Software that runs on the terminal.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_ht_eft_application = 2,
    
    /**
     * <p>Secure part of the terminal.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_ht_pin_pad = 3,
    
    /**
     * <p>Contact ICC reader.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_ht_contact_reader = 4,
    
    /**
     * <p>Contactless card reader.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_ht_contactless_reader = 5,
    
    /**
     * <p>Magnetic stripe reader.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_ht_mag_stripe_reader = 6,
    
    /**
     * <p>Wireless LAN Network Device</p>
     * <p>Specification: retail.</p>
     */
    ta_c_ht_wifi_adapter = 7,
    
    /**
     * <p>Wired LAN Network Device</p>
     * <p>Specification: retail.</p>
     */
    ta_c_ht_lan_adapter = 8,
    
    /**
     * <p>Bluetooth Device</p>
     * <p>Specification: retail.</p>
     */
    ta_c_ht_bluetooth_adapter = 9,
    
    /**
     * <p>Mobile Network Device</p>
     * <p>Specification: retail.</p>
     */
    ta_c_ht_mobile_adapter = 10
    
} ta_e_hardware_type_t;

#endif // TA_HARDWARE_TYPE_H
