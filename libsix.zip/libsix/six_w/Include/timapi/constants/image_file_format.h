/**
 * \file constants/image_file_format.h
 *
 * <p>Defines the file format of the signature image.</p>
 * <p>This field can either be used as attribute in the <sixml:SignatureData> tag to define the file
 * format of the signature image that is wished to be returned, or in the
 * <sixml:SignatureInformation> to specify the file format of the signature image that has actually
 * been returned from the terminal.</p>
 * <p>The following values are valid:</p>
 *
 * Copyright: Worldline.
 */

#ifndef TA_IMAGE_FILE_FORMAT_H
#define TA_IMAGE_FILE_FORMAT_H


/**
 * <p><p>Defines the file format of the signature image.</p>
 * <p>This field can either be used as attribute in the <sixml:SignatureData> tag to define the file
 * format of the signature image that is wished to be returned, or in the
 * <sixml:SignatureInformation> to specify the file format of the signature image that has actually
 * been returned from the terminal.</p>
 * <p>The following values are valid:</p></p>
 * <p>Specification: retail.</p>
 */
typedef enum ta_e_image_file_format{
    /**
     * Undefined/invalid value.
     */
    ta_c_iff_undefined = 0,
    
    /**
     * <p>JPEG format.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_iff_jpeg = 1,
    
    /**
     * <p>PNG format.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_iff_png = 2,
    
    /**
     * <p>BMP format.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_iff_bmp = 3
    
} ta_e_image_file_format_t;

#endif // TA_IMAGE_FILE_FORMAT_H
