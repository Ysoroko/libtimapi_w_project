/**
 * \file constants/kernel_type.h
 *
 * <p>Enumeration that specifies the type of kernel.</p>
 * <p>This field is used as attribute of the <sixml:KernelVersion> tag to specify the type of the
 * kernel accoring to EMV.</p>
 * <p>The following values are valid:</p>
 *
 * Copyright: Worldline.
 */

#ifndef TA_KERNEL_TYPE_H
#define TA_KERNEL_TYPE_H


/**
 * <p><p>Enumeration that specifies the type of kernel.</p>
 * <p>This field is used as attribute of the <sixml:KernelVersion> tag to specify the type of the
 * kernel accoring to EMV.</p>
 * <p>The following values are valid:</p></p>
 * <p>Specification: retail.</p>
 */
typedef enum ta_e_kernel_type{
    /**
     * Undefined/invalid value.
     */
    ta_c_kt_undefined = 0,
    
    /**
     * Gemalto PURE Contactless Kernel
     */
    ta_c_kt_kernel_pure = 1,
    
    /**
     * EMV Contact kernel.
     */
    ta_c_kt_emv_contact = 2,
    
    /**
     * EMV Contactless Entrypoint.
     */
    ta_c_kt_entry_point = 3,
    
    /**
     * EMV Contactless kernel number according to kernel numbering as defined by EMV contactless
     * Book A [B35].
     */
    ta_c_kt_kernel1 = 4,
    
    /**
     * EMV Contactless kernel number according to kernel numbering as defined by EMV contactless
     * Book A [B35].
     */
    ta_c_kt_kernel2 = 5,
    
    /**
     * EMV Contactless kernel number according to kernel numbering as defined by EMV contactless
     * Book A [B35].
     */
    ta_c_kt_kernel3 = 6,
    
    /**
     * EMV Contactless kernel number according to kernel numbering as defined by EMV contactless
     * Book A [B35].
     */
    ta_c_kt_kernel4 = 7,
    
    /**
     * EMV Contactless kernel number according to kernel numbering as defined by EMV contactless
     * Book A [B35].
     */
    ta_c_kt_kernel5 = 8,
    
    /**
     * EMV Contactless kernel number according to kernel numbering as defined by EMV contactless
     * Book A [B35].
     */
    ta_c_kt_kernel6 = 9,
    
    /**
     * EMV Contactless kernel number according to kernel numbering as defined by EMV contactless
     * Book A [B35].
     */
    ta_c_kt_kernel7 = 10
    
} ta_e_kernel_type_t;

#endif // TA_KERNEL_TYPE_H
