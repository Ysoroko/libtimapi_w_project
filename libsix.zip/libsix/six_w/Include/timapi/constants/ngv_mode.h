/**
 * \file constants/ngv_mode.h
 *
 * <p>Defines if NGV usage is mandatory or optional if card supports it.</p>
 * <p>This field can be set in a purchase transaction request to define the NGV behaviour for the
 * current transaction.</p>
 * <p>Example: NGV purchase transaction with one day clearing delay: <sixml:TransactionData
 * NGVMode='AllowedWithFallback' NGVClearingDelay='1' ... /></p>
 * <p>The following values are valid:</p>
 *
 * Copyright: Worldline.
 */

#ifndef TA_NGV_MODE_H
#define TA_NGV_MODE_H


/**
 * <p><p>Defines if NGV usage is mandatory or optional if card supports it.</p>
 * <p>This field can be set in a purchase transaction request to define the NGV behaviour for the
 * current transaction.</p>
 * <p>Example: NGV purchase transaction with one day clearing delay: <sixml:TransactionData
 * NGVMode='AllowedWithFallback' NGVClearingDelay='1' ... /></p>
 * <p>The following values are valid:</p></p>
 * <p>Specification: austrianUseCases.</p>
 */
typedef enum ta_e_ngv_mode{
    /**
     * Undefined/invalid value.
     */
    ta_c_ngvm_undefined = 0,
    
    /**
     * <p>NGV is mandatory, no fallback to standard purchase allowed.</p>
     * <p>Specification: austrianUseCases.</p>
     */
    ta_c_ngvm_mandatory = 1,
    
    /**
     * <p>NGV shall be performed if card supports it, fallback to standard purchase allowed. (Default)</p>
     * <p>Specification: austrianUseCases.</p>
     */
    ta_c_ngvm_allowed_with_fallback = 2,
    
    /**
     * <p>NGV not allowed.</p>
     * <p>Specification: austrianUseCases.</p>
     */
    ta_c_ngvm_not_allowed = 3
    
} ta_e_ngv_mode_t;

#endif // TA_NGV_MODE_H
