/**
 * \file constants/non_financial_transactions.h
 *
 * Flag constants for FeatureType and OptionType sixml:NonFinancialTransactions value.
 *
 * Copyright: Worldline.
 */

#ifndef TA_NON_FINANCIAL_TRANSACTIONS_H
#define TA_NON_FINANCIAL_TRANSACTIONS_H


/**
 * <p>Flag constants for FeatureType and OptionType sixml:NonFinancialTransactions value.</p>
 * <p>Guides: retail, valueAddedServices.</p>
 */
typedef enum ta_e_non_financial_transactions{
    /**
     * Undefined/invalid value.
     */
    ta_c_nft_undefined = 0,
    
    /**
     * <p>Cancel function supported.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_nft_cancel = 1 << 0,
    
    /**
     * <p>Balance inquiry function supported.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_nft_balance_inquiry = 1 << 1,
    
    /**
     * <p>Client identification function supported.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_nft_client_identification = 1 << 2,
    
    /**
     * <p>Init transaction function supported.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_nft_init_transaction = 1 << 3,
    
    /**
     * <p>Hold commit notification function supported.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_nft_hold_commit = 1 << 4,
    
    /**
     * <p>Reservation function supported.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_nft_reservation = 1 << 5,
    
    /**
     * <p>Adjust Reservation function supported.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_nft_adjust_reservation = 1 << 6,
    
    /**
     * <p>Cancel Reservation function supported.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_nft_cancel_reservation = 1 << 7,
    
    /**
     * <p>Loyalty data query/init/deinit/update function.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_nft_loyalty_data = 1 << 8,
    
    /**
     * <p>Start checkout process at the POS.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_nft_start_checkout = 1 << 9,
    
    /**
     * <p>Finish checkout process at the POS.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_nft_finish_checkout = 1 << 10,
    
    /**
     * <p>Provide LoyaltyBasket to the terminal.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_nft_provide_loyalty_basket = 1 << 11,
    
    /**
     * <p>Provide Vas Result to the terminal.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_nft_provide_vas_result = 1 << 12,
    
    /**
     * <p>AccountVerification function supported.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_nft_account_verification = 1 << 13,
    
    /**
     * <p>ThirdPartyAppData function supported.</p>
     * <p>Specification: valueAddedServices.</p>
     */
    ta_c_nft_third_party_app_data = 1 << 14,
    
    /**
     * <p>AgeCheck function supported.</p>
     * <p>Specification: valueAddedServices.</p>
     */
    ta_c_nft_age_check = 1 << 15
    
} ta_e_non_financial_transactions_t;

#endif // TA_NON_FINANCIAL_TRANSACTIONS_H
