/**
 * \file constants/outcome.h
 *
 * Identifies the outcome of the previous transaction (in the TransactionInfoRequest response).
 *
 * Copyright: Worldline.
 */

#ifndef TA_OUTCOME_H
#define TA_OUTCOME_H


/**
 * <p>Identifies the outcome of the previous transaction (in the TransactionInfoRequest response).</p>
 * <p>Specification: retail.</p>
 */
typedef enum ta_e_outcome{
    /**
     * Undefined/invalid value.
     */
    ta_c_o_undefined = 0,
    
    /**
     * <p>If transaction was successful. This does not necessarily mean the transaction is committed,
     * as for example Reservation does not need a commit. But if there was a rollback, the
     * transaction must NOT be indicated as Successful, but as Failed.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_o_successful = 1,
    
    /**
     * <p>Indicates that the transaction failed / was aborted or rollbacked.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_o_failed = 2,
    
    /**
     * <p>Indicates that the transaction has only partially succeeded (partial commit).</p>
     * <p>Specification: retail.</p>
     */
    ta_c_o_partial = 3
    
} ta_e_outcome_t;

#endif // TA_OUTCOME_H
