/**
 * \file constants/pos_entry_mode.h
 *
 * <p>Defines how the cardholder used the card with the terminal for the transaction.</p>
 * <p>Enumeration according to EMV definition. The following values are valid:</p>
 *
 * Copyright: Worldline.
 */

#ifndef TA_POS_ENTRY_MODE_H
#define TA_POS_ENTRY_MODE_H


/**
 * <p><p>Defines how the cardholder used the card with the terminal for the transaction.</p>
 * <p>Enumeration according to EMV definition. The following values are valid:</p></p>
 * <p>Specification: retail.</p>
 */
typedef enum ta_e_pos_entry_mode{
    /**
     * Undefined/invalid value.
     */
    ta_c_pem_undefined = 0,
    
    /**
     * Unspecified.
     */
    ta_c_pem_unspecified = 1,
    
    /**
     * Manual.
     */
    ta_c_pem_manual = 2,
    
    /**
     * Magnetic stripe, only partial data available. Track data checking may not possible,minimum
     * requirement: PAN data.
     */
    ta_c_pem_mag_stripe_incomplete = 3,
    
    /**
     * Bar Code.
     */
    ta_c_pem_bar_code = 4,
    
    /**
     * OCR.
     */
    ta_c_pem_ocr = 5,
    
    /**
     * Integrated circuit card.
     */
    ta_c_pem_icc = 6,
    
    /**
     * Reference based transaction. Depending on a previously made transaction.
     */
    ta_c_pem_reference_based = 7,
    
    /**
     * Bluetooth Low Energy (BLE)
     */
    ta_c_pem_bluetooth_low_energy = 8,
    
    /**
     * QR Code is displayed on terminal display
     */
    ta_c_pem_qrc_on_terminal = 9,
    
    /**
     * QR Code is displayed on mobile device screen.
     */
    ta_c_pem_qrc_on_mobile = 10,
    
    /**
     * Token based e-commerce transaction.
     */
    ta_c_pem_token_based_ecommerce = 11,
    
    /**
     * Magnetic stripe read completely. Track data checking is possible, service code does not begin
     * with "2" or "6".
     */
    ta_c_pem_mag_stripe = 12,
    
    /**
     * Fallback (normal case): magnetic stripe read; service code begins with "2" or "6". Last
     * transaction in the transaction log was a successful chip or magnetic stripe transaction.
     */
    ta_c_pem_mag_stripe_fallback = 13,
    
    /**
     * Fallback: magnetic stripe read; service code begins with "2" or "6". Last transaction in the
     * transaction log was also a fallback transaction. If the number of transactions with
     * <sixml:PosEntryMode> = "92" grows, the chip reader could be out of order.
     */
    ta_c_pem_mag_stripe_fallback_again = 14,
    
    /**
     * Fallback: magnetic stripe read; service code begins with "2" or "6"; transaction processing
     * with IC failed. Code "93" is used at the transaction, which has caused the fallback, if the
     * chip has been contacted, an application has been selected and the chip data could be read
     * (trm-func, steps 11.4.5, 11.4.8 and 11.4.9), but the following processing with the chip has
     * been aborted because of unknown reasons.
     */
    ta_c_pem_mag_stripe_fallback_icc_fail = 15,
    
    /**
     * Emergency data entry: The emergency receipt data is entered at acquirer.
     */
    ta_c_pem_emergency_data_entry = 16,
    
    /**
     * E-Commerce PSP transaction (distance payment).
     */
    ta_c_pem_ecommerce = 17,
    
    /**
     * Contactless Chip (EMV).
     */
    ta_c_pem_ctless_icc = 18,
    
    /**
     * Contactless Magstripe.
     */
    ta_c_pem_ctless_mag_strige = 19
    
} ta_e_pos_entry_mode_t;

#endif // TA_POS_ENTRY_MODE_H
