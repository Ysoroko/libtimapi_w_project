/**
 * \file constants/print_format.h
 *
 * Constants for PrintFormat tag.
 *
 * Copyright: Worldline.
 */

#ifndef TA_PRINT_FORMAT_H
#define TA_PRINT_FORMAT_H


/**
 * <p>Constants for PrintFormat tag.</p>
 * <p>Specification: retail.</p>
 */
typedef enum ta_e_print_format{
    /**
     * Undefined/invalid value.
     */
    ta_c_pfmt_undefined = 0,
    
    /**
     * <p>Do not generate any receipts.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_pfmt_no_print = 1,
    
    /**
     * <p>Receipts are generated, formatted and sent to the ECR. (default)</p>
     * <p>Specification: retail.</p>
     */
    ta_c_pfmt_normal = 2,
    
    /**
     * <p>Receipts are generated and printed on the printer attached to the EFT terminal but not
     * returned to the ECR.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_pfmt_on_device = 3,
    
    /**
     * <p>Only fields are returned for printing, not a generated receipt.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_pfmt_fields_only = 4,
    
    /**
     * <p>Receipts are generated and printed on the printer attached to the EFT terminal and generated
     * receipts are returned to the ECR.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_pfmt_on_device_with_receipt = 5,
    
    /**
     * <p>Receipts are generated and printed on the printer attached to the EFT terminal and receipt
     * fields are returned to the ECR, not generated receipts.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_pfmt_on_device_with_fields = 6
    
} ta_e_print_format_t;

#endif // TA_PRINT_FORMAT_H
