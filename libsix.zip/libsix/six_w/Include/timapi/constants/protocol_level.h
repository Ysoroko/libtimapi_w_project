/**
 * \file constants/protocol_level.h
 *
 * Protocol level for FeatureType and OptionType sixml:ProtocolLevel value.
 *
 * Copyright: Worldline.
 */

#ifndef TA_PROTOCOL_LEVEL_H
#define TA_PROTOCOL_LEVEL_H


/**
 * <p>Protocol level for FeatureType and OptionType sixml:ProtocolLevel value.</p>
 * <p>Specification: retail.</p>
 */
typedef enum ta_e_protocol_level{
    /**
     * Undefined/invalid value.
     */
    ta_c_pl_undefined = 0,
    
    /**
     * <p>SIXml according to 2.2 Specification.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_pl_sixml_2_2 = 1
    
} ta_e_protocol_level_t;

#endif // TA_PROTOCOL_LEVEL_H
