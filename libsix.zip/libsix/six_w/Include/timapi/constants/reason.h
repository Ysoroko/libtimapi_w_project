/**
 * \file constants/reason.h
 *
 * Constants for Reason tag.
 *
 * Copyright: Worldline.
 */

#ifndef TA_REASON_H
#define TA_REASON_H


/**
 * <p>Constants for Reason tag.</p>
 * <p>Specification: petrol.</p>
 */
typedef enum ta_e_reason{
    /**
     * Undefined/invalid value.
     */
    ta_c_rsn_undefined = 0,
    
    /**
     * <p>Ok button used to confirm dialog.</p>
     * <p>Specification: petrol.</p>
     */
    ta_c_rsn_ok = 1,
    
    /**
     * <p>Corr button used to confirm/decline dialog.</p>
     * <p>Specification: petrol.</p>
     */
    ta_c_rsn_corr = 2,
    
    /**
     * <p>Stop button used to decline dialog.</p>
     * <p>Specification: petrol.</p>
     */
    ta_c_rsn_stop = 3,
    
    /**
     * <p>Card inserted/swiped/presented to confirm dialog.</p>
     * <p>Specification: petrol.</p>
     */
    ta_c_rsn_card_reader = 4,
    
    /**
     * <p>Dialog confirmed automatically (e.g. with the completion of an input form).</p>
     * <p>Specification: petrol.</p>
     */
    ta_c_rsn_auto_confirm = 5,
    
    /**
     * <p>No interaction performed and timeout occured.</p>
     * <p>Specification: petrol.</p>
     */
    ta_c_rsn_timeout = 6,
    
    /**
     * <p>Code Check succesful.</p>
     * <p>Specification: petrol.</p>
     */
    ta_c_rsn_code_ok = 7,
    
    /**
     * <p>Code Check failed.</p>
     * <p>Specification: petrol.</p>
     */
    ta_c_rsn_code_nok = 8,
    
    /**
     * <p>PIN Check succesful.</p>
     * <p>Specification: petrol.</p>
     */
    ta_c_rsn_pin_ok = 9,
    
    /**
     * <p>PIN Check failed.</p>
     * <p>Specification: petrol.</p>
     */
    ta_c_rsn_pin_nok = 10,
    
    /**
     * <p>Function key 1 used to confirm dialog.</p>
     * <p>Specification: petrol.</p>
     */
    ta_c_rsn_f1 = 11,
    
    /**
     * <p>Function key 2 used to confirm dialog.</p>
     * <p>Specification: petrol.</p>
     */
    ta_c_rsn_f2 = 12,
    
    /**
     * <p>Function key 3 used to confirm dialog.</p>
     * <p>Specification: petrol.</p>
     */
    ta_c_rsn_f3 = 13,
    
    /**
     * <p>Any other key used (not Ok, Stop, Corr, F1, F2) to confirm the dialog.</p>
     * <p>Specification: petrol.</p>
     */
    ta_c_rsn_other_key = 14
    
} ta_e_reason_t;

#endif // TA_REASON_H
