/**
 * \file constants/receipt_item_type.h
 *
 * <p>Specifies type of ReceiptItem.</p>
 * <p>This field has a freetext format, but the following values are predefined:</p>
 *
 * Copyright: Worldline.
 */

#ifndef TA_RECEIPT_ITEM_TYPE_H
#define TA_RECEIPT_ITEM_TYPE_H


/**
 * <p><p>Specifies type of ReceiptItem.</p>
 * <p>This field has a freetext format, but the following values are predefined:</p></p>
 * <p>Specification: retail.</p>
 */
typedef enum ta_e_receipt_item_type{
    /**
     * Undefined/invalid value.
     */
    ta_c_rit_undefined = 0,
    
    /**
     * <p>Activation Id</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rit_act_id = 1,
    
    /**
     * <p>Accounting Period</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rit_acc_per = 2,
    
    /**
     * <p>AcquirerId</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rit_acq_id = 3,
    
    /**
     * <p>Application identifier</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rit_aid = 4,
    
    /**
     * <p>Amount of the transaction</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rit_amount = 5,
    
    /**
     * <p>DCC amount of the transaction</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rit_amount_dcc = 6,
    
    /**
     * <p>Other amount of the transaction</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rit_amount_other = 7,
    
    /**
     * <p>Total reservation amount after a reservation adjustment</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rit_amount_reservation = 8,
    
    /**
     * <p>Saldo amount</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rit_amount_saldo = 9,
    
    /**
     * <p>Tip amount</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rit_amount_tip = 10,
    
    /**
     * <p>Authorization code</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rit_auth_code = 11,
    
    /**
     * <p>ep2 Authorization result</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rit_auth_reslt = 12,
    
    /**
     * <p>ep2 Authorization response code</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rit_auth_resp_c = 13,
    
    /**
     * <p>ep2 Authorization response text</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rit_auth_resp_text_c = 14,
    
    /**
     * <p>BrandName of the card used</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rit_brand_name = 15,
    
    /**
     * <p>Currency of the transaction</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rit_currency = 16,
    
    /**
     * <p>DCC currency of the transaction</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rit_currency_dcc = 17,
    
    /**
     * <p>DCC disclaimer</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rit_dcc_disclaimer = 18,
    
    /**
     * <p>Standard disclaimer</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rit_disclaimer = 19,
    
    /**
     * <p>Exponent of the currency used</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rit_exponent = 20,
    
    /**
     * <p>Exponent of the DCC currency</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rit_exponent_dcc = 21,
    
    /**
     * <p>DCC markup</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rit_markup_dcc = 22,
    
    /**
     * <p>Exponent of DCC markup</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rit_markup_exponent_dcc = 23,
    
    /**
     * <p>Card number for merchant receipt</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rit_card_number_printable_merchant = 24,
    
    /**
     * <p>Card number for cardholder receipt</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rit_card_number_printable_cardholder = 25,
    
    /**
     * <p>DCC rate</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rit_rate_dcc = 26,
    
    /**
     * <p>Exponent of DCC rate</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rit_rate_exponent_dcc = 27,
    
    /**
     * <p>Time stamp of transaction, date part</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rit_time_stamp_date = 28,
    
    /**
     * <p>Time stamp of transaction, time part</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rit_time_stamp_time = 29,
    
    /**
     * <p>Terminal identifier</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rit_trm_id = 30,
    
    /**
     * <p>Transaction reference number</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rit_trx_ref_num = 31,
    
    /**
     * <p>Transaction sequence counter</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rit_trx_seq_cnt = 32,
    
    /**
     * <p>POS entry mode</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rit_pos_entry_mode = 33,
    
    /**
     * <p>Card expiry date</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rit_card_expiry_date = 34,
    
    /**
     * <p>Card number encrypted</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rit_card_number_enc = 35,
    
    /**
     * <p>ECR sequence number</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rit_ecr_seq_counter = 36,
    
    /**
     * <p>Ep2 PAN receipt DOL</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rit_pan_receipt_dol = 37,
    
    /**
     * <p>Ep2 PAN receipt DOL index</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rit_pan_receipt_dol_index = 38,
    
    /**
     * <p>PreAuthorization Expiration Date</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rit_pre_authorization_exp_date = 39,
    
    /**
     * <p>TenderName of the card used</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rit_tender_name = 40,
    
    /**
     * <p>ep2 number of chosen installments</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rit_number_of_installments = 41,
    
    /**
     * <p>ep2 disclaimer used for installment receipts</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rit_installment_disclaimer = 42,
    
    /**
     * <p>Application identifier of the original transaction used for a follow on transaction.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rit_original_aid = 43,
    
    /**
     * <p>Truncated card number of the original transaction used for a follow on transaction.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rit_original_card_number_printable = 44,
    
    /**
     * <p>Name of the brand of the original transaction used for a follow on transaction.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rit_original_brand_name = 45,
    
    /**
     * <p>CardCountryCode/IssuerCountryCode of the original transaction used for a follow on
     * transaction.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rit_original_card_country_code = 46,
    
    /**
     * <p>TenderName of the original transaction used for a follow on transaction.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rit_original_tender_name = 47,
    
    /**
     * <p>Transaction reference number of the original transaction used for a follow on transaction.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rit_original_trans_ref = 48,
    
    /**
     * <p>Fee amount charged for the installment service.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rit_amount_installment_fee = 49,
    
    /**
     * <p>Total amount including including installment fees and interest rates.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rit_amount_installment_total = 50,
    
    /**
     * <p>Amount of the first installment payment.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rit_amount_installment_first = 51,
    
    /**
     * <p>Amount of one installment payment (Not the first if a first amount is present).</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rit_amount_installment_one = 52,
    
    /**
     * <p>Interest rate of the installment option.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rit_interest_installment = 53,
    
    /**
     * <p>DCC markup vs regulated (ECB) reference exchange rate</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rit_markup_dcc_regulated = 54,
    
    /**
     * <p>Exponent of regulated DCC markup</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rit_markup_exponent_dcc_regulated = 55,
    
    /**
     * <p>DCC rate vs regulated (ECB) reference exchange rate</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rit_rate_dcc_regulated = 56,
    
    /**
     * <p>Exponent of regulated DCC rate</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rit_rate_exponent_dcc_regulated = 57,
    
    /**
     * <p>Key Index of encrypted PAN on receipt</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rit_key_pan_receipt_index = 58,
    
    /**
     * <p>Additional data the merchant added to the transaction.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rit_additional_merchant_data = 59,
    
    /**
     * <p>Account index that has been used for this transaction.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rit_multi_account_index = 60,
    
    /**
     * <p>Acquirer contract index has been used for this transaction.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rit_multi_contract_index = 61,
    
    /**
     * <p>Specific terminal identifier defined by the merchant. (Petrol usage)</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rit_merchant_tid = 62,
    
    /**
     * <p>Merchant defined attendant identifier. (Petrol usage)</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rit_clerk_identifier = 63,
    
    /**
     * <p>Fuel Pump used. (Petrol usage)</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rit_fuel_dispenser_number = 64,
    
    /**
     * <p>Number of the POS device. (Petrol usage)</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rit_posdnumber = 65,
    
    /**
     * <p>ECR Receipt number. (Petrol usage)</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rit_receipt_number = 66,
    
    /**
     * <p>ECR side shift number. (Petrol usage)</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rit_shift_number = 67,
    
    /**
     * <p>ASRPD/Product entry of the card: Credit, Debit, Commercial, Pre-Paid.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rit_card_product_type = 68,
    
    /**
     * <p>The selected account type during Account Selection.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rit_account_type = 69,
    
    /**
     * <p>Surcharge amount that has been added.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rit_surcharge_amount = 70,
    
    /**
     * <p>Original Transaction reference number (used for Omnichannel original payment ID).</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rit_original_trx_ref_num = 71,
    
    /**
     * <p>Signature line is required to be printed. Value 1 for yes, 0 for no.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rit_signature_line = 72
    
} ta_e_receipt_item_type_t;

#endif // TA_RECEIPT_ITEM_TYPE_H
