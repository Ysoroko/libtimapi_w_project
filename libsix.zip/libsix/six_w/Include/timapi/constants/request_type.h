/**
 * \file
 * \brief Request type constant.
 */

#ifndef REQUEST_TYPE_H
#define REQUEST_TYPE_H


/** \brief Request type. */
typedef enum ta_e_request_type {
	/** \brief Invalid/undefined. */
	ta_c_req_undefined = 0,
	
	/** \brief Operation started by terminal_connect. */
	ta_c_req_connect = 1,
	
	/** \brief Operation started by terminal_activate_async. */
	ta_c_req_activate = 2,
	
	/** \brief Operation started by terminal_application_information_async. */
	ta_c_req_application_information = 3,
	
	/** \brief Operation started by terminal_balance_async. */
	ta_c_req_balance = 4,
	
	/** \brief Operation started by terminal_change_settings_async. */
	ta_c_req_change_settings = 5,
	
	/** \brief Operation started by terminal_commit_async. */
	ta_c_req_commit = 6,
	
	/** \brief Operation started by terminal_counter_request_async. */
	ta_c_req_counter_request = 7,
	
	/** \brief Operation started by terminal_deactivate_async. */
	ta_c_req_deactivate = 8,
	
	/** \brief Operation started by terminal_dcc_rates_async. */
	ta_c_req_dcc_rates = 9,
	
	/** \brief Operation started by terminal_hardware_information_async. */
	ta_c_req_hardware_information = 10,
	
	/** \brief Operation started by terminal_init_transaction_async. */
	ta_c_req_init_transaction = 11,
	
	/** \brief Operation started by terminal_init_transaction_async. */
	ta_c_req_init_transaction_with_dialog = 12,
	
	/** \brief Operation started by terminal_login_async. */
	ta_c_req_login = 13,
	
	/** \brief Operation started by terminal_logout_async. */
	ta_c_req_logout = 14,
	
	/** \brief Operation started by terminal_reboot_async. */
	ta_c_req_reboot = 15,
	
	/** \brief Operation started by terminal_reconciliation_async. */
	ta_c_req_reconciliation = 16,
	
	/** \brief Operation started by terminal_receipt_request_async. */
	ta_c_req_receipt_request = 17,
	
	/** \brief Operation started by terminal_reconfig_async. */
	ta_c_req_reconfig = 18,
	
	/** \brief Operation started by terminal_rollback_async. */
	ta_c_req_rollback = 19,
	
	/** \brief Operation started by terminal_system_information_async. */
	ta_c_req_system_information = 20,
	
	/** \brief Operation started by terminal_software_update_async. */
	ta_c_req_software_update = 21,
	
	/** \brief Operation started by terminal_transaction_async. */
	ta_c_req_transaction = 22,
	
	
	
	/**
	 * \brief Operation started by terminal_close_reader_async.
	 * 
	 * Supported only if ta_c_g_unattended is enabled.
	 */
	ta_c_req_close_reader = 23,
	
	/**
	 * \brief Operation started by terminal_open_reader_async.
	 * 
	 * Supported only if ta_c_g_unattended is enabled.
	 */
	ta_c_req_open_reader = 24,
	
	/**
	 * \brief Operation started by terminal_eject_card_async.
	 * 
	 * Supported only if ta_c_g_unattended is enabled.
	 */
	ta_c_req_eject_card = 25,
	
	/**
	 * \brief Operation started by terminal_open_maintenance_window_async.
	 * 
	 * Supported only if ta_c_g_unattended is enabled.
	 */
	ta_c_req_open_maintenance_window = 26,
	
	/**
	 * \brief Operation started by terminal_close_maintenance_window_async.
	 * 
	 * Supported only if ta_c_g_unattended is enabled.
	 */
	ta_c_req_close_maintenance_window = 27,
	
	/**
	 * \brief Operation started by terminal_activate_service_menu_async.
	 * 
	 * Supported only if ta_c_g_unattended is enabled.
	 */
	ta_c_req_activate_service_menu = 28,
	
	
	
	/**
	 * \brief Operation started by terminal_open_dialog_mode_async.
	 * 
	 * Supported only if ta_c_g_dialog is enabled.
	 */
	ta_c_req_open_dialog_mode = 29,
	
	/**
	 * \brief Operation started by terminal_close_dialog_mode_async.
	 * 
	 * Supported only if ta_c_g_dialog is enabled.
	 */
	ta_c_req_close_dialog_mode = 30,
	
	/**
	 * \brief Operation started by terminal_show_signature_capture_async.
	 * 
	 * Supported only if ta_c_g_dialog is enabled.
	 */
	ta_c_req_show_signature_capture = 31,
	
	/**
	 * \brief Operation started by terminal_show_dialog_async.
	 * 
	 * Supported only if ta_c_g_dialog is enabled.
	 */
	ta_c_req_show_dialog = 32,
	
	/**
	 * \brief Operation started by terminal_send_card_command.
	 * 
	 * Supported only if ta_c_g_dialog is enabled.
	 */
	ta_c_req_send_card_command = 33,
	
	/**
	 * \brief Operation started by terminal_print_on_terminal_async.
	 * 
	 * Supported only if ta_c_g_dialog is enabled.
	 */
	ta_c_req_print_on_terminal = 34,
	
	
	
	/**
	 * \brief Operation started by terminal_loyalty_data_async.
	 * 
	 * Supported only if ta_c_g_value_added_services is enabled.
	 */
	ta_c_req_loyalty_data = 35,
	
	/**
	 * \brief Operation started by terminal_start_checkout_async.
	 * 
	 * Supported only if ta_c_g_value_added_services is enabled.
	 */
	ta_c_req_start_checkout = 36,
	
	/**
	 * \brief Operation started by terminal_finish_checkout_async.
	 * 
	 * Supported only if ta_c_g_value_added_services is enabled.
	 */
	ta_c_req_finish_checkout = 37,
	
	/**
	 * \brief Operation started by terminal_provide_loyalty_basket_async.
	 * 
	 * Supported only if ta_c_g_value_added_services is enabled.
	 */
	ta_c_req_provide_loyalty_basket = 38,
	
	/**
	 * \brief Operation started by terminal_vas_result_async.
	 * 
	 * Supported only if ta_c_g_value_added_services is enabled.
	 */
	ta_c_req_provide_vas_result = 39,
	
	/**
	 * \brief Operation started by terminal_mobile_topup_issuer_info_async.
	 * 
	 * Supported only if ta_c_g_value_added_services is enabled.
	 */
	ta_c_req_mobile_topup_issuer_info = 40,
	
	/**
	 * \brief Operation started by terminal_mobile_topup_async.
	 * 
	 * Supported only if ta_c_g_value_added_services is enabled.
	 */
	ta_c_req_mobile_topup = 41,
	
	
	
	/**
	 * \brief Operation started by terminal_balance_inquiry_async.
	 * 
	 * Supported only if ta_c_g_advanced_retail is enabled.
	 */
	ta_c_req_balance_inquiry = 42,
	
	
	
	/** \brief Operation started by terminal_request_alias_async. */
	ta_c_req_request_alias = 43,
	
	
	
	/** \brief Operation started by terminal_device_maintenance. */
	ta_c_req_device_maintenance = 44,
	
	/** \brief Operation started by terminal_client_identification. */
	ta_c_req_client_identification = 45,
	
	/** \brief Operation started by transaction_info_request_async. */
	ta_c_req_transaction_info_request = 46,
	
	/**
	 * \brief Operation started by terminal_age_check_async.
	 * 
	 * Supported only if ta_c_g_value_added_services is enabled.
	 */
	ta_c_req_age_check = 47
} ta_e_request_type_t;

#endif
