/**
 * \file constants/resource_id.h
 *
 * Enumeration attribute defines which dialog shall be displayed. All dialogs are divided into
 * multiple groups containing dialogs similar operational area.
 *
 * Copyright: Worldline.
 */

#ifndef TA_RESOURCE_ID_H
#define TA_RESOURCE_ID_H


/**
 * <p>Enumeration attribute defines which dialog shall be displayed. All dialogs are divided into
 * multiple groups containing dialogs similar operational area.</p>
 * <p>Specification: dialog.</p>
 */
typedef enum ta_e_resource_id{
    /**
     * Undefined/invalid value.
     */
    ta_c_rid_undefined = 0,
    
    /**
     * Enter mileage + OK<br />
     * %i
     */
    ta_c_rid_enter_mileage = 1,
    
    /**
     * Enter your car number + OK<br />
     * %i
     */
    ta_c_rid_enter_car_number = 2,
    
    /**
     * Enter drivercode + OK<br />
     * %i
     */
    ta_c_rid_enter_driver_code = 3,
    
    /**
     * Enter fleet ID + OK<br />
     * %i
     */
    ta_c_rid_enter_fleet_id = 4,
    
    /**
     * %0 %1<br />
     * Please select pump: %i<br />
     * + OK<br />
     * PlaceholderItems:<br />
     * - 0: Currency<br />
     * - 1: Amount<br />
     * 
     */
    ta_c_rid_select_pump = 5,
    
    /**
     * Please select washing<br />
     * station: %i + OK
     */
    ta_c_rid_select_washing_station = 6,
    
    /**
     * Please select program:<br />
     * %i + OK
     */
    ta_c_rid_select_program = 7,
    
    /**
     * Please select product:<br />
     * %i + OK
     */
    ta_c_rid_select_product = 8,
    
    /**
     * Load card + OK<br />
     * %0 %i<br />
     * PlaceholderItems:<br />
     * - 0: Currency<br />
     * <br />
     * ResourceParameter:<br />
     * - Exponent<br />
     * 
     */
    ta_c_rid_load_card = 9,
    
    /**
     * Tankcode?<br />
     * %i
     */
    ta_c_rid_read_code = 10,
    
    /**
     * CODE & OK?<br />
     * %i<br />
     * ResourceParameter:<br />
     * - CodeCheckType<br />
     * - CodeCheckKeyId<br />
     * - CodeCheckData<br />
     * - PetrolCardData1<br />
     * - PetrolCardData2<br />
     * - PetrolCardData3<br />
     * 
     */
    ta_c_rid_check_code = 11,
    
    /**
     * Enter additional information + OK<br />
     * %i
     */
    ta_c_rid_enter_additional_information = 12,
    
    /**
     * Enter cost center + OK<br />
     * %i
     */
    ta_c_rid_enter_cost_center = 13,
    
    /**
     * Enter employee no + OK<br />
     * %i
     */
    ta_c_rid_enter_employee_number = 14,
    
    /**
     * Enter license plate + OK<br />
     * %i
     */
    ta_c_rid_enter_license_plate = 15,
    
    /**
     * Enter project no + OK<br />
     * %i
     */
    ta_c_rid_enter_project_number = 16,
    
    /**
     * Print receipt?<br />
     * [YES] / [NO]
     */
    ta_c_rid_petrol_print_receipt = 17,
    
    /**
     * Remove card
     */
    ta_c_rid_petrol_remove_card = 18,
    
    /**
     * Out of order
     */
    ta_c_rid_petrol_out_of_order = 19,
    
    /**
     * Invalid entry
     */
    ta_c_rid_petrol_invalid_entry = 20,
    
    /**
     * Please refuel at<br />
     * dispenser %0<br />
     * PlaceholderItems:<br />
     * - 0: Dispenser number<br />
     * 
     */
    ta_c_rid_petrol_refuel_at_pump = 21,
    
    /**
     * Please consider<br />
     * main screen
     */
    ta_c_rid_petrol_see_other_screen = 22,
    
    /**
     * Please refuel
     */
    ta_c_rid_petrol_please_refuel = 23,
    
    /**
     * Please refuel for<br />
     * %0 %1<br />
     * PlaceholderItems:<br />
     * - 0: Currency<br />
     * - 1: Amount<br />
     * 
     */
    ta_c_rid_petrol_please_refuel_for_amt = 24,
    
    /**
     * Welcome,<br />
     * card please
     */
    ta_c_rid_petrol_insert_card = 25,
    
    /**
     * Please wait
     */
    ta_c_rid_petrol_please_wait = 26,
    
    /**
     * Last CODE try<br />
     * CODE + OK<br />
     * %i<br />
     * ResourceParameter:<br />
     * - CodeCheckType<br />
     * - CodeCheckKeyId<br />
     * - CodeCheckData<br />
     * - PetrolCardData1<br />
     * - PetrolCardData2<br />
     * - PetrolCardData3<br />
     * 
     */
    ta_c_rid_petrol_last_code_try = 27,
    
    /**
     * %0 tries left<br />
     * CODE + OK<br />
     * %i<br />
     * PlaceholderItems:<br />
     * - 0: Number of tries left<br />
     * <br />
     * ResourceParameter:<br />
     * - CodeCheckType<br />
     * - CodeCheckKeyId<br />
     * - CodeCheckData<br />
     * - PetrolCardData1<br />
     * - PetrolCardData2<br />
     * - PetrolCardData3<br />
     * 
     */
    ta_c_rid_petrol_code_tries_left = 28,
    
    /**
     * No more CODE<br />
     * tries left
     */
    ta_c_rid_petrol_no_code_tries_left = 29,
    
    /**
     * CODE incorrect
     */
    ta_c_rid_petrol_code_incorrect = 30,
    
    /**
     * Last try<br />
     * Tankcode + OK<br />
     * %i
     */
    ta_c_rid_petrol_last_tankcode_try = 31,
    
    /**
     * %0 tries left<br />
     * Tankcode + OK<br />
     * %i<br />
     * PlaceholderItems:<br />
     * - 0: Number of tries left<br />
     * 
     */
    ta_c_rid_petrol_tankcode_tries_left = 32,
    
    /**
     * No more Tankcode<br />
     * tries left<br />
     * 
     */
    ta_c_rid_petrol_no_more_tankcode_tries_left = 33,
    
    /**
     * Tankcode incorrect
     */
    ta_c_rid_petrol_tankcode_incorrect = 34,
    
    /**
     * Card unreadable<br />
     * Card inverted?
     */
    ta_c_rid_petrol_card_inverted = 35,
    
    /**
     * Card type<br />
     * out-of-order
     */
    ta_c_rid_petrol_card_out_of_order = 36,
    
    /**
     * Card not authorised
     */
    ta_c_rid_petrol_card_not_authorised = 37,
    
    /**
     * Card unknown
     */
    ta_c_rid_petrol_card_unknown = 38,
    
    /**
     * Card expired
     */
    ta_c_rid_petrol_card_expired = 39,
    
    /**
     * Card blocked
     */
    ta_c_rid_petrol_card_blocked = 40,
    
    /**
     * Card refused
     */
    ta_c_rid_petrol_card_refused = 41,
    
    /**
     * Card refused by host
     */
    ta_c_rid_petrol_card_refused_by_host = 42,
    
    /**
     * Card without<br />
     * payment function
     */
    ta_c_rid_petrol_card_without_payment_function = 43,
    
    /**
     * Operation aborted
     */
    ta_c_rid_petrol_card_operation_aborted = 44,
    
    /**
     * No product allowed
     */
    ta_c_rid_petrol_card_product_not_allowed = 45,
    
    /**
     * No product available
     */
    ta_c_rid_petrol_card_product_not_available = 46,
    
    /**
     * Amount too low<br />
     * to start pump
     */
    ta_c_rid_petrol_card_amount_too_low = 47,
    
    /**
     * A transaction for<br />
     * this card is still<br />
     * in progress
     */
    ta_c_rid_petrol_card_transction_still_in_progress = 48,
    
    /**
     * Limit reached
     */
    ta_c_rid_petrol_card_limit_reached = 49,
    
    /**
     * Personalisation card
     */
    ta_c_rid_petrol_card_personalisation_card = 50,
    
    /**
     * Dual Card System
     */
    ta_c_rid_petrol_card_dual_card_system = 51,
    
    /**
     * Insert Second Card
     */
    ta_c_rid_petrol_card_insert_second_card = 52,
    
    /**
     * Dual Card System<br />
     * Insert Second Card
     */
    ta_c_rid_petrol_card_dual_card_system_insert_second_card = 53,
    
    /**
     * Selected pump not<br />
     * available
     */
    ta_c_rid_petrol_pump_not_available = 54,
    
    /**
     * No pump is free
     */
    ta_c_rid_petrol_pump_no_pump_free = 55,
    
    /**
     * Refueling stopped
     */
    ta_c_rid_petrol_pump_stopped_refueling = 56,
    
    /**
     * Refueling in<br />
     * progress
     */
    ta_c_rid_petrol_pump_refueling_in_progress = 57,
    
    /**
     * Product not<br />
     * available on<br />
     * selected pump
     */
    ta_c_rid_petrol_pump_product_not_available = 58,
    
    /**
     * Refueling aborted<br />
     * please put the<br />
     * nozzle back
     */
    ta_c_rid_petrol_pump_refueling_aborted = 59,
    
    /**
     * Press [OK] for pump
     */
    ta_c_rid_petrol_pump_press_ok = 60,
    
    /**
     * Closed
     */
    ta_c_rid_petrol_welcome_closed = 61,
    
    /**
     * Welcome
     */
    ta_c_rid_petrol_welcome = 62,
    
    /**
     * Shop open
     */
    ta_c_rid_petrol_welcome_shop_open = 63,
    
    /**
     * Please insert card.<br />
     * Printer not available
     */
    ta_c_rid_petrol_welcome_insert_card_receipt_not_available = 64,
    
    /**
     * Insert Banknote
     */
    ta_c_rid_petrol_banknote_insert_banknote = 65,
    
    /**
     * Credit<br />
     * %0 %1<br />
     * [STOP] for payback<br />
     * PlaceholderItems:<br />
     * - 0: Currency<br />
     * - 1: Amount<br />
     * 
     */
    ta_c_rid_petrol_banknote_credit_amount = 66,
    
    /**
     * Credit<br />
     * %0 %1<br />
     * Insert Banknote<br />
     * PlaceholderItems:<br />
     * - 0: Currency<br />
     * - 1: Amount<br />
     * 
     */
    ta_c_rid_petrol_banknote_credit_amount_insert_banknote = 67,
    
    /**
     * No Credit
     */
    ta_c_rid_petrol_banknote_no_credit = 68,
    
    /**
     * Banknotes and<br />
     * Cards available
     */
    ta_c_rid_petrol_banknote_or_cards = 69,
    
    /**
     * Banknotes available<br />
     * Cards out of order
     */
    ta_c_rid_petrol_banknote_only = 70,
    
    /**
     * Banknotes<br />
     * out of order<br />
     * Cards available
     */
    ta_c_rid_petrol_banknote_cards_only = 71,
    
    /**
     * Credit<br />
     * %0 %1<br />
     * Press [OK]for pump<br />
     * PlaceholderItems:<br />
     * - 0: Currency<br />
     * - 1: Amount<br />
     * 
     */
    ta_c_rid_petrol_banknote_credit_amount_pump_press_ok = 72,
    
    /**
     * Insert Card<br />
     * or Banknote<br />
     * Function Keys:<br />
     * - F1: Language<br />
     * - F2: Receipt
     */
    ta_c_rid_petrol_trx_banknote_receipt_language = 73,
    
    /**
     * Insert Card<br />
     * Banknotes out<br />
     * of order<br />
     * Function Keys:<br />
     * - F1: Language<br />
     * - F2: Receipt
     */
    ta_c_rid_petrol_trx_receipt_language = 74,
    
    /**
     * Insert Card<br />
     * Function Keys:<br />
     * - F1: Language<br />
     * - F2: Receipt
     */
    ta_c_rid_petrol_insert_card_receipt_language = 75,
    
    /**
     * Please pay in shop
     */
    ta_c_rid_petrol_payment_in_shop = 76,
    
    /**
     * Pay in the shop<br />
     * Press [OK]
     */
    ta_c_rid_petrol_payment_in_shop_press_btn = 77,
    
    /**
     * Pay at the pump<br />
     * Press [OK]
     */
    ta_c_rid_petrol_payment_at_pump_press_btn = 78,
    
    /**
     * Select shop/pump
     */
    ta_c_rid_petrol_paymen_select_shop_pump = 79,
    
    /**
     * See Other Display
     */
    ta_c_rid_petrol_paymen_see_other_display = 80,
    
    /**
     * Receipt not<br />
     * available
     */
    ta_c_rid_petrol_print_receipt_not_available = 81,
    
    /**
     * Press receipt key<br />
     * for safe-receipt
     */
    ta_c_rid_petrol_print_press_key_for_safe_receipt = 82,
    
    /**
     * Receipt printer out<br />
     * of order. Continue?<br />
     * [OK] or [STOP]
     */
    ta_c_rid_petrol_print_out_of_order = 83,
    
    /**
     * Your receipt is<br />
     * being printed
     */
    ta_c_rid_petrol_print_receipt_in_print = 84,
    
    /**
     * Unknown scan code
     */
    ta_c_rid_petrol_vas = 85,
    
    /**
     * Amount:<br />
     * %0 %1<br />
     * Checking scan code<br />
     * PlaceholderItems:<br />
     * - 0: Currency<br />
     * - 1: Amount<br />
     * 
     */
    ta_c_rid_petrol_vas_amount_checking_scancode = 86,
    
    /**
     * Please Wait<br />
     * Checking scan code
     */
    ta_c_rid_petrol_vas_wait_checking_scancode = 87,
    
    /**
     * Voucher invalid<br />
     * Amount used up
     */
    ta_c_rid_petrol_vas_voucher_used_up = 88,
    
    /**
     * Voucher<br />
     * invalid/blocked
     */
    ta_c_rid_petrol_vas_voucher_invalid_blocked = 89,
    
    /**
     * Voucher expired
     */
    ta_c_rid_petrol_vas_voucher_expired = 90,
    
    /**
     * Voucher cannot<br />
     * be evaluated
     */
    ta_c_rid_petrol_vas_voucher_cannot_be_evaluated = 91,
    
    /**
     * Cumulus scanned
     */
    ta_c_rid_petrol_vas_cumulus_scanned = 92,
    
    /**
     * Discount bon scanned
     */
    ta_c_rid_petrol_vas_discount_bon_scanned = 93,
    
    /**
     * Enter scan code or<br />
     * method of payment
     */
    ta_c_rid_petrol_vas_enter_scancode = 94,
    
    /**
     * Discount voucher<br />
     * not active
     */
    ta_c_rid_petrol_vas_discount_voucher_not_active = 95,
    
    /**
     * Clubsmart scanned
     */
    ta_c_rid_petrol_vas_clubsmart_scanned = 96,
    
    /**
     * Gift card<br />
     * already active
     */
    ta_c_rid_petrol_vas_giftcard_already_active = 97,
    
    /**
     * Gift card<br />
     * not possible
     */
    ta_c_rid_petrol_vas_giftcard_not_possible = 98,
    
    /**
     * Service required
     */
    ta_c_rid_petrol_maintenance_service_required = 99,
    
    /**
     * Technical problem
     */
    ta_c_rid_petrol_maintenance_technical_problem = 100,
    
    /**
     * Door not closed
     */
    ta_c_rid_petrol_maintenance_door_open = 101,
    
    /**
     * Communication<br />
     * faliure
     */
    ta_c_rid_petrol_maintenance_comm_failure = 102,
    
    /**
     * Host Out of Order
     */
    ta_c_rid_petrol_maintenance_host_out_of_order = 103,
    
    /**
     * Keine Recharge<br />
     * Karte
     */
    ta_c_rid_post_no_recharge_card = 104,
    
    /**
     * %0<br />
     * %1 %2<br />
     * PlaceholderItems:<br />
     * - 0: Phone Number<br />
     * - 1: Currency<br />
     * - 2: Amount<br />
     * 
     */
    ta_c_rid_post_show_phone_number_with_amount = 105,
    
    /**
     * Bitte Tel. Nummer<br />
     * oder PrePaid-Karte<br />
     * %i
     */
    ta_c_rid_post_enter_phone_or_prepaid_number = 106,
    
    /**
     * Tel. Nummer zu lang
     */
    ta_c_rid_post_phone_number_too_long = 107,
    
    /**
     * Tel. Nummer zu kurz
     */
    ta_c_rid_post_phone_number_too_short = 108,
    
    /**
     * Bitte<br />
     * Telefonnummer<br />
     * eingeben<br />
     * %i
     */
    ta_c_rid_post_enter_phone_number = 109,
    
    /**
     * Bitte warten
     */
    ta_c_rid_post_please_wait = 110,
    
    /**
     * Verarbeitung<br />
     * fehlgeschlagen
     */
    ta_c_rid_post_processing_declined = 111,
    
    /**
     * Verarbeitung OK
     */
    ta_c_rid_post_processing_ok = 112,
    
    /**
     * Karte anmelden
     */
    ta_c_rid_post_register_card = 113,
    
    /**
     * Willkommen,<br />
     * Karte bitte
     */
    ta_c_rid_post_welcome_card = 114,
    
    /**
     * Ihre<br />
     * Telefonnummer<br />
     * lautet %0<br />
     * PlaceholderItems:<br />
     * - 0: Phone Number<br />
     * 
     */
    ta_c_rid_post_show_phone_number = 115,
    
    /**
     * Von %0 %1 %2<br />
     * %3<br />
     * auf %4 %5 %6<br />
     * %7<br />
     * %8 %9<br />
     * PlaceholderItems:<br />
     * - 0: LastKonto<br />
     * - 1: LastKontoTyp<br />
     * - 2: Currency LastKonto<br />
     * - 3: LastKonto-Bezeichnung<br />
     * - 4: GutsKonto<br />
     * - 5: GutsKontoTyp<br />
     * - 6: Currency Gutskonto<br />
     * - 7: GutsKonto-Bezeichnung<br />
     * - 8: Currency<br />
     * - 9: Amount<br />
     * 
     */
    ta_c_rid_post_inter_account_transfer = 116,
    
    /**
     * %0 %1 %2<br />
     * %3 %4<br />
     * %5 %6 %7<br />
     * %8 %9<br />
     * PlaceholderItems:<br />
     * - 0: LastKonto<br />
     * - 1: LastKontoTyp<br />
     * - 2: Currency LastKonto<br />
     * - 3: Currency<br />
     * - 4: AmountSaldo<br />
     * - 5: GutsKonto<br />
     * - 6: GutsKontoTyp<br />
     * - 7: Currency GutsKonto<br />
     * - 8: Currency<br />
     * - 9: AmountSaldo<br />
     * 
     */
    ta_c_rid_post_inter_account_transfer_confirmation = 117,
    
    /**
     * Bezug ab Konto<br />
     * %0<br />
     * %1 %2 OK?
     */
    ta_c_rid_post_disbursement_from_account = 118,
    
    /**
     * Einz. auf eigenes Kto<br />
     * Autorisierung<br />
     * %0 %1 OK?<br />
     * PlaceholderItems:<br />
     * - 0: Currency<br />
     * - 1: Amount<br />
     * 
     */
    ta_c_rid_post_deposit_own_account = 119,
    
    /**
     * 
     */
    ta_c_rid_post_empty_dialog = 120,
    
    /**
     * Ich habe die<br />
     * Sendungen und<br />
     * die darauf<br />
     * aufgeführten<br />
     * Inhalte erhalten
     */
    ta_c_rid_post_packet_acknowledgement = 121,
    
    /**
     * Bitte PIN<br />
     * eingeben:<br />
     * %i
     */
    ta_c_rid_post_pin_entry = 122,
    
    /**
     * Confirmation %0<br />
     * Card: %1<br />
     * Amount: %2 %3<br />
     * Fee: %4 %5<br />
     * PlaceholderItems:<br />
     * - 0: Confirmation subject (use case)<br />
     * - 1: Card number (non PCI only)<br />
     * - 2: Transaction currency<br />
     * - 3: Transaction amount<br />
     * - 4: Fee currency<br />
     * - 5: Fee amount<br />
     * 
     */
    ta_c_rid_post_confirm_costs_for_use_case = 144,
    
    /**
     * Welcome<br />
     * card please
     */
    ta_c_rid_banking_insert_card = 123,
    
    /**
     * PIN & OK<br />
     * %i
     */
    ta_c_rid_banking_pin_check = 124,
    
    /**
     * Press key<br />
     * to show saldo
     */
    ta_c_rid_banking_show_saldo = 125,
    
    /**
     * Confirm amount<br />
     * %2<br />
     * %0 %1<br />
     * PlaceholderItems:<br />
     * - 0: Currency<br />
     * - 1: Amount<br />
     * - 2: Time and Date<br />
     * 
     */
    ta_c_rid_banking_confirm_amount = 126,
    
    /**
     * Remove card
     */
    ta_c_rid_banking_remove_card = 127,
    
    /**
     * Welcome<br />
     * card please
     */
    ta_c_rid_banking_welcome = 128,
    
    /**
     * Welcome
     */
    ta_c_rid_mdb_activate_payment = 129,
    
    /**
     * Bitte warten
     */
    ta_c_rid_common_please_wait = 130,
    
    /**
     * Karte entnehmen
     */
    ta_c_rid_common_remove_card = 131,
    
    /**
     * Stammkundenabfrage<br />
     * ResourceParameter:<br />
     * - RegularDataQueryType<br />
     * 
     */
    ta_c_rid_common_regular = 132,
    
    /**
     * Daten geschrieben
     */
    ta_c_rid_common_data_saved = 133,
    
    /**
     * Karte initialisiert
     */
    ta_c_rid_common_card_initialized = 134,
    
    /**
     * Karte deinitialisiert
     */
    ta_c_rid_common_card_deinitialized = 135,
    
    /**
     * %0 %1<br />
     * Migros GKK Passcode<br />
     * %i<br />
     * PlaceholderItems:<br />
     * - 0: Currency<br />
     * - 1: Amount<br />
     * 
     */
    ta_c_rid_migros_gkkpin_check = 136,
    
    /**
     * Passcode incorrect<br />
     * Try again
     */
    ta_c_rid_migros_passcode_incorrect_retry = 137,
    
    /**
     * Passcode incorrect<br />
     * Last try
     */
    ta_c_rid_migros_passcode_incorrect_last_try = 138,
    
    /**
     * Passcode incorrect<br />
     * Abort
     */
    ta_c_rid_migros_passcode_incorrect_abort = 139,
    
    /**
     * Passcode OK
     */
    ta_c_rid_migros_passode_ok = 140,
    
    /**
     * Payback Code?{br/}%i
     */
    ta_c_rid_payback_read_code = 141,
    
    /**
     * Punkte-Guthaben: %0
     */
    ta_c_rid_payback_show_balance = 142,
    
    /**
     * Punkte einlösen: %i
     */
    ta_c_rid_payback_spend_points = 143
    
} ta_e_resource_id_t;

#endif // TA_RESOURCE_ID_H
