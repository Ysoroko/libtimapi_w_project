/**
 * \file constants/resource_parameter_type.h
 *
 * <p>Parameter type</p>
 * <p>Classifies the value of the <sixml:ResourceParameter> tag.</p>
 * <p>The following values are valid:</p>
 *
 * Copyright: Worldline.
 */

#ifndef TA_RESOURCE_PARAMETER_TYPE_H
#define TA_RESOURCE_PARAMETER_TYPE_H


/**
 * <p><p>Parameter type</p>
 * <p>Classifies the value of the <sixml:ResourceParameter> tag.</p>
 * <p>The following values are valid:</p></p>
 * <p>Guides: petrol, dialog.</p>
 */
typedef enum ta_e_resource_parameter_type{
    /**
     * Undefined/invalid value.
     */
    ta_c_rpt_undefined = 0,
    
    /**
     * <p>Type of code check to perform.
     * <ul>
     *   <li>0: EMV - Check using EMV PIN check.</li>
     *   <li>1: SwissPost - SwissPost Card algorithm.</li>
     *   <li>2: Avia - Use Aviacard algorithm.</li>
     *   <li>3: SB - Use Scheit & Bachmann algorithm.</li>
     *   <li>4: ProEDA/Tokheim - Use ProEDA / Tokheim algorithm</li>
     *   <li>5: Agrola - Use Agrola algorithm</li>
     *   <li>6: Bica - Use Bica algorithm</li>
     *   <li>7: CTAC - Use CTAC algorithm</li>
     *   <li>8: DASAG - Use DASAG algorithm</li>
     *   <li>9: DKV - Use DKV algorithm</li>
     *   <li>10: Esso - Use Esso algorithm</li>
     *   <li>11: Migrol - Use Migrol algorithm</li>
     *   <li>12: Oelpool - Use Oelpool algorithm</li>
     *   <li>13: Pronto - Use Pronto algorithm</li>
     *   <li>14: Shell - Use Shell algorithm</li>
     *   <li>15: WLDC - Use WLDC algorithm</li>
     *   <li>16: Hectronic - Use HecPAC algorithm</li>
     *   <li>17: Diplomatkarte - Use Diplomatkarten algorithm</li>
     *   <li>18: Micrelec - Use the Micrelec algorithm</li>
     *   <li>19: Schenk - Use the Schenk algorithm</li>
     *   <li>20: BeBeCo - Use the BeBeCo (Postbetriebe) algorithm</li>
     * </ul>
     * This value is to be encoded as a ascii number i.e. using characters in the range 30h to 39h.</p>
     * <p>Specification: petrol.</p>
     */
    ta_c_rpt_code_check_type = 1,
    
    /**
     * <p>Key id of the key to use for the selected <em>CodeCheckType</em> .
     * <ul>
     *   <li>0: Tokheim key id.</li>
     *   <li>1: HecPAC key id.</li>
     *   <li>2: DASAG key id.</li>
     *   <li>3: Diplomatkarten key id.</li>
     *   <li>4: Micrelec key id</li>
     *   <li>5000: Start of test key range.</li>
     *   <li>5002: DASAG test key id.</li>
     * </ul>
     * This value is to be encoded as a ascii number i.e. using characters in the range 30h to 39h.</p>
     * <p>Specification: petrol.</p>
     */
    ta_c_rpt_code_check_key_id = 2,
    
    /**
     * <p>Data used in the calculation of some <em>CodeCheckType</em> s. This value is to be encoded as
     * hex string.</p>
     * <p>Specification: petrol.</p>
     */
    ta_c_rpt_code_check_data = 3,
    
    /**
     * <p>Type of query to receive data about regulars.
     * <ul>
     *   <li>StfkV1: Version 1 regular data query type in Austria.</li>
     *   <li>StfkV4: Version 4 regular data query type in Austria.</li>
     * </ul>
     * This value is to be encoded as a ascii string.</p>
     * <p>Specification: petrol.</p>
     */
    ta_c_rpt_regular_data_query_type = 4,
    
    /**
     * <p>Customer data of the regular.</p>
     * <p>Specification: petrol.</p>
     */
    ta_c_rpt_regular_data = 5,
    
    /**
     * <p>Track 1 of a petrol card. This value is to be encoded as a ascii string.</p>
     * <p>Specification: petrol.</p>
     */
    ta_c_rpt_petrol_card_data1 = 6,
    
    /**
     * <p>Track 2 of a petrol card. This value is to be encoded as a ascii string.</p>
     * <p>Specification: petrol.</p>
     */
    ta_c_rpt_petrol_card_data2 = 7,
    
    /**
     * <p>Track 3 of a petrol card. This value is to be encoded as a ascii string.</p>
     * <p>Specification: petrol.</p>
     */
    ta_c_rpt_petrol_card_data3 = 8,
    
    /**
     * <p>Defines which card readers are active during the dialog. This is a bitmap. Value 0 = reader
     * not active, 1 = reader active.<br />
     * Example 1: Only magstripe reader active = 00000001 = 01 hex<br />
     * Example 2: Only contactless reader active = 00000100 = 04h<br />
     * Example 3: Magstripe, chip and contactless reader active = 00000111 = 07h
     * <ul>
     *   <li>Bit 1: Magstripe reader</li>
     *   <li>Bit 2: Chip reader</li>
     *   <li>Bit 3: Contactless reader</li>
     *   <li>Bit 4: RFU</li>
     *   <li>Bit 5: RFU</li>
     *   <li>Bit 6: RFU</li>
     *   <li>Bit 7: RFU</li>
     *   <li>Bit 8: RFU</li>
     * </ul>
     * This value is to be transmitted hex encoded. Example: For a value of 00000111 (Magstripe,
     * Chip and Ctless active), the value '07' hex must be transmitted.</p>
     * <p>Specification: petrol.</p>
     */
    ta_c_rpt_active_readers = 9,
    
    /**
     * <p>Currency Exponent e.g. to define input mask for Amount entry. n2 value<br />
     * Example 1: Exponent = 2 will result in an input mask of XXXX.XX with 2 positions after
     * decimal point.<br />
     * Example 2: Exponent = 3 will result in an input mask of XXX.XXX with 3 positions after
     * decimal point.</p>
     * <p>Specification: petrol.</p>
     */
    ta_c_rpt_exponent = 10,
    
    /**
     * <p>Mode of function key 1. Determines how the terminal handles the key pressed event of function
     * key 1. Valid values are:
     * <ul>
     *   <li>
     *     <pre>DISABLED</pre>
     *     : Do not show the function key. No action if the key is pressed.</li>
     *   <li>
     *     <pre>INTERRUPT</pre>
     *     : Default. The key interrupts the InitTransaction process. The press is reported through the ReasonCode.</li>
     *   <li>
     *     <pre>NOTIFY</pre>
     *     : The key does not interrupt the InitTransaction process. The press is reported through a KeyPress Notification.</li>
     * </ul></p>
     * <p>Specification: petrol.</p>
     */
    ta_c_rpt_key_mode_f1 = 11,
    
    /**
     * <p>Mode of function key 2. Determines how the terminal handles the key pressed event of function
     * key 2. Valid values are:
     * <ul>
     *   <li>
     *     <pre>DISABLED</pre>
     *     : Do not show the function key. No action if the key is pressed.</li>
     *   <li>
     *     <pre>INTERRUPT</pre>
     *     : Default. The key interrupts the InitTransaction process. The press is reported through the ReasonCode.</li>
     *   <li>
     *     <pre>NOTIFY</pre>
     *     : The key does not interrupt the InitTransaction process. The press is reported through a KeyPress Notification.</li>
     * </ul></p>
     * <p>Specification: petrol.</p>
     */
    ta_c_rpt_key_mode_f2 = 12,
    
    /**
     * <p>Mode of function key 3. Determines how the terminal handles the key pressed event of function
     * key 3. Valid values are:
     * <ul>
     *   <li>
     *     <pre>DISABLED</pre>
     *     : Do not show the function key. No action if the key is pressed.</li>
     *   <li>
     *     <pre>INTERRUPT</pre>
     *     : Default. The key interrupts the InitTransaction process. The press is reported through the ReasonCode.</li>
     *   <li>
     *     <pre>NOTIFY</pre>
     *     : The key does not interrupt the InitTransaction process. The press is reported through a KeyPress Notification.</li>
     * </ul></p>
     * <p>Specification: petrol.</p>
     */
    ta_c_rpt_key_mode_f3 = 13,
    
    /**
     * <p>Defines how many times a PIN or other code entry can be done before failing the dialog.<br />
     * Example: PinRetryCounter = 3, the PIN (or other code) can be entered 3 times in total before
     * the dialog fails.</p>
     * <p>Specification: petrol.</p>
     */
    ta_c_rpt_pin_retry_counter = 14
    
} ta_e_resource_parameter_type_t;

#endif // TA_RESOURCE_PARAMETER_TYPE_H
