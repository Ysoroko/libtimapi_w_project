/**
 * \file constants/result_code.h
 *
 * Result codes.
 *
 * Copyright: Worldline.
 */

#ifndef TA_RESULT_CODE_H
#define TA_RESULT_CODE_H


/**
 * <p>Result codes.</p>
 * <p>Guides: retail, valueAddedServices.</p>
 */
typedef enum ta_e_result_code{
    /**
     * Undefined/invalid value.
     */
    ta_c_rc_undefined = 0,
        
    
    
    /**
     * <p>Positive results.</p>
     * <p>Specification: retail.</p>
     */
    /** \name Positive results. */
    /** @{ */

    /**
     * <p>OK</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_ok = 1,
    
    /** @} */
    
    
    
    /**
     * <p>TIM API related results - General.</p>
     * <p>Specification: retail.</p>
     */
    /** \name TIM API related results - General. */
    /** @{ */

    /**
     * <p>Current request has been cancelled by the ECR.<br />
     *  <b>Error message:</b> Cancelled by ECR</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_api_cancel_ecr = 2,
    
    /**
     * <p>The ECR received an invalid answer.<br />
     *  <b>Error message:</b> Invalid answer</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_api_invalid_answer = 3,
    
    /**
     * <p>The current request cannot be handled because the required feature is disabled.<br />
     *  <b>Error message:</b> Message belongs to disabled feature</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_api_disabled_feature = 4,
    
    /**
     * <p>The requested function is not allowed with the current license Communication.<br />
     *  <b>Error message:</b> Function not allowed - License issue</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_api_function_disallowed = 5,
    
    /**
     * <p>Persistent data damaged, out of space or storage permission problem.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_api_persistency_problem = 6,
    
    /** @} */
    
    
    
    /**
     * <p>TIM API related results - Communication.</p>
     * <p>Guides: retail, valueAddedServices.</p>
     */
    /** \name TIM API related results - Communication. */
    /** @{ */

    /**
     * <p>The ECR was not able to connect to the TIM Server.<br />
     *  <b>Error message:</b> Could not connect to TIM Server</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_api_connect_fail_server = 7,
    
    /**
     * <p>The ECR was not able to connect to the EFT Terminal.<br />
     *  <b>Error message:</b> Could not connect to EFT Terminal</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_api_connect_fail_terminal = 8,
    
    /**
     * <p>The ECR lost the connection to the TIM Server.<br />
     *  <b>Error message:</b> Connection lost to TIM Server</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_api_connection_lost_server = 9,
    
    /**
     * <p>The ECR lost the connection to the EFT Terminal.<br />
     *  <b>Error message:</b> Connection lost to EFT Terminal</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_api_connection_lost_terminal = 10,
    
    /**
     * <p>No ethernet cable has been connected.<br />
     *  <b>Error message:</b> Ethernet cable not connected</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_ethernet_disconnected = 11,
    
    /**
     * <p>No RS232 cable has been connected.<br />
     *  <b>Error message:</b> RS232 cable not connected</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_rs232_disconnected = 12,
    
    /**
     * <p>Timeout during connection establishment from TIM API to TIM Server.<br />
     *  <b>Error message:</b> Timeout - Communication TIM Server</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_api_timeout_server = 13,
    
    /**
     * <p>Timeout during connection establishment from TIM API to EFT Terminal.<br />
     *  <b>Error message:</b> Timeout - Communication EFT Terminal</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_api_timeout_terminal = 14,
    
    /**
     * <p>ECR did not respond in time.<br />
     *  <b>Error message:</b> Timeout - ECR</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_tim_timeout_ecr = 56,
    
    /**
     * <p>EFT terminal not able to connect to payment host.<br />
     *  <b>Error message:</b> Could not connect to payment host</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_tim_connect_fail_payment_host = 57,
    
    /**
     * <p>EFT Terminal did lose connection to payment host.<br />
     *  <b>Error message:</b> Connection lost to payment host</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_tim_connection_lost_payment_host = 58,
    
    /**
     * <p>RS232 device did not respond in time.<br />
     *  <b>Error message:</b> Timeout - Answer RS232</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_tim_timeout_answer_rs232 = 59,
    
    /**
     * <p>Communication failed.<br />
     *  <b>Error message:</b> Communication failure</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_tim_communication_failure = 60,
    
    /**
     * <p>Reconfig request partially successful - Config failed.<br />
     *  <b>Error message:</b> Config failed</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_tim_config_failure = 61,
    
    /**
     * <p>Reconfig request partially successful - Init not or only partially successful.<br />
     *  <b>Error message:</b> Init not or only partially successful</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_tim_init_failure = 62,
    
    /**
     * <p>Connection to host timed out. The transaction outcome is unknown. The user must use another
     * channel to verify the outcome.<br />
     *  <b>Error message:</b> Host Timeout - Outcome unknown - Use another channel to verify outcome</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_host_timeout_outcome_unknown = 151,
    
    /**
     * <p><p>Third Party App not available (reasons may be: not installed, not enabled or no connection
     * possible).</p>
     * <p>Error message: Third Party App not available - <additional information if available></p></p>
     * <p>Specification: valueAddedServices.</p>
     */
    ta_c_rc_third_party_app_not_available = 150,
    
    /**
     * <p><p>Unsupported reference age to check against was entered on ECR. (If other values are
     * entered than are supported on the payment protocol.).</p>
     * <p>Error message: Invalid request - Unsupported reference age</p></p>
     * <p>Specification: valueAddedServices.</p>
     */
    ta_c_rc_unsupported_reference_age = 153,
    
    /** @} */
    
    
    
    /**
     * <p>TIM Server related results - General.</p>
     * <p>Specification: retail.</p>
     */
    /** \name TIM Server related results - General. */
    /** @{ */

    /**
     * <p>TIM Server received an invalid answer.<br />
     *  <b>Error message:</b> Invalid answer</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_server_invalid_answer = 15,
    
    /**
     * <p>TIM Server received an invalid request from TIM API.<br />
     *  <b>Error message:</b> Invalid request</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_server_invalid_request = 16,
    
    /**
     * <p>TIM Server received a message that requires a disabled feature.<br />
     *  <b>Error message:</b> Message belongs to disabled feature</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_server_disabled_feature = 17,
    
    /**
     * <p>Persistent data damaged, out of space or storage permission problem.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_server_persistency_problem = 18,
    
    /** @} */
    
    
    
    /**
     * <p>TIM Server related results - Communication.</p>
     * <p>Specification: retail.</p>
     */
    /** \name TIM Server related results - Communication. */
    /** @{ */

    /**
     * <p>TIM Server was not able to connect to EFT Terminal.<br />
     *  <b>Error message:</b> Could not connect to EFT Terminal</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_server_connect_fail_terminal = 19,
    
    /**
     * <p>TIM Server lost connection to the EFT Terminal.<br />
     *  <b>Error message:</b> Connection lost to EFT Terminal</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_server_connection_lost_terminal = 20,
    
    /**
     * <p>Timeout during connection establishment from TIM Server to EFT Terminal.<br />
     *  <b>Error message:</b> Timeout - Communication EFT Terminal</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_server_timeout_terminal = 21,
    
    /** @} */
    
    
    
    /**
     * <p>TIM API related results - Hardware General.</p>
     * <p>Specification: retail.</p>
     */
    /** \name TIM API related results - Hardware General. */
    /** @{ */

    /**
     * <p>Chip card reader not available.<br />
     *  <b>Error message:</b> Device not available - CCR</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_ccr_unavailable = 22,
    
    /**
     * <p>Magstripe card reader not available.<br />
     *  <b>Error message:</b> Device not available - MCR</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_mcr_unavailable = 23,
    
    /**
     * <p>Contactless card reader not available.<br />
     *  <b>Error message:</b> Device not available - NFC</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_nfc_unavailable = 24,
    
    /**
     * <p>Display not available.<br />
     *  <b>Error message:</b> Device not available - Display</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_display_unavailable = 25,
    
    /**
     * <p>PinPad not available.<br />
     *  <b>Error message:</b> Device not available - PinPad<br />
     * </p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_pin_pad_unavailable = 26,
    
    /**
     * <p>RS232 device not available.<br />
     *  <b>Error message:</b> Device not available - RS232</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_rs232_unavailable = 27,
    
    /**
     * <p>Connected RS232 device not configured.<br />
     *  <b>Error message:</b> Device not configured - RS232</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_rs232_not_configured = 28,
    
    /**
     * <p>Something went wrong during the SW Update process.<br />
     *  <b>Error message:</b> SW Installation failed</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_sw_installation_failed = 29,
    
    /**
     * <p>SW version set for update in the SCS is not suitable for the device.<br />
     *  <b>Error message:</b> SW version not suitable</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_sw_version_not_suitable = 30,
    
    /**
     * <p>SW authentication failed due to hash check failure.<br />
     *  <b>Error message:</b> SW authentication failed</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_sw_authentication_failed = 31,
    
    /** @} */
    
    
    
    /**
     * <p>TIM API related results - CardReader.</p>
     * <p>Specification: retail.</p>
     */
    /** \name TIM API related results - CardReader. */
    /** @{ */

    /**
     * <p>Chip card reader error occured.<br />
     *  <b>Error message:</b> Card reader error - CCR</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_card_reader_error_ccr = 32,
    
    /**
     * <p>Magstripe card reader error occured.<br />
     *  <b>Error message:</b> Card reader error - MCR</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_card_reader_error_mcr = 33,
    
    /**
     * <p>Contactless card reader error occured.<br />
     *  <b>Error message:</b> Card reader error - NFC</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_card_reader_error_nfc = 34,
    
    /**
     * <p>Card error occured using the chip card reader.<br />
     *  <b>Error message:</b> Card error - CCR<br />
     * </p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_card_error_ccr = 35,
    
    /**
     * <p>Card error occured using the magstripe card reader.<br />
     *  <b>Error message:</b> Card error - MCR</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_card_error_mcr = 36,
    
    /**
     * <p>Card error occured using the contactless card reader.<br />
     *  <b>Error message:</b> Card error - NFC</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_card_error_nfc = 37,
    
    /**
     * <p>Reading error occured during card reading.<br />
     *  <b>Error message:</b> Read error</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_card_read_error = 38,
    
    /**
     * <p>Timeout occured during card reading.<br />
     *  <b>Error message:</b> Read timeout</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_card_read_timeout = 39,
    
    /**
     * <p>Cardholder did not insert card during timeout.<br />
     *  <b>Error message:</b> Card insertion timeout</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_card_insertion_timeout = 40,
    
    /**
     * <p>Keys lost for secure communication.<br />
     *  <b>Error message:</b> Keys lost - Card reader</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_card_reader_keys_lost = 41,
    
    /**
     * <p>Security error occured.<br />
     *  <b>Error message:</b> Security error</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_card_reader_security_error = 42,
    
    /**
     * <p>Card did not respond in time.<br />
     *  <b>Error message:</b> Card timeout</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_card_timeout = 43,
    
    /**
     * <p>Card could not be read.<br />
     *  <b>Error message:</b> Card not readable</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_card_not_readable = 44,
    
    /**
     * <p>Invalid card data read.<br />
     *  <b>Error message:</b> Card - invalid data</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_card_invalid_data = 45,
    
    /**
     * <p>Corresponding card function not found.<br />
     *  <b>Error message:</b> Card - function not found</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_card_function_not_found = 46,
    
    /**
     * <p>Card function not allowed.<br />
     *  <b>Error message:</b> Card - function not allowed</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_card_function_not_allowed = 47,
    
    /**
     * <p>Card unexpectedly present in card reader.<br />
     *  <b>Error message:</b> Card unexpectedly present</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_card_unexpectedly_present_in_reader = 48,
    
    /** @} */
    
    
    
    /**
     * <p>TIM API related results - PinPad.</p>
     * <p>Specification: retail.</p>
     */
    /** \name TIM API related results - PinPad. */
    /** @{ */

    /**
     * <p>Security error occured.<br />
     *  <b>Error message:</b> Security error</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_pin_pad_security_error = 49,
    
    /**
     * <p>PinPad has be tampered.<br />
     *  <b>Error message:</b> Tampered</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_pin_pad_tampered = 50,
    
    /**
     * <p>Keys lost for secure communication.<br />
     *  <b>Error message:</b> Keys lost - PinPad</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_pin_pad_keys_lost = 51,
    
    /**
     * <p>Terminal serial number mismatch in TMS.<br />
     *  <b>Error message:</b> Serial number already in use. Terminal is out of order. Please call hotline.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_serial_number_mismatch = 52,
    
    /** @} */
    
    
    
    /**
     * <p>TIM API related results - Cardholder.</p>
     * <p>Specification: retail.</p>
     */
    /** \name TIM API related results - Cardholder. */
    /** @{ */

    /**
     * <p>Cardholder cancelled transaction pushing the Stop key.<br />
     *  <b>Error message:</b> Stop - Cardholder</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_cardholder_stop = 53,
    
    /**
     * <p>Cardholder did not react in time.<br />
     *  <b>Error message:</b> Timeout - Cardholder</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_cardholder_timeout = 54,
    
    /**
     * <p>Card has been removed by the cardholder.<br />
     *  <b>Error message:</b> Card removed</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_card_removed = 55,
    
    /** @} */
    
    
    
    /**
     * <p>TIM API related results - SIXml Protocol.</p>
     * <p>Specification: retail.</p>
     */
    /** \name TIM API related results - SIXml Protocol. */
    /** @{ */

    /**
     * <p>General error on SIXml Protocol.<br />
     *  <b>Error message:</b> General error</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_sixml_general_error = 63,
    
    /**
     * <p>Generic error if request not valid.<br />
     *  <b>Error message:</b> Invalid request - Generic</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_sixml_invalid_request = 64,
    
    /**
     * <p>Wrong UsrId entered for Activate.<br />
     *  <b>Error message:</b> Invalid request - Wrong cashier</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_sixml_wrong_cashier = 65,
    
    /**
     * <p>Wrong EcrId entered for Login.<br />
     *  <b>Error message:</b> Invalid request - Wrong EcrId</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_sixml_wrong_ecr_id = 66,
    
    /**
     * <p>Unknown reference number entered, e.g. for Credit, Reversal or FinalizePurchase.<br />
     *  <b>Error message:</b> Invalid request - Unknown reference number</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_sixml_unknown_reference_number = 67,
    
    /**
     * <p>Request not allowed in the current terminal state.<br />
     *  <b>Error message:</b> Message not allowed in this state</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_sixml_wrong_state = 68,
    
    /**
     * <p>Another controller is currently using the EFT.<br />
     *  <b>Error message:</b> Busy (Other controller)</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_busy_other_controller = 69,
    
    /**
     * <p>Mainenance task in progress.<br />
     *  <b>Error message:</b> Busy (Maintenance)</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_busy_maintenance = 70,
    
    /**
     * <p>Another request from the same controller is already running.<br />
     *  <b>Error message:</b> Busy - Another request running</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_request_pending = 71,
    
    /**
     * <p>Request not supported by terminal.<br />
     *  <b>Error message:</b> Request not supported by terminal</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_sixml_unsupported_request = 72,
    
    /**
     * <p>Failure to wake the terminal from sleep. Request cannot be processed. <b>Error message:</b>
     * Terminal does not wake up</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_terminal_wakeup_failure = 73,
    
    /** @} */
    
    
    
    /**
     * <p>TIM API related results - Transaction.</p>
     * <p>Specification: retail.</p>
     */
    /** \name TIM API related results - Transaction. */
    /** @{ */

    /**
     * <p>No common application found on card during Application Selection.<br />
     *  <b>Error message:</b> No common applications found</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_trx_no_common_applications = 74,
    
    /**
     * <p>Current transaction exceeds transaction limit (amount).<br />
     *  <b>Error message:</b> Transaction limit exceeded</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_trx_limit_exceeded = 75,
    
    /**
     * <p>No common cardholder verification method found on card during.<br />
     *  <b>Error message:</b> No common CVM found</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_trx_no_common_cvm = 76,
    
    /**
     * <p>Performed CVM failed.<br />
     *  <b>Error message:</b> Declined - CVM failed</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_declined_cvm_failed = 77,
    
    /**
     * <p>Referral required for current transaction.<br />
     *  <b>Error message:</b> Referral</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_trx_referral = 78,
    
    /**
     * <p>Authorization response invalid.<br />
     *  <b>Error message:</b> Invalid auth response</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_trx_invalid_auth_response = 79,
    
    /**
     * <p>Authorization failed, generic error.<br />
     *  <b>Error message:</b> Authorization declined - Generic</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_declined_generic = 80,
    
    /**
     * <p>Authorization failed, saldo too low.<br />
     *  <b>Error message:</b> Authorization declined - Saldo too low</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_declined_saldo_too_low = 81,
    
    /**
     * <p>Authorization failed, cardholder entered wrong PIN.<br />
     *  <b>Error message:</b> Authorization declined - Wrong PIN</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_declined_wrong_pin = 82,
    
    /**
     * <p>Authorization failed, card blocked.<br />
     *  <b>Error message:</b> Authorization declined - Card blocked</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_declined_card_blocked = 83,
    
    /**
     * <p>Authorization failed, security issue.<br />
     *  <b>Error message:</b> Authorization declined - Security issue</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_declined_security_issue = 84,
    
    /**
     * <p>Authorization failed, usage control.<br />
     *  <b>Error message:</b> Authorization declined - Usage control</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_declined_usage_control = 85,
    
    /**
     * <p>Authorization failed, current transaction may be a double transaction.<br />
     *  <b>Error message:</b> Authorization declined - Double transaction</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_declined_double_transaction = 86,
    
    /**
     * <p>Authorization failed, first AC generation failed.<br />
     *  <b>Error message:</b> Authorization declined - Generic, first AC</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_declined_generic_first_ac = 87,
    
    /**
     * <p>Authorization failed, second AC generation failed.<br />
     *  <b>Error message:</b> Authorization declined - Generic, second AC</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_declined_generic_second_ac = 88,
    
    /**
     * <p>Commit request not sent in time.<br />
     *  <b>Error message:</b> Commit timeout</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_trx_commit_timeout = 89,
    
    /**
     * <p>Rollback not possible for current transaction.<br />
     *  <b>Error message:</b> Rollback not possible</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_trx_rollback_impossible = 90,
    
    /**
     * <p>The intended cashback amount is too low.<br />
     *  <b>Error message:</b> Cashback amount too low</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_cashback_amount_too_low = 91,
    
    /**
     * <p>The intended cashback amount is too high.<br />
     *  <b>Error message:</b> Cashback amount to high</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_cashback_amount_too_high = 92,
    
    /**
     * <p>Part of the basket is not allowed. Transaction declined.<br />
     *  <b>Error message:</b> Basket declined</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_basket_declined = 93,
    
    /**
     * <p>Current transaction exceeds the limit for the number of transactions in a group.<br />
     *  <b>Error message:</b> No trx in group exceeded</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_no_trx_in_group_exceeded = 94,
    
    /**
     * <p>Current request contains unsupported characters.<br />
     *  <b>Error message:</b> Unsupported characters in message</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_unsupported_characters_in_message = 95,
    
    /**
     * <p>So far no loyalty data is available, check-in pending.<br />
     *  <b>Error message:</b> Loyalty check-in pending</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_loyalty_check_in_pending = 96,
    
    /**
     * <p>Authorization failed, card error.<br />
     *  <b>Error message:</b> Authorization declined - Card error</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_declined_card_error = 97,
    
    /**
     * <p>Authorization failed, card expired.<br />
     *  <b>Error message:</b> Authorization declined - Card expired</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_declined_card_expired = 98,
    
    /**
     * <p>Authorization failed, transaction invalid.<br />
     *  <b>Error message:</b> Authorization declined - Trx invalid</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_declined_trx_invalid = 99,
    
    /**
     * <p>Authorization failed, try later.<br />
     *  <b>Error message:</b> Authorization declined - Try later</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_declined_try_later = 100,
    
    /**
     * <p>Authorization failed, try another interface.<br />
     *  <b>Error message:</b> Authorization declined - Try another interface</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_declined_try_another_interface = 101,
    
    /**
     * <p>Authorization failed, invalid merchant.<br />
     *  <b>Error message:</b> Authorization declined - Invalid merchant</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_declined_invalid_merchant = 102,
    
    /**
     * <p>Authorization failed, restriction declined.<br />
     *  <b>Error message:</b> Authorization declined - Restriction declined</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_declined_restriction_declined = 103,
    
    /**
     * <p>Authorization failed, wrong currency.<br />
     *  <b>Error message:</b> Authorization declined - Wrong currency</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_declined_wrong_currency = 104,
    
    /**
     * <p>Authorization failed, autoreversal pending.<br />
     *  <b>Error message:</b> Authorization declined - Autoreversal pending</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_declined_autoreversal_pending = 105,
    
    /**
     * <p>Authorization failed, wrong card number.<br />
     *  <b>Error message:</b> Authorization declined - Wrong card number</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_declined_wrong_card_number = 106,
    
    /**
     * <p>Authorization failed, wrong card expiry date.<br />
     *  <b>Error message:</b> Authorization declined - Wrong card expiry date</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_declined_wrong_card_expiry_date = 107,
    
    /**
     * <p>Authorization failed, retry, temporary unavailable.<br />
     *  <b>Error message:</b> Authorization declined - Retry, temporary unavailable</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_declined_retry_temporary_unavailable = 108,
    
    /**
     * <p>Authorization failed, service not allowed.<br />
     *  <b>Error message:</b> Authorization declined - Service not allowed</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_declined_service_not_allowed = 109,
    
    /**
     * <p>Authorization failed, cardholder information issue.<br />
     *  <b>Error message:</b> Authorization declined - Cardholder information issue</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_declined_cardholder_information_issue = 110,
    
    /**
     * <p>Authorization failed, wrong auth code.<br />
     *  <b>Error message:</b> Referral declined - Wrong auth code</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_declined_referral_wrong_auth_code = 111,
    
    /**
     * <p>Authorization failed, wrong amount.<br />
     *  <b>Error message:</b> Referral declined - Wrong amount</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_declined_referral_wrong_amount = 112,
    
    /**
     * <p>Authorization failed, referral generic.<br />
     *  <b>Error message:</b> Referral declined - Other reason</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_declined_referral_other_reason = 113,
    
    /**
     * <p>Capture card, generic.<br />
     *  <b>Error message:</b> Capture card - Generic</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_declined_capture_card_generic = 114,
    
    /**
     * <p>Capture card, information to the client.<br />
     *  <b>Error message:</b> Capture card - Information to the client</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_declined_capture_card_info_to_client = 115,
    
    /**
     * <p>Capture card, order to the client.<br />
     *  <b>Error message:</b> Capture card - Order to the client</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_declined_capture_card_order_to_client = 116,
    
    /**
     * <p>Capture card, timeout removing card from terminal.<br />
     *  <b>Error message:</b> Capture card - Timeout removing card from terminal</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_declined_capture_card_timeout_removing_card = 117,
    
    /**
     * <p>Authorization failed, not supported.<br />
     *  <b>Error message:</b> Authorization declined - Not supported</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_declined_not_supported = 118,
    
    /**
     * <p>Value out of range in this context, e.g. negative where only positive values are
     * supported.<br />
     *  <b>Error message:</b> Value out of range in this context</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_value_out_of_range_in_this_context = 119,
    
    /**
     * <p>The (mobile topup) voucher cannot be generated with this combination of issuer and value.<br
     * />
     *  <b>Error message:</b> Requested voucher not available</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_voucher_type_not_available = 120,
    
    /**
     * <p>The InitTransaction <em>FunctionHint</em> is not compatible to the transaction function. No
     * recovery possible.<br />
     *  <b>Error message:</b> Transaction mismatch</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_transaction_mismatch = 121,
    
    /**
     * <p>The (mobile topup) voucher cannot be reversed.<br />
     *  <b>Error message:</b> Voucher reversal failed</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_voucher_cannot_be_reversed = 122,
    
    /**
     * <p>Authorization failed, amount invalid.<br />
     *  <b>Error message:</b> Authorization declined - Amount invalid</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_declined_amount_invalid = 123,
    
    /**
     * <p>Products in basket not allowed. Transaction declined.<br />
     *  <b>Error message:</b> Products not allowed</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_moc_products_not_allowed = 124,
    
    /**
     * <p>Mileage entered is not correct. Transaction declined.<br />
     *  <b>Error message:</b> Incorrect Mileage</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_moc_incorrect_mileage = 125,
    
    /**
     * <p>Car number entered is not correct. Transaction declined.<br />
     *  <b>Error message:</b> Incorrect Car Number</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_moc_incorrect_car_number = 126,
    
    /**
     * <p>Driver code entered is not correct. Transaction declined.<br />
     *  <b>Error message:</b> Incorrect Driver Code</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_moc_incorrect_driver_code = 127,
    
    /**
     * <p>Fleet ID entered is not correct. Transaction declined.<br />
     *  <b>Error message:</b> Incorrect Fleet ID</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_moc_incorrect_fleet_id = 128,
    
    /**
     * <p>Additional information entered is not correct. Transaction declined.<br />
     *  <b>Error message:</b> Incorrect Additional Info</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_moc_incorrect_additional_info = 129,
    
    /**
     * <p>Employee number entered is not correct. Transaction declined.<br />
     *  <b>Error message:</b> Incorrect Employee Number</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_moc_incorrect_employee_number = 130,
    
    /**
     * <p>Cost centre entered is not correct. Transaction declined.<br />
     *  <b>Error message:</b> Incorrect Cost Centre</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_moc_incorrect_cost_centre = 131,
    
    /**
     * <p>Project number entered is not correct. Transaction declined.<br />
     *  <b>Error message:</b> Incorrect Project Number</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_moc_incorrect_project_number = 132,
    
    /**
     * <p>License plate entered not correct. Transaction declined.<br />
     *  <b>Error message:</b> Incorrect License Plate</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_moc_incorrect_license_plate = 133,
    
    /**
     * <p>Reference entered is not correct. Transaction declined.<br />
     *  <b>Error message:</b> Incorrect Reference</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_moc_incorrect_reference = 134,
    
    /**
     * <p>The card is blacklisted . Transaction declined.<br />
     *  <b>Error message:</b> Card Blacklisted</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_card_blacklisted = 135,
    
    /**
     * <p>Product not supported . Transaction declined.<br />
     *  <b>Error message:</b> Transaction declined - Product not supported</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_product_not_supported = 136,
    
    /**
     * <p><p>No card account selectable with given account restrictions.</p>
     * <p> <b>Error message:</b> No card account selectable with given account restrictions</p></p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_no_account_selectable_with_given_restrictions = 137,
    
    /**
     * <p><p>Transaction type not allowed for selected account.</p>
     * <p> <b>Error message:</b> Transaction type not allowed for selected account</p></p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_transaction_type_not_allowed_for_selected_account = 138,
    
    /**
     * <p><p>Action not allowed on the transaction. E.g. do a refund on a not captured purchase. / Do a
     * refund with higher amount than the original purchase amount.</p>
     * <p> <b>Error message:</b> Action not allowed on the transaction</p></p>
     * <p>Specification: retail.</p>
     */
    ta_c_rc_action_not_allowed_on_the_transaction = 152,
    
    /** @} */
    
    
    
    /** \name C-API Runtime Errors. */
    /** @{ */

    /**
     * \brief Invalid argument.
     */
    ta_c_rc_invalid_argument = 139,
    
    /**
     * \brief Out of memory.
     */
    ta_c_rc_out_of_memory = 140,
    
    /**
     * System error.
     */
    ta_c_rc_system_error = 141
    
    /** @} */

} ta_e_result_code_t;

#endif // TA_RESULT_CODE_H
