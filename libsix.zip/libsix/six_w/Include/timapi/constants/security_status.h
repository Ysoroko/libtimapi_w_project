/**
 * \file constants/security_status.h
 *
 * Constants for SecurityStatus tag.
 *
 * Copyright: Worldline.
 */

#ifndef TA_SECURITY_STATUS_H
#define TA_SECURITY_STATUS_H


/**
 * <p>Constants for SecurityStatus tag.</p>
 * <p>Specification: retail.</p>
 */
typedef enum ta_e_security_status{
    /**
     * Undefined/invalid value.
     */
    ta_c_ss_undefined = 0,
    
    /**
     * <p>The security has actively been disabled (i.e. some form of test mode).</p>
     * <p>Specification: retail.</p>
     */
    ta_c_ss_disabled = 1,
    
    /**
     * <p>The security is working correctly.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_ss_active = 2,
    
    /**
     * <p>The security system is in tampered state. Key lost.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_ss_tampered = 3
    
} ta_e_security_status_t;

#endif // TA_SECURITY_STATUS_H
