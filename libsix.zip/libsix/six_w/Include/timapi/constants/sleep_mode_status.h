/**
 * \file constants/sleep_mode_status.h
 *
 * Constants for SleepModeStatus tag.
 *
 * Copyright: Worldline.
 */

#ifndef TA_SLEEP_MODE_STATUS_H
#define TA_SLEEP_MODE_STATUS_H


/**
 * <p>Constants for SleepModeStatus tag.</p>
 * <p>Specification: retail.</p>
 */
typedef enum ta_e_sleep_mode_status{
    /**
     * Undefined/invalid value.
     */
    ta_c_sms_undefined = 0,
    
    /**
     * <p>Terminal enters sleep mode.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_sms_entering_sleep = 1,
    
    /**
     * <p>Terminal wakes up from sleep mode.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_sms_waking_up = 2
    
} ta_e_sleep_mode_status_t;

#endif // TA_SLEEP_MODE_STATUS_H
