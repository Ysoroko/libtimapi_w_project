/**
 * \file constants/status_functions.h
 *
 * Flag constants for FeatureType and OptionType sixml:StatusFunctions value.
 *
 * Copyright: Worldline.
 */

#ifndef TA_STATUS_FUNCTIONS_H
#define TA_STATUS_FUNCTIONS_H


/**
 * <p>Flag constants for FeatureType and OptionType sixml:StatusFunctions value.</p>
 * <p>Specification: retail.</p>
 */
typedef enum ta_e_status_functions{
    /**
     * Undefined/invalid value.
     */
    ta_c_sf_undefined = 0,
    
    /**
     * <p>Feature request function supported.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_sf_feature_request = 1 << 0,
    
    /**
     * <p>Terminal status function supported.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_sf_terminal_status = 1 << 1,
    
    /**
     * <p>System information function supported.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_sf_system_information = 1 << 2,
    
    /**
     * <p>Application information function supported.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_sf_application_information = 1 << 3,
    
    /**
     * <p>Hardware information function supported.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_sf_hardware_information = 1 << 4,
    
    /**
     * <p>Keep alive function supported.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_sf_keep_alive = 1 << 5,
    
    /**
     * <p>Licence changed function supported.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_sf_license_changed = 1 << 6,
    
    /**
     * <p>Vas info function supported.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_sf_vas_info = 1 << 7,
    
    /**
     * <p>Error function supported.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_sf_error = 1 << 8,
    
    /**
     * <p>Change language function supported.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_sf_change_language = 1 << 9,
    
    /**
     * <p>Key press function supported.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_sf_key_press = 1 << 10,
    
    /**
     * <p>Configuration changed function supported.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_sf_configuration_changed = 1 << 11,
    
    /**
     * <p>WakeUp function supported.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_sf_wake_up = 1 << 12,
    
    /**
     * <p>Transaction information function supported.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_sf_transaction_info_request = 1 << 13
    
} ta_e_status_functions_t;

#endif // TA_STATUS_FUNCTIONS_H
