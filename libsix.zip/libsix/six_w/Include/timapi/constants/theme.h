/**
 * \file constants/theme.h
 *
 * <p>Defines the appearance of the dialog.</p>
 * <p>The following values are valid:</p>
 *
 * Copyright: Worldline.
 */

#ifndef TA_THEME_H
#define TA_THEME_H


/**
 * <p><p>Defines the appearance of the dialog.</p>
 * <p>The following values are valid:</p></p>
 * <p>Specification: dialog.</p>
 */
typedef enum ta_e_theme{
    /**
     * Undefined/invalid value.
     */
    ta_c_theme_undefined = 0,
    
    /**
     * <p>Standard SIX appearance.</p>
     * <p>Specification: dialog.</p>
     */
    ta_c_theme_six = 1,
    
    /**
     * <p>Swiss Post appearance.</p>
     * <p>Specification: dialog.</p>
     */
    ta_c_theme_swiss_post = 2
    
} ta_e_theme_t;

#endif // TA_THEME_H
