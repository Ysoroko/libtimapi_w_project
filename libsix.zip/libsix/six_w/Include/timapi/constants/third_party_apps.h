/**
 * \file constants/third_party_apps.h
 *
 * Flag constants for FeatureType and OptionType ThirdPartyApps value.
 *
 * Copyright: Worldline.
 */

#ifndef TA_THIRD_PARTY_APPS_H
#define TA_THIRD_PARTY_APPS_H


/**
 * <p>Flag constants for FeatureType and OptionType ThirdPartyApps value.</p>
 * <p>Specification: valueAddedServices.</p>
 */
typedef enum ta_e_third_party_apps{
    /**
     * Undefined/invalid value.
     */
    ta_c_tpa_undefined = 0,
    
    /**
     * <p>Slave app written by Linkly (Australian POS service provider)</p>
     * <p>Specification: valueAddedServices.</p>
     */
    ta_c_tpa_linkly_slave_app = 1 << 0
    
} ta_e_third_party_apps_t;

#endif // TA_THIRD_PARTY_APPS_H
