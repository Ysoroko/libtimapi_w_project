/**
 * \file constants/transaction_reason.h
 *
 * <p>Contains information on the purpose of the transaction and the credential on file
 * establishment.</p>
 *
 * Copyright: Worldline.
 */

#ifndef TA_TRANSACTION_REASON_H
#define TA_TRANSACTION_REASON_H


/**
 * <p><p>Contains information on the purpose of the transaction and the credential on file
 * establishment.</p></p>
 * <p>Specification: retail.</p>
 */
typedef enum ta_e_transaction_reason{
    /**
     * Undefined/invalid value.
     */
    ta_c_tr_undefined = 0,
    
    /**
     * <p>Establish credentials on file for installment payment</p>
     * <p>Specification: retail.</p>
     */
    ta_c_tr_installment = 1,
    
    /**
     * <p>Establish credentials on file for recurring payment</p>
     * <p>Specification: retail.</p>
     */
    ta_c_tr_recurring = 2,
    
    /**
     * <p>Establish credentials on file for unscheduled payment</p>
     * <p>Specification: retail.</p>
     */
    ta_c_tr_unscheduled = 3,
    
    /**
     * <p>Establish credentials on file for recurring payment, with fixed amount</p>
     * <p>Specification: retail.</p>
     */
    ta_c_tr_recurring_fixed = 4
    
} ta_e_transaction_reason_t;

#endif // TA_TRANSACTION_REASON_H
