/**
 * \file constants/transaction_status.h
 *
 * <p>Information of the current transaction state.</p>
 * <p>This field is returned in the TerminalStatus notification to give the current transaction
 * state from the terminal.</p>
 * <p>The following values are valid:</p>
 *
 * Copyright: Worldline.
 */

#ifndef TA_TRANSACTION_STATUS_H
#define TA_TRANSACTION_STATUS_H


/**
 * <p><p>Information of the current transaction state.</p>
 * <p>This field is returned in the TerminalStatus notification to give the current transaction
 * state from the terminal.</p>
 * <p>The following values are valid:</p></p>
 * <p>Specification: retail.</p>
 */
typedef enum ta_e_transaction_status{
    /**
     * Undefined/invalid value.
     */
    ta_c_ts_undefined = 0,
    
    /**
     * <p>The terminal is busy doing an action by itself, without an open request from the ECR. E.g. a
     * timed Balance.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_ts_busy = 1,
    
    /**
     * <p>No transaction running.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_ts_idle = 2,
    
    /**
     * <p>Transaction started, no card inserted.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_ts_wait_for_card = 3,
    
    /**
     * <p>Reading card data and matching applications.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_ts_reading_card = 4,
    
    /**
     * <p>Application selection is ongoing. May require cardholder interaction.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_ts_application_selection = 5,
    
    /**
     * <p>Terminal waits for another ECR command.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_ts_wait_for_proceed = 6,
    
    /**
     * <p>DCC selection in progress.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_ts_dcc_selection = 7,
    
    /**
     * <p>Tip Entry in progress.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_ts_enter_tip = 8,
    
    /**
     * <p>CVM PIN has been selected. PIN entry in progress.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_ts_pin_entry = 9,
    
    /**
     * <p>CVM Signature has been selected. Signature capture ongoing.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_ts_signature_capture = 10,
    
    /**
     * <p>Payment processing in progress.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_ts_processing = 11,
    
    /**
     * <p>AutoCommit is disabled. Waiting for Commit from ECR.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_ts_wait_for_commit = 12,
    
    /**
     * <p>Account selection is ongoing. May require cardholder interaction.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_ts_account_selection = 13
    
} ta_e_transaction_status_t;

#endif // TA_TRANSACTION_STATUS_H
