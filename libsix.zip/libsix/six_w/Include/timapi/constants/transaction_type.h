/**
 * \file constants/transaction_type.h
 *
 * <p>Defines the type of transaction.</p>
 * <p>Used as attribute to classify the transaction in the <sixml:TrxDetail> field.</p>
 * <p>The following values are valid:</p>
 *
 * Copyright: Worldline.
 */

#ifndef TA_TRANSACTION_TYPE_H
#define TA_TRANSACTION_TYPE_H


/**
 * <p><p>Defines the type of transaction.</p>
 * <p>Used as attribute to classify the transaction in the <sixml:TrxDetail> field.</p>
 * <p>The following values are valid:</p></p>
 * <p>Guides: retail, petrol, unattended, advancedRetail, banking, hospitality, valueAddedServices.</p>
 */
typedef enum ta_e_transaction_type{
    /**
     * Undefined/invalid value.
     */
    ta_c_tt_undefined = 0,
    
    /**
     * <p>Sale transaction.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_tt_purchase = 1,
    
    /**
     * <p>Credit transaction. (Refund)</p>
     * <p>Specification: retail.</p>
     */
    ta_c_tt_credit = 2,
    
    /**
     * <p>Reversal of a transaction.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_tt_reversal = 3,
    
    /**
     * <p>PreAuthorization function.</p>
     * <p>Specification: petrol.</p>
     */
    ta_c_tt_pre_authorization = 4,
    
    /**
     * <p>Finalize purchase / Online advice function.</p>
     * <p>Specification: petrol.</p>
     */
    ta_c_tt_finalize_purchase = 5,
    
    /**
     * <p>Debt recovery.</p>
     * <p>Specification: unattended.</p>
     */
    ta_c_tt_debt_recovery = 6,
    
    /**
     * <p>Cash advance function.</p>
     * <p>Specification: advancedRetail.</p>
     */
    ta_c_tt_cash_advance = 7,
    
    /**
     * <p>Purchase function with forced acceptance function.</p>
     * <p>Specification: advancedRetail.</p>
     */
    ta_c_tt_purchase_forced_acceptance = 8,
    
    /**
     * <p>Purchase function with cashback amount.</p>
     * <p>Specification: advancedRetail.</p>
     */
    ta_c_tt_purchase_with_cashback = 9,
    
    /**
     * <p>Purchase function phone authorized.</p>
     * <p>Specification: advancedRetail.</p>
     */
    ta_c_tt_purchase_phone_authorized = 10,
    
    /**
     * <p>Purchase function phone ordered.</p>
     * <p>Specification: advancedRetail.</p>
     */
    ta_c_tt_purchase_phone_ordered = 11,
    
    /**
     * <p>Purchase function mail ordered.</p>
     * <p>Specification: advancedRetail.</p>
     */
    ta_c_tt_purchase_mail_ordered = 12,
    
    /**
     * <p>Account verification.</p>
     * <p>Specification: advancedRetail.</p>
     */
    ta_c_tt_account_verification = 13,
    
    /**
     * <p>Giro</p>
     * <p>Specification: banking.</p>
     */
    ta_c_tt_giro = 14,
    
    /**
     * <p>Combined</p>
     * <p>Specification: banking.</p>
     */
    ta_c_tt_combined = 15,
    
    /**
     * <p>Authorize credit</p>
     * <p>Specification: banking.</p>
     */
    ta_c_tt_authorize_credit = 16,
    
    /**
     * <p>Authorize deposit</p>
     * <p>Specification: banking.</p>
     */
    ta_c_tt_authorize_deposit = 17,
    
    /**
     * <p>Reservation function.</p>
     * <p>Specification: hospitality.</p>
     */
    ta_c_tt_reservation = 18,
    
    /**
     * <p>Adjust reservation function.</p>
     * <p>Specification: hospitality.</p>
     */
    ta_c_tt_adjust_reservation = 19,
    
    /**
     * <p>Cancel reservation function.</p>
     * <p>Specification: hospitality.</p>
     */
    ta_c_tt_cancel_reservation = 20,
    
    /**
     * <p>Purchase reservation function.</p>
     * <p>Specification: hospitality.</p>
     */
    ta_c_tt_purchase_reservation = 21,
    
    /**
     * <p>Purchase reservation phone authorized function.</p>
     * <p>Specification: hospitality.</p>
     */
    ta_c_tt_purchase_reservation_phone_authorized = 22,
    
    /**
     * <p>Load Voucher.</p>
     * <p>Specification: valueAddedServices.</p>
     */
    ta_c_tt_load_voucher = 23,
    
    /**
     * <p>Collect Points</p>
     * <p>Specification: valueAddedServices.</p>
     */
    ta_c_tt_collect_points = 24,
    
    /**
     * <p>Funding</p>
     * <p>Specification: valueAddedServices.</p>
     */
    ta_c_tt_funding = 25,
    
    /**
     * <p>Renfunding</p>
     * <p>Specification: valueAddedServices.</p>
     */
    ta_c_tt_refunding = 26,
    
    /**
     * <p>Load</p>
     * <p>Specification: valueAddedServices.</p>
     */
    ta_c_tt_load = 27,
    
    /**
     * <p>Unload</p>
     * <p>Specification: valueAddedServices.</p>
     */
    ta_c_tt_unload = 28,
    
    /**
     * <p>Activate card</p>
     * <p>Specification: valueAddedServices.</p>
     */
    ta_c_tt_activate_card = 29
    
} ta_e_transaction_type_t;

#endif // TA_TRANSACTION_TYPE_H
