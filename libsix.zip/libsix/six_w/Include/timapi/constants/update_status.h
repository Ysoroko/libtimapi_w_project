/**
 * \file constants/update_status.h
 *
 * <p>Contains the current software update status.</p>
 * <p>Used in the SoftwareUpdate response returned by the treminal.</p>
 * <p>The following values are valid:</p>
 *
 * Copyright: Worldline.
 */

#ifndef TA_UPDATE_STATUS_H
#define TA_UPDATE_STATUS_H


/**
 * <p><p>Contains the current software update status.</p>
 * <p>Used in the SoftwareUpdate response returned by the treminal.</p>
 * <p>The following values are valid:</p></p>
 * <p>Specification: retail.</p>
 */
typedef enum ta_e_update_status{
    /**
     * Undefined/invalid value.
     */
    ta_c_us_undefined = 0,
    
    /**
     * <p>The actual software is up to date and no software update will be made.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_us_up_to_date = 1,
    
    /**
     * <p>The software update is running. No terminal reboot is needed to complete it.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_us_running_no_reboot = 2,
    
    /**
     * <p>The software update is running. At least one (or more) terminal reboot(s) is/are needed to
     * complete it.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_us_running_reboot = 3
    
} ta_e_update_status_t;

#endif // TA_UPDATE_STATUS_H
