/**
 * \file constants/vas_info_list_type.h
 *
 * <p>Defines what kind of information will be available in the VasInformationList.</p>
 * <p>The following values are valid:</p>
 *
 * Copyright: Worldline.
 */

#ifndef TA_VAS_INFO_LIST_TYPE_H
#define TA_VAS_INFO_LIST_TYPE_H


/**
 * <p><p>Defines what kind of information will be available in the VasInformationList.</p>
 * <p>The following values are valid:</p></p>
 * <p>Specification: valueAddedServices.</p>
 */
typedef enum ta_e_vas_info_list_type{
    /**
     * Undefined/invalid value.
     */
    ta_c_vilt_undefined = 0,
    
    /**
     * <p>WOL matching information, no WOL-Program information</p>
     * <p>Specification: valueAddedServices.</p>
     */
    ta_c_vilt_wol_match = 1,
    
    /**
     * <p>WOL-Program information</p>
     * <p>Specification: valueAddedServices.</p>
     */
    ta_c_vilt_wol_program = 2,
    
    /**
     * <p>TWINT information</p>
     * <p>Specification: valueAddedServices.</p>
     */
    ta_c_vilt_twint = 3
    
} ta_e_vas_info_list_type_t;

#endif // TA_VAS_INFO_LIST_TYPE_H
