/**
 * \file constants/vas_info_type.h
 *
 * <p>Specifies type of value added services information.</p>
 * <p>Field that describes the content of its parent <sixml:VasInformation> tag.</p>
 *
 * Copyright: Worldline.
 */

#ifndef TA_VAS_INFO_TYPE_H
#define TA_VAS_INFO_TYPE_H


/**
 * <p><p>Specifies type of value added services information.</p>
 * <p>Field that describes the content of its parent <sixml:VasInformation> tag.</p></p>
 * <p>Specification: valueAddedServices.</p>
 */
typedef enum ta_e_vas_info_type{
    /**
     * Undefined/invalid value.
     */
    ta_c_vit_undefined = 0,
    
    /**
     * <p>VAS Alternative Identifier, e.g. for WOL. Alternative Identifier for the transaction given by
     * the ECR or terminal</p>
     * <p>Specification: valueAddedServices.</p>
     */
    ta_c_vit_alt_id = 1,
    
    /**
     * <p>VAS Transaction Match. Indication if PAN is available on VAS host: 0=no, 1=yes</p>
     * <p>Specification: valueAddedServices.</p>
     */
    ta_c_vit_trx_match = 2,
    
    /**
     * <p>VAS Transaction Identification. VAS specific ID for this transaction, e.g. used for WOL.</p>
     * <p>Specification: valueAddedServices.</p>
     */
    ta_c_vit_trx_id = 3,
    
    /**
     * <p>VAS Identification Timestamp. Timestamp of the VAS identification.</p>
     * <p>Specification: valueAddedServices.</p>
     */
    ta_c_vit_trx_ident_time = 4,
    
    /**
     * <p>VAS User Alias. E.g. WOL specific Alias of the WOL User linked with the used card.</p>
     * <p>Specification: valueAddedServices.</p>
     */
    ta_c_vit_user_alias = 5,
    
    /**
     * <p>VAS Card Alias. E.g. WOL specific Alias of the used card.</p>
     * <p>Specification: valueAddedServices.</p>
     */
    ta_c_vit_card_alias = 6,
    
    /**
     * <p>Aggregated Forward Data To ECR Indicator. Flag indicating wether at least one included VAS
     * program requires to forward the data from e.g the VAS enabled terminal to the ECR.</p>
     * <p>Specification: valueAddedServices.</p>
     */
    ta_c_vit_agr_data_to_ecrindicator = 7,
    
    /**
     * <p>Aggregated Request Additional VAS Data Indicator. Flag indicating wether at least one
     * included VAS program requires to request additional the data from a VAS provider.</p>
     * <p>Specification: valueAddedServices.</p>
     */
    ta_c_vit_agr_req_add_vasdata_indicator = 8,
    
    /**
     * <p>Aggregated Forward Result Data To Host Indicator. Flag indicating wether at least one
     * included VAS program requires to forward the result data e.g. to the WOL Host.</p>
     * <p>Specification: valueAddedServices.</p>
     */
    ta_c_vit_agr_res_data_to_hst_indicator = 9,
    
    /**
     * <p>Amount Matching VAS Program. Indicates how many e.g. WOL program matches the processed
     * transaction.</p>
     * <p>Specification: valueAddedServices.</p>
     */
    ta_c_vit_amt_vasprg = 10,
    
    /**
     * <p>Matching VAS Program Container. Containing VAS Programs with specific data.</p>
     * <p>Specification: valueAddedServices.</p>
     */
    ta_c_vit_vasprg_ctnr = 11,
    
    /**
     * <p>VAS Program ID. E.g. WOL program specific identifier like 123</p>
     * <p>Specification: valueAddedServices.</p>
     */
    ta_c_vit_vasprg_id = 12,
    
    /**
     * <p>VAS Program Name. E.g. WOL program name like "Miles and More collect points".</p>
     * <p>Specification: valueAddedServices.</p>
     */
    ta_c_vit_vasprg_name = 13,
    
    /**
     * <p>VAS Program Match ID. E.g. WOL specific match ID for this specific transaction.</p>
     * <p>Specification: valueAddedServices.</p>
     */
    ta_c_vit_vasprg_mtch_id = 14,
    
    /**
     * <p>VAS Specific ID. E.g. WOL program VAS identification number, e.g. M and M ID or loyalty
     * reference for TWINT.</p>
     * <p>Specification: valueAddedServices.</p>
     */
    ta_c_vit_vasspec_id = 15,
    
    /**
     * <p>Forward Data To ECR Indicator. Flag indicating wether for this specific VAS program it is
     * required to send additional data to ECR.</p>
     * <p>Specification: valueAddedServices.</p>
     */
    ta_c_vit_data_to_ecrind = 16,
    
    /**
     * <p>Request Additional VAS Data Indicator. Flag indicating wether for this specific VAS program
     * it is required to request additional data from a VAS provider.</p>
     * <p>Specification: valueAddedServices.</p>
     */
    ta_c_vit_req_add_vasdata_ind = 17,
    
    /**
     * <p>Additional VAS Data Communication Mode. Indicates how the VAS advanced data should be
     * transmitted between VAS enabled terminal and VAS provider. Allowed values: 0: no
     * communication required, 1: ep2 request/response, 2: out-of-band</p>
     * <p>Specification: valueAddedServices.</p>
     */
    ta_c_vit_add_vasdata_com_md = 18,
    
    /**
     * <p>Forward Result Data To Host Indicator. Flag indicating wether for this specific VAS program
     * will forward the result data to the VAS Host.</p>
     * <p>Specification: valueAddedServices.</p>
     */
    ta_c_vit_res_data_to_hst_ind = 19,
    
    /**
     * <p>Additional VAS Data. Free to use container for VAS specific data, max. 3000 chars. E.g. TWINT
     * extended reference description.</p>
     * <p>Specification: valueAddedServices.</p>
     */
    ta_c_vit_add_vasdata = 20,
    
    /**
     * <p>VAS Supported Version. Supported VAS specification version (e.g. WOL version) by the terminal
     * software, has to be set by the terminal software based on the implemented VAS specification
     * version.</p>
     * <p>Specification: valueAddedServices.</p>
     */
    ta_c_vit_support_ver = 21
    
} ta_e_vas_info_type_t;

#endif // TA_VAS_INFO_TYPE_H
