/**
 * \file
 * \brief Contains information about a currency supported by a brand.
 * \details Object type \em currency_item.
 */

#ifndef TA_CURRENCY_ITEM_H
#define TA_CURRENCY_ITEM_H

#include "common/object.h"
#include "common/boolean.h"
#include "constants/currency.h"
#include "constants/currency_type.h"


#ifdef __cplusplus
extern "C" {
#endif


/**
 * \brief Supported or used currency.
 * 
 * \param[in] currency_item Object instance of type [currency_item](\ref currency_item.h).
 * \param[out] currency Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Object instance written to \em currency.
 * \retval ta_c_rc_invalid_argument \em currency_item is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em currency_item is not of type [currency_item](\ref currency_item.h).
 * \retval ta_c_rc_invalid_argument \em currency is \em null-pointer.
 */
extern ta_e_result_code_t ta_currency_item_get_currency(
	ta_object_t currency_item,
	ta_e_currency_t* currency );

/**
 * \brief Type of currency.
 * 
 * \param[in] currency_item Object instance of type [currency_item](\ref currency_item.h).
 * \param[out] currency_type Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Object instance written to \em currency_type.
 * \retval ta_c_rc_invalid_argument \em currency_item is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em currency_item is not of type [currency_item](\ref currency_item.h).
 * \retval ta_c_rc_invalid_argument \em currency_type is \em null-pointer.
 */
extern ta_e_result_code_t ta_currency_item_get_currency_type(
	ta_object_t currency_item,
	ta_e_currency_type_t* currency_type );


#ifdef __cplusplus
}
#endif

#endif
