/**
 * \file
 * \brief Display product info.
 * \details Object type \em display_product_info.
 */

#ifndef TA_DISPLAY_PRODUCT_INFO_H
#define TA_DISPLAY_PRODUCT_INFO_H

#include "color.h"
#include "common/object.h"
#include "common/boolean.h"
#include "constants/image_file_format.h"


#ifdef __cplusplus
extern "C" {
#endif


/**
 * \brief Create display product info.
 * 
 * \param[out] info Pointer to variable to write created object instance to.
 *                     Created object instance is retained.
 * 
 * \retval ta_c_rc_ok Object instance has been created and written to \em info.
 * \retval ta_c_rc_invalid_argument \em info is \em null-pointer.
 * \retval ta_c_rc_out_of_memory Failed allocating memory.
 */
extern ta_e_result_code_t ta_display_product_info_create(
	ta_object_t *info );

/**
 * \brief Create copy of display product info.
 * 
 * \param[out] info Pointer to variable to write created object instance to.
 *                     Created object instance is retained.
 * \param[in] source_info Object of type [display_product_info](\ref display_product_info.h) to create copy of.
 * 
 * \retval ta_c_rc_ok Object instance has been created and written to \em info.
 * \retval ta_c_rc_invalid_argument \em info is \em null-pointer.
 * \retval ta_c_rc_invalid_argument \em source_info is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em source_info is not of type
 *                                  \em display_product_info.
 * \retval ta_c_rc_out_of_memory Failed allocating memory.
 */
extern ta_e_result_code_t ta_display_product_info_copy(
	ta_object_t* info,
	const ta_object_t* source_info );



/**
 * \brief Image file format.
 * 
 * \param[in] info Object instance of type [display_product_info](\ref display_product_info.h).
 * \param[out] image_file_format Pointer to variable to write value to. Value is
 *                               \em ta_c_iff_undefined if value is not set in \em info.
 * 
 * \retval ta_c_rc_ok Value written to \em image_file_format.
 * \retval ta_c_rc_invalid_argument \em info is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em info is not of type [display_product_info](\ref display_product_info.h).
 * \retval ta_c_rc_invalid_argument \em image_file_format is \em null-pointer.
 */
extern ta_e_result_code_t ta_display_product_info_get_image_file_format(
	ta_object_t info,
	ta_e_image_file_format_t* image_file_format );

/**
 * \brief Set image file format.
 * 
 * \param[in] info Object instance of type [display_product_info](\ref display_product_info.h).
 * \param[in] image_file_format Value to set.
 * 
 * \retval ta_c_rc_ok Value assigned to \em info.
 * \retval ta_c_rc_invalid_argument \em info is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em info is not of type [display_product_info](\ref display_product_info.h).
 * \retval ta_c_rc_invalid_argument \em image_file_format is \em ta_c_iff_undefined.
 */
extern ta_e_result_code_t ta_display_product_info_set_image_file_format(
	ta_object_t info,
	ta_e_image_file_format_t image_file_format );



/**
 * \brief Image file width in pixels.
 * 
 * \param[in] info Object instance of type [display_product_info](\ref display_product_info.h).
 * \param[out] image_file_width Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Value written to \em image_file_width.
 * \retval ta_c_rc_invalid_argument \em info is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em info is not of type [display_product_info](\ref display_product_info.h).
 * \retval ta_c_rc_invalid_argument \em image_file_width is \em null-pointer.
 */
extern ta_e_result_code_t ta_display_product_info_get_image_file_width(
	ta_object_t info,
	int* image_file_width );

/**
 * \brief Set image file width in pixels.
 * 
 * \param[in] info Object instance of type [display_product_info](\ref display_product_info.h).
 * \param[in] image_file_width Value to set.
 * 
 * \retval ta_c_rc_ok Value assigned to \em info.
 * \retval ta_c_rc_invalid_argument \em info is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em info is not of type [display_product_info](\ref display_product_info.h).
 * \retval ta_c_rc_invalid_argument \em image_file_width is less than 1.
 */
extern ta_e_result_code_t ta_display_product_info_set_image_file_width(
	ta_object_t info,
	int image_file_width );



/**
 * \brief Image file height in pixels.
 * 
 * \param[in] info Object instance of type [display_product_info](\ref display_product_info.h).
 * \param[out] image_file_height Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Value written to \em image_file_height.
 * \retval ta_c_rc_invalid_argument \em info is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em info is not of type [display_product_info](\ref display_product_info.h).
 * \retval ta_c_rc_invalid_argument \em image_file_height is \em null-pointer.
 */
extern ta_e_result_code_t ta_display_product_info_get_image_file_height(
	ta_object_t info,
	int* image_file_height );

/**
 * \brief Set image file height in pixels.
 * 
 * \param[in] info Object instance of type [display_product_info](\ref display_product_info.h).
 * \param[in] image_file_height Value to set.
 * 
 * \retval ta_c_rc_ok Value assigned to \em info.
 * \retval ta_c_rc_invalid_argument \em info is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em info is not of type [display_product_info](\ref display_product_info.h).
 * \retval ta_c_rc_invalid_argument \em image_file_height is less than 1.
 */
extern ta_e_result_code_t ta_display_product_info_set_image_file_height(
	ta_object_t info,
	int image_file_height );



/**
 * \brief Image data in specified format.
 * 
 * \param[in] info Object instance of type [display_product_info](\ref display_product_info.h).
 * \param[out] data Pointer to variable to write object instance to. Object instance is
 *                  of type [string](\ref string.h) and is not retained. Object instance is
 *                  \em ta_object_invalid if value is not set in \em info.
 * 
 * \retval ta_c_rc_ok Object instance written to \em data.
 * \retval ta_c_rc_invalid_argument \em info is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em info is not of type [display_product_info](\ref display_product_info.h).
 * \retval ta_c_rc_invalid_argument \em data is \em null-pointer.
 */
extern ta_e_result_code_t ta_display_product_info_get_image_data(
	ta_object_t info,
	ta_object_t* data );

/**
 * \brief Set image data in specified format.
 * 
 * \param[in] info Object instance of type [display_product_info](\ref display_product_info.h).
 * \param[in] data Object instance to set. Object instance can be \em ta_object_invalid
 *                 to clear the value in \em info. If object instance is not
 *                 ta_object_invalid is has to be of type [string](\ref string.h).
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em info.
 * \retval ta_c_rc_invalid_argument \em info is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em info is not of type [display_product_info](\ref display_product_info.h).
 * \retval ta_c_rc_invalid_argument \em data is not \em ta_object_invalid and is not of type [string](\ref string.h).
 */
extern ta_e_result_code_t ta_display_product_info_set_image_data(
	ta_object_t info,
	ta_object_t data );



/**
 * \brief Background color.
 * 
 * \param[in] info Object instance of type [display_product_info](\ref display_product_info.h).
 * \param[out] background_color Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Value written to \em background_color.
 * \retval ta_c_rc_invalid_argument \em info is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em info is not of type [display_product_info](\ref display_product_info.h).
 * \retval ta_c_rc_invalid_argument \em background_color is \em null-pointer.
 */
extern ta_e_result_code_t ta_display_product_info_get_background_color(
	ta_object_t info,
	ta_s_color_t* background_color );

/**
 * \brief Set background color.
 * 
 * \param[in] info Object instance of type [display_product_info](\ref display_product_info.h).
 * \param[in] background_color Pointer to value to set.
 * 
 * \retval ta_c_rc_ok Value assigned to \em info.
 * \retval ta_c_rc_invalid_argument \em info is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em info is not of type [display_product_info](\ref display_product_info.h).
 * \retval ta_c_rc_invalid_argument \em background_color is \em null-pointer.
 */
extern ta_e_result_code_t ta_display_product_info_set_background_color(
	ta_object_t info,
	const ta_s_color_t* background_color );



/**
 * \brief Product display name.
 * 
 * \param[in] info Object instance of type [display_product_info](\ref display_product_info.h).
 * \param[out] name Pointer to variable to write object instance to. Object instance is
 *                  of type [string](\ref string.h) and is not retained. Object instance is
 *                  \em ta_object_invalid if value is not set in \em info.
 * 
 * \retval ta_c_rc_ok Object instance written to \em name.
 * \retval ta_c_rc_invalid_argument \em info is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em info is not of type [display_product_info](\ref display_product_info.h).
 * \retval ta_c_rc_invalid_argument \em name is \em null-pointer.
 */
extern ta_e_result_code_t ta_display_product_info_get_product_display_name(
	ta_object_t info,
	ta_object_t* name );

/**
 * \brief Set product display name.
 * 
 * \param[in] info Object instance of type [display_product_info](\ref display_product_info.h).
 * \param[in] name Object instance to set. Object instance can be \em ta_object_invalid
 *                 to clear the value in \em info. If object instance is not
 *                 ta_object_invalid is has to be of type [string](\ref string.h).
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em info.
 * \retval ta_c_rc_invalid_argument \em info is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em info is not of type [display_product_info](\ref display_product_info.h).
 * \retval ta_c_rc_invalid_argument \em name is not \em ta_object_invalid and is not of type [string](\ref string.h).
 */
extern ta_e_result_code_t ta_display_product_info_set_product_display_name(
	ta_object_t info,
	ta_object_t name );


#ifdef __cplusplus
}
#endif

#endif
