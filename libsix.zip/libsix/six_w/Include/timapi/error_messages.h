/**
 * \file
 * \brief Error messages.
 */

#ifndef TA_ERROR_MESSAGES_H
#define TA_ERROR_MESSAGES_H

#include <stdint.h>

#include "common/object.h"
#include "constants/result_code.h"


#ifdef __cplusplus
extern "C" {
#endif


/**
 * \brief Get translation for error text matching terminal language.
 * 
 * \param[out] message Pointer to variable to write object instance to. Object instance is of
 *                     type \em string and is retained.
 * \param[in] result_code Result code to get error message for.
 * \param[in] terminal Terminal object to get language from. Object of type [terminal](\ref terminal.h).
 *                     You have to call ta_terminal_system_information or
 *                     ta_terminal_system_information_async first to obtain the terminal
 *                     language. Otherwise the default language is used.
 * \retval ta_c_rc_ok Object instance written to \em message.
 * \retval ta_c_rc_invalid_argument \em message is \em null-pointer.
 * \retval ta_c_rc_invalid_argument \em terminal is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em result_code is not a valid result code.
 * \retval ta_c_rc_out_of_memory Failed allocating memory.
 */
extern ta_e_result_code_t ta_error_message_get_terminal(
	ta_object_t* message,
	ta_e_result_code_t result_code,
	ta_object_t terminal );

/**
 * \brief Get translation for error text.
 * 
 * \param[out] message Pointer to variable to write object instance to. Object instance is of
 *                     type \em string and is retained.
 * \param[in] result_code Result code to get error message for.
 * \param[in] language Language code to get error message for. If no entry for language is
 *                     found the default error message is returned. Use null-pointer to get
 *                     the default error message.
 * \retval ta_c_rc_ok Object instance written to \em message.
 * \retval ta_c_rc_invalid_argument \em message is \em null-pointer.
 * \retval ta_c_rc_invalid_argument \em result_code is not a valid result code.
 * \retval ta_c_rc_out_of_memory Failed allocating memory.
 */
extern ta_e_result_code_t ta_error_message_get_language(
	ta_object_t* message,
	ta_e_result_code_t result_code,
	const char* language );


#ifdef __cplusplus
}
#endif

#endif
