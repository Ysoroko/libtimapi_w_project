/**
 * \file
 * \brief Item quantity.
 * \details Object type \em item_quantity.
 */

#ifndef TA_ITEM_QUANTITY_H
#define TA_ITEM_QUANTITY_H

#include "common/object.h"
#include "common/boolean.h"


#ifdef __cplusplus
extern "C" {
#endif


/**
 * \brief Create object of type [item_quantity](\ref item_quantity.h).
 * 
 * \param[out] item_quantity Pointer to variable to write created object instance to.
 *                           Created object instance is retained.
 * 
 * \retval ta_c_rc_ok Object instance has been created and written to \em item.
 * \retval ta_c_rc_invalid_argument \em item_quantity is \em null-pointer.
 * \retval ta_c_rc_out_of_memory Failed allocating memory.
 */
extern ta_e_result_code_t ta_item_quantity_create(
	ta_object_t *item_quantity );


/**
 * \brief Quantity of the product.
 * 
 * \param[in] item_quantity Object instance of type [item_quantity](\ref item_quantity.h).
 * \param[out] quantity Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Object instance written to \em quantity.
 * \retval ta_c_rc_invalid_argument \em item_quantity is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em item_quantity is not of type [item_quantity](\ref item_quantity.h).
 * \retval ta_c_rc_invalid_argument \em quantity is \em null-pointer.
 */
extern ta_e_result_code_t ta_item_quantity_get_quantity(
	ta_object_t item_quantity,
	int* quantity );

/**
 * \brief Set quantity of the product.
 * 
 * \param[in] item_quantity Object instance of type [item_quantity](\ref item_quantity.h).
 * \param[in] quantity Quantity to set.
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em item.
 * \retval ta_c_rc_invalid_argument \em item_quantity is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em item_quantity is not of type [item_quantity](\ref item_quantity.h).
 */
extern ta_e_result_code_t ta_item_quantity_set_quantity(
	ta_object_t item_quantity,
	int quantity );


/**
 * \brief Exponent of quantity of the product.
 * 
 * \param[in] item_quantity Object instance of type [item_quantity](\ref item_quantity.h).
 * \param[out] exponent Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Object instance written to \em exponent.
 * \retval ta_c_rc_invalid_argument \em item_quantity is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em item_quantity is not of type [item_quantity](\ref item_quantity.h).
 * \retval ta_c_rc_invalid_argument \em exponent is \em null-pointer.
 */
extern ta_e_result_code_t ta_item_quantity_get_exponent(
	ta_object_t item_quantity,
	int* exponent );

/**
 * \brief Set exponent of quantity of the product.
 * 
 * \param[in] item_quantity Object instance of type [item_quantity](\ref item_quantity.h).
 * \param[in] exponent Exponent to set.
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em item.
 * \retval ta_c_rc_invalid_argument \em item_quantity is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em item_quantity is not of type [item_quantity](\ref item_quantity.h).
 */
extern ta_e_result_code_t ta_item_quantity_set_exponent(
	ta_object_t item_quantity,
	int exponent );


/**
 * \brief Type of quantity of the product.
 * 
 * \param[in] item_quantity Object instance of type [item_quantity](\ref item_quantity.h).
 * \param[out] type Pointer to variable to write object instance to. Object
 *                  instance is of type [string](\ref string.h) and is not retained.
 * 
 * \retval ta_c_rc_ok Object instance written to \em type.
 * \retval ta_c_rc_invalid_argument \em item_quantity is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em item_quantity is not of type [item_quantity](\ref item_quantity.h).
 * \retval ta_c_rc_invalid_argument \em type is \em null-pointer.
 */
extern ta_e_result_code_t ta_item_quantity_get_quantity_type(
	ta_object_t item_quantity,
	ta_object_t *type );

/**
 * \brief Set type of quantity of the product.
 * 
 * \param[in] item_quantity Object instance of type [item_quantity](\ref item_quantity.h).
 * \param[in] type Object instance to set. Object instance can be \em ta_object_invalid
 *                 to clear the value in \em item. If object instance is not
 *                 ta_object_invalid is has to be of type [string](\ref string.h).
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em item.
 * \retval ta_c_rc_invalid_argument \em item is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em item is not of type [item_quantity](\ref item_quantity.h).
 * \retval ta_c_rc_invalid_argument \em type is not \em ta_object_invalid and
 *                                  is not of type [string](\ref string.h).
 */
extern ta_e_result_code_t ta_item_quantity_set_type(
	ta_object_t item_quantity,
	ta_object_t type );


#ifdef __cplusplus
}
#endif

#endif
