/**
 * \file
 * \brief Logging.
 */

#ifndef TA_LOGGING_H
#define TA_LOGGING_H


#include <time.h>

#include "constants/result_code.h"


#ifdef __cplusplus
extern "C" {
#endif


/** \brief Log levels. */
typedef enum ta_e_log_level{
	/** \brief Disable. */
	ta_c_ll_off,
	
	/** \brief Severe error. */
	ta_c_ll_severe,
	
	/** \brief Warning. */
	ta_c_ll_warning,
	
	/** \brief Information. */
	ta_c_ll_info,
	
	/** \brief Fine debug details. */
	ta_c_ll_fine,
	
	/** \brief Finest debug details. */
	ta_c_ll_finest
} ta_e_log_level_t;


/** \brief Read-only log record stack trace. */
typedef struct ta_s_log_record_stack_trace{
	/** \brief File name. */
	const char *file;
	
	/** \brief Method name. */
	const char *method;
	
	/** \brief Line number. */
	int line;
} ta_s_log_record_stack_trace_t;


/**
 * \brief Read-only log record.
 */
typedef struct ta_s_log_record{
	/** \brief Log level. */
	ta_e_log_level_t level;
	
	/** \brief Thread identifier. */
	unsigned int thread;
	
	/** \brief File name. */
	const char *file;
	
	/** \brief Method name. */
	const char *method;
	
	/** \brief Line number. */
	int line;
	
	/**
	 * \brief Message text.
	 * 
	 * \warning Message text is potentially very long for example for SIXml logging.
	 *          Using *printf family of functions runs the risk of buffer overflow
	 *          causing segmentation faults. To avoid problems use the *nprintf
	 *          family of functions. These take a buffer size parameter and avoid
	 *          writing past the buffer size in all situations.
	 */
	const char *message;
	
	/** \brief Optional list of parameters or 0 if empty. */
	const char **parameters;
	
	/** \brief Number of parameters. */
	int parameter_count;
	
	/** \brief Stack trace entries or 0 if empty. */
	const ta_s_log_record_stack_trace_t *stack_trace;
	
	/** \brief Number of stack trace entries. */
	int stack_trace_count;
	
	/** \brief Timestamp. */
	time_t timetstamp;
} ta_s_log_record_t;



/**
 * \brief Callback to publish log record.
 * 
 * \param[in] record Log record.
 * \param[in] user_pointer User pointer used while setting the callback.
 */
typedef void ( *ta_cb_publish_log_record )(
	const ta_s_log_record_t *record,
	void *user_pointer );



/**
 * \brief Set custom global logger callback.
 * 
 * If not null-pointer the callback is used whenever the global logger needs to publish a new
 * log record. The global logger is used when no terminal function is used, hence any function
 * not of ta_terminal_*. You can use the same logger for both global and terminal specific
 * logging. If no custom terminal logger is set the global one is used if set.
 * 
 * \param[in] callback Callback to set. Can be \em null-pointer to disable.
 * \param[in] user_pointer User pointer to use in the callback.
 */
extern void ta_logger_set_global_logger(
	ta_cb_publish_log_record callback,
	void *user_pointer );


#ifdef __cplusplus
}
#endif

#endif
