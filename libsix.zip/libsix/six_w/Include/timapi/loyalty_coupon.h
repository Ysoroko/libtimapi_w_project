/**
 * \file
 * \brief Loyalty coupon. Contains amount value given by merchant.
 * \details Object type \em loyalty_coupon.
 */

#ifndef TA_LOYALTY_COUPON_H
#define TA_LOYALTY_COUPON_H

#include "common/object.h"
#include "common/boolean.h"
#include "constants/currency.h"
#include "constants/coupon_rejection_reason.h"


#ifdef __cplusplus
extern "C" {
#endif


/**
 * \brief Create object of type [loyalty_coupon](\ref loyalty_coupon.h).
 * 
 * \param[out] loyalty_coupon Pointer to variable to write created object instance to.
 *                            Created object instance is retained.
 * \param[in] amount Coupon amount in minor units as object of type [integer](\ref integer.h).
 * \param[in] currency Currency of amount.
 * \param[in] exponent Exponent of amount as object of type [integer](\ref integer.h).
 * \param[in] id Coupon ID.
 * \param[in] rejection_reason Rejection reason.
 * 
 * \retval ta_c_rc_ok Object instance has been created and written to \em loyalty_coupon.
 * \retval ta_c_rc_invalid_argument \em loyalty_coupon is \em null-pointer.
 * \retval ta_c_rc_invalid_argument \em currency is not a valid value from \em ta_e_currency_t.
 * \retval ta_c_rc_invalid_argument \em amount is less than 0.
 * \retval ta_c_rc_invalid_argument \em exponent is less than 0.
 * \retval ta_c_rc_invalid_argument \em amount is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em exponent is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em id is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em rejection_reason is not a valid value from
 *                                  \em ta_e_coupon_rejection_reason_t.
 * \retval ta_c_rc_out_of_memory Failed allocating memory.
 */
extern ta_e_result_code_t ta_loyalty_coupon_create(
	ta_object_t *loyalty_coupon,
	ta_object_t amount,
	ta_e_currency_t currency,
	ta_object_t exponent,
	ta_object_t id,
	ta_e_coupon_rejection_reason_t rejection_reason );


/**
 * \brief Coupon amount.
 * 
 * \param[in] loyalty_coupon Object instance of type [loyalty_coupon](\ref loyalty_coupon.h).
 * \param[out] amount Pointer to variable to write value to. Object 
 *                      instance of type [integer](\ref integer.h) and is not retained.
 * 
 * \retval ta_c_rc_ok Object instance written to \em amount.
 * \retval ta_c_rc_invalid_argument \em loyalty_coupon is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em loyalty_coupon is not of type [loyalty_coupon](\ref loyalty_coupon.h).
 * \retval ta_c_rc_invalid_argument \em amount is \em null-pointer.
 */
extern ta_e_result_code_t ta_loyalty_coupon_get_amount(
	ta_object_t loyalty_coupon,
	ta_object_t* amount );

/**
 * \brief Coupon currency.
 * 
 * \param[in] loyalty_coupon Object instance of type [loyalty_coupon](\ref loyalty_coupon.h).
 * \param[out] currency Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Object instance written to \em amount.
 * \retval ta_c_rc_invalid_argument \em loyalty_coupon is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em loyalty_coupon is not of type [loyalty_coupon](\ref loyalty_coupon.h).
 * \retval ta_c_rc_invalid_argument \em currency is \em null-pointer.
 */
extern ta_e_result_code_t ta_loyalty_coupon_get_currency(
	ta_object_t loyalty_coupon,
	ta_e_currency_t* currency );

/**
 * \brief Exponent of coupon amount.
 * 
 * \param[in] loyalty_coupon Object instance of type [loyalty_coupon](\ref loyalty_coupon.h).
 * \param[out] exponent Pointer to variable to write value to. Object 
 *                      instance of type [integer](\ref integer.h) and is not retained.
 * 
 * \retval ta_c_rc_ok Object instance written to \em exponent.
 * \retval ta_c_rc_invalid_argument \em loyalty_coupon is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em loyalty_coupon is not of type [loyalty_coupon](\ref loyalty_coupon.h).
 * \retval ta_c_rc_invalid_argument \em exponent is \em null-pointer.
 */
extern ta_e_result_code_t ta_loyalty_coupon_get_exponent(
	ta_object_t loyalty_coupon,
	ta_object_t* exponent );

/**
 * \brief Coupon ID.
 * 
 * \param[in] loyalty_coupon Object instance of type [loyalty_coupon](\ref loyalty_coupon.h).
 * \param[out] id Pointer to variable to write object instance to. Object
 *                  instance is of type [string](\ref string.h) and is not retained.
 * 
 * \retval ta_c_rc_ok Object instance written to \em id.
 * \retval ta_c_rc_invalid_argument \em loyalty_coupon is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em loyalty_coupon is not of type [loyalty_coupon](\ref loyalty_coupon.h).
 * \retval ta_c_rc_invalid_argument \em id is \em null-pointer.
 */
extern ta_e_result_code_t ta_loyalty_coupon_get_id(
	ta_object_t loyalty_coupon,
	ta_object_t *id );

/**
 * \brief Coupon rejection reason.
 * 
 * \param[in] loyalty_coupon Object instance of type [loyalty_coupon](\ref loyalty_coupon.h).
 * \param[out] rejection_reason Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Object instance written to \em rejection_reason.
 * \retval ta_c_rc_invalid_argument \em loyalty_coupon is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em loyalty_coupon is not of type [loyalty_coupon](\ref loyalty_coupon.h).
 * \retval ta_c_rc_invalid_argument \em rejection_reason is \em null-pointer.
 */
extern ta_e_result_code_t ta_loyalty_coupon_get_rejection_reason(
	ta_object_t loyalty_coupon,
	ta_e_coupon_rejection_reason_t *rejection_reason );


#ifdef __cplusplus
}
#endif

#endif
