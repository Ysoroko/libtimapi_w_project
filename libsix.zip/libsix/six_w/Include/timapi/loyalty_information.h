/**
 * \file
 * \brief Loyalty information. Value depending on LoyaltyInfoType.
 * \details Object type \em loyalty_information.
 */

#ifndef TA_LOYALTY_INFORMATION_H
#define TA_LOYALTY_INFORMATION_H

#include "common/object.h"
#include "common/boolean.h"
#include "constants/currency.h"
#include "constants/loyalty_function_type.h"


#ifdef __cplusplus
extern "C" {
#endif


/**
 * \brief Create object of type [loyalty_information](\ref loyalty_information.h).
 * 
 * \param[out] loyalty_information Pointer to variable to write created object instance to.
 *                            Created object instance is retained.
 * \param[in] value Value of information. Object instance has to be of type [string](\ref string.h)
 *                  and is retained.
 * \param[in] loyalty_info_type Information type. Object instance has to be of type
 *                              [string](\ref string.h) and is retained.
 * 
 * \retval ta_c_rc_ok Object instance has been created and written to \em loyalty_information.
 * \retval ta_c_rc_invalid_argument \em loyalty_information is \em null-pointer.
 * \retval ta_c_rc_invalid_argument \em value is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em value is not of type [string](\ref string.h).
 * \retval ta_c_rc_invalid_argument \em loyalty_info_type is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em loyalty_info_type is not of type [string](\ref string.h).
 * \retval ta_c_rc_out_of_memory Failed allocating memory.
 */
extern ta_e_result_code_t ta_loyalty_information_create(
	ta_object_t *loyalty_information,
	ta_object_t value,
	ta_object_t loyalty_info_type );


/**
 * \brief Information value.
 * 
 * \param[in] loyalty_information Object instance of type [loyalty_information](\ref loyalty_information.h).
 * \param[out] value Pointer to variable to write object instance to. Object
 *                   instance is of type [string](\ref string.h) and is not retained.
 * 
 * \retval ta_c_rc_ok Object instance written to \em value.
 * \retval ta_c_rc_invalid_argument \em loyalty_information is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em loyalty_information is not of type [loyalty_information](\ref loyalty_information.h).
 * \retval ta_c_rc_invalid_argument \em value is \em null-pointer.
 */
extern ta_e_result_code_t ta_loyalty_information_get_value(
	ta_object_t loyalty_information,
	ta_object_t* value );

/**
 * \brief Specifies type of loyalty information.
 * 
 * \param[in] loyalty_information Object instance of type [loyalty_information](\ref loyalty_information.h).
 * \param[out] loyalty_info_type Pointer to variable to write object instance to. Object
 *                               instance is of type [string](\ref string.h) and is not retained.
 * 
 * \retval ta_c_rc_ok Object instance written to \em value.
 * \retval ta_c_rc_invalid_argument \em loyalty_information is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em loyalty_information is not of type [loyalty_information](\ref loyalty_information.h).
 * \retval ta_c_rc_invalid_argument \em loyalty_info_type is \em null-pointer.
 */
extern ta_e_result_code_t ta_loyalty_information_get_loyalty_info_type(
	ta_object_t loyalty_information,
	ta_object_t* loyalty_info_type );

/**
 * \brief Defines what kind of loyalty mode will be used.
 * 
 * \param[in] loyalty_information Object instance of type [loyalty_information](\ref loyalty_information.h).
 * \param[out] loyalty_function_type Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Object instance written to \em value.
 * \retval ta_c_rc_invalid_argument \em loyalty_information is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em loyalty_information is not of type [loyalty_information](\ref loyalty_information.h).
 * \retval ta_c_rc_invalid_argument \em loyalty_function_type is \em null-pointer.
 */
extern ta_e_result_code_t ta_loyalty_information_get_loyalty_function_type(
	ta_object_t loyalty_information,
	ta_e_loyalty_function_type_t* loyalty_function_type );

/**
 * \brief Coupon ID.
 * 
 * \param[in] loyalty_information Object instance of type [loyalty_information](\ref loyalty_information.h).
 * \param[out] loyalty_number Pointer to variable to write object instance to. Object
 *                            instance is of type [string](\ref string.h) and is not retained.
 * 
 * \retval ta_c_rc_ok Object instance written to \em id.
 * \retval ta_c_rc_invalid_argument \em loyalty_information is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em loyalty_information is not of type [loyalty_information](\ref loyalty_information.h).
 * \retval ta_c_rc_invalid_argument \em loyalty_number is \em null-pointer.
 */
extern ta_e_result_code_t ta_loyalty_information_get_loyalty_number(
	ta_object_t loyalty_information,
	ta_object_t *loyalty_number );


#ifdef __cplusplus
}
#endif

#endif
