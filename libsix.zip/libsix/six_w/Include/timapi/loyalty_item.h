/**
 * \file
 * \brief Loyalty item.
 * \details Object type \em loyalty_item.
 */

#ifndef TA_LOYALTY_ITEM_H
#define TA_LOYALTY_ITEM_H

#include "common/object.h"
#include "common/boolean.h"


#ifdef __cplusplus
extern "C" {
#endif


/**
 * \brief Create object of type [loyalty_item](\ref loyalty_item.h).
 * 
 * \param[out] item Pointer to variable to write created object instance to.
 *                  Created object instance is retained.
 * 
 * \retval ta_c_rc_ok Object instance has been created and written to \em item.
 * \retval ta_c_rc_invalid_argument \em item is \em null-pointer.
 * \retval ta_c_rc_out_of_memory Failed allocating memory.
 */
extern ta_e_result_code_t ta_loyalty_item_create(
	ta_object_t *item );

/**
 * \brief Create deep copy of object instance of type [loyalty_item](\ref loyalty_item.h).
 * 
 * \param[out] item Pointer to variable to write created object instance to.
 *                  Created object instance is retained.
 * \param[in] source_item Object of type [loyalty_item](\ref loyalty_item.h) to create copy of.
 * 
 * \retval ta_c_rc_ok Object instance has been created and written to \em item.
 * \retval ta_c_rc_invalid_argument \em item is \em null-pointer.
 * \retval ta_c_rc_invalid_argument \em source_item is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em source_item is not of type [loyalty_item](\ref loyalty_item.h).
 * \retval ta_c_rc_out_of_memory Failed allocating memory.
 */
extern ta_e_result_code_t ta_loyalty_item_copy(
	ta_object_t* item,
	const ta_object_t* source_item );



/**
 * \brief Identifies the item.
 * 
 * \param[in] item Object instance of type [loyalty_item](\ref loyalty_item.h).
 * \param[out] item_id Pointer to variable to write object instance to. Object instance is of type
 *                     [string](\ref string.h) and is not retained. Object instance is
 *                     \em ta_object_invalid if value is not set in \em loyalty_item.
 * 
 * \retval ta_c_rc_ok Object instance written to \em auth_result.
 * \retval ta_c_rc_invalid_argument \em item is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em item is not of type [loyalty_item](\ref loyalty_item.h).
 * \retval ta_c_rc_invalid_argument \em item_id is not \em null-pointer.
 */
extern ta_e_result_code_t ta_loyalty_item_get_item_id(
	ta_object_t item,
	ta_object_t *item_id );

/**
 * \brief Set identifies the item.
 * 
 * \param[in] item Object instance of type [loyalty_item](\ref loyalty_item.h).
 * \param[in] item_id Object instance to set. Object instance can be \em ta_object_invalid
 *                    to clear the value in \em item. If object instance is not
 *                    ta_object_invalid is has to be of type [string](\ref string.h).
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em item.
 * \retval ta_c_rc_invalid_argument \em item is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em item is not of type [loyalty_item](\ref loyalty_item.h).
 * \retval ta_c_rc_invalid_argument \em item_id is not \em ta_object_invalid and
 *                                  is not of type [string](\ref string.h).
 */
extern ta_e_result_code_t ta_loyalty_item_set_item_id(
	ta_object_t item,
	ta_object_t item_id );



/**
 * \brief Product description.
 * 
 * \param[in] item Object instance of type [loyalty_item](\ref loyalty_item.h).
 * \param[out] prod_description Pointer to variable to write object instance to. Object instance is
 *                              of type [string](\ref string.h) and is not retained. Object instance
 *                              is \em ta_object_invalid if value is not set in \em loyalty_item.
 * 
 * \retval ta_c_rc_ok Object instance written to \em auth_result.
 * \retval ta_c_rc_invalid_argument \em item is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em item is not of type [loyalty_item](\ref loyalty_item.h).
 * \retval ta_c_rc_invalid_argument \em prod_description is not \em null-pointer.
 */
extern ta_e_result_code_t ta_loyalty_item_get_prod_description(
	ta_object_t item,
	ta_object_t *prod_description );

/**
 * \brief Set product description.
 * 
 * \param[in] item Object instance of type [loyalty_item](\ref loyalty_item.h).
 * \param[in] prod_description Object instance to set. Object instance can be \em ta_object_invalid
 *                             to clear the value in \em item. If object instance is not
 *                             ta_object_invalid is has to be of type [string](\ref string.h).
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em item.
 * \retval ta_c_rc_invalid_argument \em item is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em item is not of type [loyalty_item](\ref loyalty_item.h).
 * \retval ta_c_rc_invalid_argument \em prod_description is not \em ta_object_invalid and
 *                                  is not of type [string](\ref string.h).
 */
extern ta_e_result_code_t ta_loyalty_item_set_prod_description(
	ta_object_t item,
	ta_object_t prod_description );



/**
 * \brief Amount.
 * 
 * \param[in] item Object instance of type [loyalty_item](\ref loyalty_item.h).
 * \param[out] amount Pointer to variable to write object instance to. Object instance is of type
 *                    [amount](\ref amount.h) and is not retained. Object instance is
 *                    \em ta_object_invalid if value is not set in \em loyalty_item.
 * 
 * \retval ta_c_rc_ok Object instance written to \em auth_result.
 * \retval ta_c_rc_invalid_argument \em item is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em item is not of type [loyalty_item](\ref loyalty_item.h).
 * \retval ta_c_rc_invalid_argument \em amount is not \em null-pointer.
 */
extern ta_e_result_code_t ta_loyalty_item_get_amount(
	ta_object_t item,
	ta_object_t *amount );

/**
 * \brief Set amount.
 * 
 * \param[in] item Object instance of type [loyalty_item](\ref loyalty_item.h).
 * \param[in] amount Object instance to set. Object instance can be \em ta_object_invalid
 *                   to clear the value in \em item. If object instance is not
 *                   ta_object_invalid is has to be of type [amount](\ref amount.h).
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em item.
 * \retval ta_c_rc_invalid_argument \em item is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em item is not of type [loyalty_item](\ref loyalty_item.h).
 * \retval ta_c_rc_invalid_argument \em amount is not \em ta_object_invalid and
 *                                  is not of type [amount](\ref amount.h).
 */
extern ta_e_result_code_t ta_loyalty_item_set_amount(
	ta_object_t item,
	ta_object_t amount );



/**
 * \brief Quantity of the product.
 * 
 * \param[in] item Object instance of type [loyalty_item](\ref loyalty_item.h).
 * \param[out] item_quantity Pointer to variable to write object instance to. Object instance is
 *                           of type [item_quantity](\ref item_quantity.h) and is not retained.
 *                           Object instance is \em ta_object_invalid if value is not set in
 *                           \em loyalty_item.
 * 
 * \retval ta_c_rc_ok Object instance written to \em auth_result.
 * \retval ta_c_rc_invalid_argument \em item is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em item is not of type [loyalty_item](\ref loyalty_item.h).
 * \retval ta_c_rc_invalid_argument \em item_quantity is not \em null-pointer.
 */
extern ta_e_result_code_t ta_loyalty_item_get_item_quantity(
	ta_object_t item,
	ta_object_t *item_quantity );

/**
 * \brief Set quantity of the product.
 * 
 * \param[in] item Object instance of type [loyalty_item](\ref loyalty_item.h).
 * \param[in] item_quantity Object instance to set. Object instance can be \em ta_object_invalid
 *                          to clear the value in \em item. If object instance is not
 *                          ta_object_invalid is has to be of type [item_quantity](\ref item_quantity.h).
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em item.
 * \retval ta_c_rc_invalid_argument \em item is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em item is not of type [loyalty_item](\ref loyalty_item.h).
 * \retval ta_c_rc_invalid_argument \em item_quantity is not \em ta_object_invalid and
 *                                  is not of type [item_quantity](\ref item_quantity.h).
 */
extern ta_e_result_code_t ta_loyalty_item_set_item_quantity(
	ta_object_t item,
	ta_object_t item_quantity );



/**
 * \brief Total amount.
 * 
 * \param[in] item Object instance of type [loyalty_item](\ref loyalty_item.h).
 * \param[out] amount_total Pointer to variable to write object instance to. Object instance is of type
 *                          [amount](\ref amount.h) and is not retained. Object instance is
 *                          \em ta_object_invalid if value is not set in \em loyalty_item.
 * 
 * \retval ta_c_rc_ok Object instance written to \em auth_result.
 * \retval ta_c_rc_invalid_argument \em item is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em item is not of type [loyalty_item](\ref loyalty_item.h).
 * \retval ta_c_rc_invalid_argument \em amount_total is not \em null-pointer.
 */
extern ta_e_result_code_t ta_loyalty_item_get_amount_total(
	ta_object_t item,
	ta_object_t *amount_total );

/**
 * \brief Set total amount.
 * 
 * \param[in] item Object instance of type [loyalty_item](\ref loyalty_item.h).
 * \param[in] amount_total Object instance to set. Object instance can be \em ta_object_invalid
 *                         to clear the value in \em item. If object instance is not
 *                         ta_object_invalid is has to be of type [amount](\ref amount.h).
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em item.
 * \retval ta_c_rc_invalid_argument \em item is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em item is not of type [loyalty_item](\ref loyalty_item.h).
 * \retval ta_c_rc_invalid_argument \em amount_total is not \em ta_object_invalid and
 *                                  is not of type [amount](\ref amount.h).
 */
extern ta_e_result_code_t ta_loyalty_item_set_amount_total(
	ta_object_t item,
	ta_object_t amount_total );



/**
 * \brief List of loyalty discounts.
 * 
 * \param[in] item Object instance of type [loyalty_discount](\ref loyalty_discount.h).
 * \param[out] loyalty_discounts Pointer to variable to write object instance to. Object instance
 *                               is of type [list](\ref list.h) and is not retained. Elements are
 *                               of type [loyalty_discount](\ref loyalty_discount.h). List object instance
 *                               is \em ta_object_invalid if value is not set in \em loyalty_discount.
 * 
 * \retval ta_c_rc_ok Object instance written to \em auth_result.
 * \retval ta_c_rc_invalid_argument \em item is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em item is not of type [loyalty_discount](\ref loyalty_discount.h).
 * \retval ta_c_rc_invalid_argument \em loyalty_discounts is not \em null-pointer.
 */
extern ta_e_result_code_t ta_loyalty_discount_get_loyalty_discounts(
	ta_object_t item,
	ta_object_t *loyalty_discounts );



/**
 * \brief List of loyalty coupons.
 * 
 * \param[in] item Object instance of type [loyalty_item](\ref loyalty_item.h).
 * \param[out] loyalty_coupons Pointer to variable to write object instance to. Object instance
 *                               is of type [list](\ref list.h) and is not retained. Elements are
 *                               of type [loyalty_coupon](\ref loyalty_coupon.h). List object instance
 *                               is \em ta_object_invalid if value is not set in \em loyalty_coupon.
 * 
 * \retval ta_c_rc_ok Object instance written to \em auth_result.
 * \retval ta_c_rc_invalid_argument \em item is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em item is not of type [loyalty_item](\ref loyalty_item.h).
 * \retval ta_c_rc_invalid_argument \em loyalty_coupons is not \em null-pointer.
 */
extern ta_e_result_code_t ta_loyalty_coupon_get_loyalty_coupons(
	ta_object_t item,
	ta_object_t *loyalty_coupons );



/**
 * \brief Display product info.
 * 
 * \param[in] item Object instance of type [loyalty_item](\ref loyalty_item.h).
 * \param[out] info Pointer to variable to write object instance to. Object instance is
 *                  of type [display_product_info](\ref display_product_info.h) and is not retained.
 *                  Object instance is \em ta_object_invalid if value is not set in
 *                  \em loyalty_item.
 * 
 * \retval ta_c_rc_ok Object instance written to \em auth_result.
 * \retval ta_c_rc_invalid_argument \em item is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em item is not of type [loyalty_item](\ref loyalty_item.h).
 * \retval ta_c_rc_invalid_argument \em info is not \em null-pointer.
 */
extern ta_e_result_code_t ta_loyalty_item_get_display_product_info(
	ta_object_t item,
	ta_object_t *info );

/**
 * \brief Set display product info.
 * 
 * \param[in] item Object instance of type [loyalty_item](\ref loyalty_item.h).
 * \param[in] info Object instance to set. Object instance can be \em ta_object_invalid
 *                 to clear the value in \em item. If object instance is not
 *                 ta_object_invalid is has to be of type [display_product_info](\ref display_product_info.h).
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em item.
 * \retval ta_c_rc_invalid_argument \em item is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em item is not of type [loyalty_item](\ref loyalty_item.h).
 * \retval ta_c_rc_invalid_argument \em info is not \em ta_object_invalid and
 *                                  is not of type [display_product_info](\ref display_product_info.h).
 */
extern ta_e_result_code_t ta_loyalty_item_set_display_product_info(
	ta_object_t item,
	ta_object_t info );



#ifdef __cplusplus
}
#endif

#endif
