/**
 * \file
 * \brief Mobile topup issuer information result.
 * \details Object type \em mobile_topup_data.
 */

#ifndef TA_MOBILE_TOPUP_DATA_H
#define TA_MOBILE_TOPUP_DATA_H

#include "common/object.h"
#include "common/boolean.h"


#ifdef __cplusplus
extern "C" {
#endif


/**
 * \brief Create object of type [mobile_topup_data](\ref mobile_topup_data.h).
 * 
 * \param[out] data Pointer to variable to write created object instance to.
 *                  Created object instance is retained.
 * 
 * \retval ta_c_rc_ok Object instance has been created and written to \em value.
 * \retval ta_c_rc_invalid_argument \em value is \em null-pointer.
 * \retval ta_c_rc_out_of_memory Failed allocating memory.
 */
extern ta_e_result_code_t ta_mobile_topup_data_create(
	ta_object_t* data );



/**
 * \brief Contains the brand name of a card. The brand name information is retrieved from the card.
 * 
 * \param[in] data Object instance of type [mobile_topup_data](\ref mobile_topup_data.h).
 * \param[out] brand_name Pointer to variable to write object instance to. Object instance is
 *                        of type [string](\ref string.h) and is not retained. Object instance is
 *                        \em ta_object_invalid if value is not set in \em mobile_topup_data.
 * 
 * \retval ta_c_rc_ok Object instance written to \em brand_name.
 * \retval ta_c_rc_invalid_argument \em value is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em value is not of type [mobile_topup_data](\ref mobile_topup_data.h).
 * \retval ta_c_rc_invalid_argument \em brand_name is not \em null-pointer.
 */
extern ta_e_result_code_t ta_mobile_topup_data_get_brand_name(
	ta_object_t data,
	ta_object_t *brand_name );

/**
 * \brief Contains the serial number of a (mobile topup) voucher.
 * 
 * \param[in] data Object instance of type [mobile_topup_data](\ref mobile_topup_data.h).
 * \param[out] mobile_topup_serial_number Pointer to variable to write object instance to. Object instance is
 *                                        of type [string](\ref string.h) and is not retained. Object instance is
 *                                        \em ta_object_invalid if value is not set in \em mobile_topup_data.
 * 
 * \retval ta_c_rc_ok Object instance written to \em mobile_topup_serial_number.
 * \retval ta_c_rc_invalid_argument \em value is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em value is not of type [mobile_topup_data](\ref mobile_topup_data.h).
 * \retval ta_c_rc_invalid_argument \em mobile_topup_serial_number is not \em null-pointer.
 */
extern ta_e_result_code_t ta_mobile_topup_data_get_mobile_topup_serial_number(
	ta_object_t data,
	ta_object_t *mobile_topup_serial_number );

/**
 * \brief Contains the refill code of a (mobile topup) voucher.
 * 
 * \param[in] data Object instance of type [mobile_topup_data](\ref mobile_topup_data.h).
 * \param[out] mobile_topup_refill_code Pointer to variable to write object instance to. Object instance is
 *                                      of type [string](\ref string.h) and is not retained. Object instance is
 *                                      \em ta_object_invalid if value is not set in \em mobile_topup_data.
 * 
 * \retval ta_c_rc_ok Object instance written to \em mobile_topup_refill_code.
 * \retval ta_c_rc_invalid_argument \em value is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em value is not of type [mobile_topup_data](\ref mobile_topup_data.h).
 * \retval ta_c_rc_invalid_argument \em mobile_topup_refill_code is not \em null-pointer.
 */
extern ta_e_result_code_t ta_mobile_topup_data_get_mobile_topup_refill_code(
	ta_object_t data,
	ta_object_t *mobile_topup_refill_code );

/**
 * \brief Card expiration date. This information is retrieved from the card
 * 
 * \param[in] data Object instance of type [mobile_topup_data](\ref mobile_topup_data.h).
 * \param[out] card_expiry_date Pointer to variable to write object instance to. Object instance is
 *                              of type [timedate](\ref timedate.h) and is not retained. Object instance is
 *                              \em ta_object_invalid if value is not set in \em value.
 * 
 * \retval ta_c_rc_ok Object instance written to \em card_expiry_date.
 * \retval ta_c_rc_invalid_argument \em value is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em value is not of type [mobile_topup_data](\ref mobile_topup_data.h).
 * \retval ta_c_rc_invalid_argument \em card_expiry_date is not \em null-pointer.
 */
extern ta_e_result_code_t ta_mobile_topup_data_get_card_expiry_date(
	ta_object_t data,
	ta_object_t *card_expiry_date );

/**
 * \brief Print data if present.
 * 
 * \param[in] data Object instance of type [mobile_topup_data](\ref mobile_topup_data.h).
 * \param[out] print_data Pointer to variable to write object instance to. Object instance is
 *                        of type [list](\ref list.h) with entries of type [print_data](\ref print_data.h)
 *                        and is not retained. Object instance is \em ta_object_invalid if value
 *                        is not set in \em value.
 * 
 * \retval ta_c_rc_ok Object instance written to \em print_data.
 * \retval ta_c_rc_invalid_argument \em value is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em value is not of type [mobile_topup_data](\ref mobile_topup_data.h).
 * \retval ta_c_rc_invalid_argument \em print_data is not \em null-pointer.
 */
extern ta_e_result_code_t ta_mobile_topup_data_get_print_data(
	ta_object_t data,
	ta_object_t *print_data );

#ifdef __cplusplus
}
#endif

#endif
