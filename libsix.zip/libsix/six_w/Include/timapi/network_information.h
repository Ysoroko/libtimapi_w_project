/**
 * \file
 * \brief Contains network information of the terminal.
 * 
 * Object type \em network_information.
 * 
 * Result of calling ta_terminal_system_information() or ta_terminal_system_information_async().
 */

#ifndef TA_NETWORK_INFORMATION_H
#define TA_NETWORK_INFORMATION_H

#include "common/object.h"


#ifdef __cplusplus
extern "C" {
#endif


/**
 * \brief Terminal IP.
 * 
 * \param[in] network_info Object instance of type [network_information](\ref network_information.h).
 * \param[out] terminal_ip Pointer to variable to write object instance to. Object
 *                                 instance is of type [string](\ref string.h) and is not retained.
 * 
 * \retval ta_c_rc_ok Object instance written to \em terminal_ip.
 * \retval ta_c_rc_invalid_argument \em network_info is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em network_info is not of type [network_information](\ref network_information.h).
 * \retval ta_c_rc_invalid_argument \em terminal_ip is \em null-pointer.
 */
extern ta_e_result_code_t ta_network_information_get_terminal_ip(
	ta_object_t network_info,
	ta_object_t *terminal_ip );

/**
 * \brief Terminal IP network mask.
 * 
 * \param[in] network_info Object instance of type [network_information](\ref network_information.h).
 * \param[out] terminal_ip_mask Pointer to variable to write object instance to. Object
 *                              instance is of type [string](\ref string.h) and is not retained.
 * 
 * \retval ta_c_rc_ok Object instance written to \em terminal_ip_mask.
 * \retval ta_c_rc_invalid_argument \em network_info is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em network_info is not of type [network_information](\ref network_information.h).
 * \retval ta_c_rc_invalid_argument \em terminal_ip_mask is \em null-pointer.
 */
extern ta_e_result_code_t ta_network_information_get_terminal_ip_mask(
	ta_object_t network_info,
	ta_object_t *terminal_ip_mask );

/**
 * \brief Terminal IP gateway.
 * 
 * \param[in] network_info Object instance of type [network_information](\ref network_information.h).
 * \param[out] terminal_ip_gw Pointer to variable to write object instance to. Object
 *                            instance is of type [string](\ref string.h) and is not retained.
 * 
 * \retval ta_c_rc_ok Object instance written to \em terminal_ip_gw.
 * \retval ta_c_rc_invalid_argument \em network_info is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em network_info is not of type [network_information](\ref network_information.h).
 * \retval ta_c_rc_invalid_argument \em terminal_ip_gw is \em null-pointer.
 */
extern ta_e_result_code_t ta_network_information_get_terminal_ip_gw(
	ta_object_t network_info,
	ta_object_t *terminal_ip_gw );

/**
 * \brief Terminal IP dns host name.
 * 
 * \param[in] network_info Object instance of type [network_information](\ref network_information.h).
 * \param[out] terminal_ip_dns Pointer to variable to write object instance to. Object
 *                             instance is of type [string](\ref string.h) and is not retained.
 * 
 * \retval ta_c_rc_ok Object instance written to \em terminal_ip_dns.
 * \retval ta_c_rc_invalid_argument \em network_info is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em network_info is not of type [network_information](\ref network_information.h).
 * \retval ta_c_rc_invalid_argument \em terminal_ip_dns is \em null-pointer.
 */
extern ta_e_result_code_t ta_network_information_get_terminal_ip_dns(
	ta_object_t network_info,
	ta_object_t *terminal_ip_dns );


#ifdef __cplusplus
}
#endif

#endif
