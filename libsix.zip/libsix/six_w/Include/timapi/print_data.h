/**
 * \file
 * \brief Print data.
 * \details Object type \em print_data.
 */

#ifndef TA_PRINT_DATA_H
#define TA_PRINT_DATA_H

#include "common/object.h"


#ifdef __cplusplus
extern "C" {
#endif


/**
 * \brief Receipts to print by the ECR.
 * 
 * Present if print type is Normal.
 * 
 * \param[in] print_data Object instance of type [print_data](\ref print_data.h).
 * \param[out] receipts Pointer to variable to write object instance to. Object instance
 *                      is of type [list](\ref list.h) and is not retained. The list contains elements
 *                      of type [receipt](\ref receipt.h).
 * 
 * \retval ta_c_rc_ok Object instance written to \em receipts.
 * \retval ta_c_rc_invalid_argument \em print_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em print_data is not of type [print_data](\ref print_data.h).
 * \retval ta_c_rc_invalid_argument \em receipts is \em null-pointer.
 */
extern ta_e_result_code_t ta_print_data_get_receipts(
	ta_object_t print_data,
	ta_object_t *receipts );

/**
 * \brief Receipt items for the ECR to create receipts for printing.
 * 
 * Present if print type is FieldsOnly.
 * 
 * \param[in] print_data Object instance of type [print_data](\ref print_data.h).
 * \param[out] items Pointer to variable to write object instance to. Object instance
 *                   is of type [list](\ref list.h) and is not retained. The list contains elements
 *                   of type [receipt_items](\ref receipt_items.h).
 * 
 * \retval ta_c_rc_ok Object instance written to \em items.
 * \retval ta_c_rc_invalid_argument \em print_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em print_data is not of type [print_data](\ref print_data.h).
 * \retval ta_c_rc_invalid_argument \em items is \em null-pointer.
 */
extern ta_e_result_code_t ta_print_data_get_receipt_items(
	ta_object_t print_data,
	ta_object_t *items );


#ifdef __cplusplus
}
#endif

#endif
