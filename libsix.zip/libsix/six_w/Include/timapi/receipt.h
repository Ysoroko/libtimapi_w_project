/**
 * \file
 * \brief Receipt.
 * \details Object type \em receipt.
 */

#ifndef TA_RECEIPT_H
#define TA_RECEIPT_H

#include "common/object.h"
#include "constants/recipient.h"


#ifdef __cplusplus
extern "C" {
#endif


/**
 * \brief Create receipt.
 * 
 * \param[out] receipt Pointer to variable to write created object instance to.
 *                     Created object instance is retained.
 * \param[in] recipient Recipient.
 * \param[in] value Receipt text. Object instance has to be of type [string](\ref string.h).
 * 
 * \retval ta_c_rc_ok Object instance has been created and written to \em receipt.
 * \retval ta_c_rc_invalid_argument \em receipt is \em null-pointer.
 * \retval ta_c_rc_invalid_argument \em recipient is invalid value.
 * \retval ta_c_rc_invalid_argument \em value is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em value is not of type [string](\ref string.h).
 * \retval ta_c_rc_out_of_memory Failed allocating memory.
 */
extern ta_e_result_code_t ta_receipt_create(
	ta_object_t *receipt,
	ta_e_recipient_t recipient,
	ta_object_t value );


/**
 * \brief Recipient of the receipt.
 * 
 * \param[in] receipt Object instance of type [receipt](\ref receipt.h).
 * \param[out] recipient Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Value written to \em recipient.
 * \retval ta_c_rc_invalid_argument \em receipt is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em receipt is not of type [receipt](\ref receipt.h).
 * \retval ta_c_rc_invalid_argument \em recipient is \em null-pointer.
 */
extern ta_e_result_code_t ta_receipt_get_recipient(
	ta_object_t receipt,
	ta_e_recipient_t *recipient );

/**
 * \brief Receipt to print.
 * 
 * \param[in] receipt Object instance of type [receipt](\ref receipt.h).
 * \param[out] value Pointer to variable to write object instance to. Object instance is of
 *                   type \em string and is not retained.
 * 
 * \retval ta_c_rc_ok Object instance written to \em value.
 * \retval ta_c_rc_invalid_argument \em receipt is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em receipt is not of type [receipt](\ref receipt.h).
 * \retval ta_c_rc_invalid_argument \em value is \em null-pointer.
 */
extern ta_e_result_code_t ta_receipt_get_value(
	ta_object_t receipt,
	ta_object_t *value );


#ifdef __cplusplus
}
#endif

#endif
