/**
 * \file
 * \brief Receipt formatter.
 * \details Object type \em receipt_formatter.
 */

#ifndef TA_RECEIPT_FORMATTER_H
#define TA_RECEIPT_FORMATTER_H

#include "common/object.h"
#include "constants/result_code.h"


#ifdef __cplusplus
extern "C" {
#endif



/**
 * \brief Format receipt using the provided fields.
 * 
 * Result is a list of [receipt](\ref receipt.h) using "\n" as line breaks.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h) with terminal to
 *                     retrieve certain field values from. Object instance is not retained.
 * \param[in] receipt_items Object instance of type [receipt_items](\ref receipt_items.h)
 *                          containing items used to create receipt. Object instance
 *                          is not retained.
 * \param[out] receipts Object instance of type [list](\ref list.h) to fill with created
 *                      receipts. Receipts have to be object instances of type
 *                      [receipt](\ref receipt.h).
 * \param[in] user_pointer User pointer value used while creating the formatter.
 * \returns Result code from ta_e_result_code_t.
 */
typedef ta_e_result_code_t ( *ta_cb_receipt_formatter_format_receipt )(
	ta_object_t terminal,
	ta_object_t receipt_items,
	ta_object_t receipts,
	void* user_pointer );



/**
 * \brief Struct knowing how to format transaction receipts using receipt item fields.
 * 
 * Use memset to clear struct to 0 then set the callback and user pointer. This struct is
 * only used to initialize the formatter during a call to ta_receipt_formatter_create.
 * Afterwards the callbacks can not be changed anymore as long as the formatter is alive.
 */
typedef struct ta_s_receipt_formatter{
	/** \brief Format receipt. */
	ta_cb_receipt_formatter_format_receipt format_receipt;
	
	/** \brief User pointer. */
	void* user_pointer;
} ta_s_receipt_formatter_t;



/**
 * \brief Create receipt formatter.
 * 
 * Caller retains a reference to the created instance. While assigning to a terminal
 * instance the terminal instance retains the reference. The user can release the
 * reference directly afterwards. In this case the formatter is destroyed once no
 * terminal instance requires the formatter anymore.
 * 
 * \param[out] formatter Pointer to variable to write created object instance to.
 *                       Created object instance is retained.
 * \param[in] configuration Pointer to struct containinig formatter configuration.
 * 
 * \retval ta_c_rc_ok Object instance has been created and written to \em formatter.
 * \retval ta_c_rc_invalid_argument \em formatter is \em null-pointer.
 * \retval ta_c_rc_invalid_argument \em configuration is \em null-pointer.
 * \retval ta_c_rc_out_of_memory Failed allocating memory.
 */
extern ta_e_result_code_t ta_receipt_formatter_create(
	ta_object_t* formatter,
	const ta_s_receipt_formatter_t* configuration );


#ifdef __cplusplus
}
#endif

#endif
