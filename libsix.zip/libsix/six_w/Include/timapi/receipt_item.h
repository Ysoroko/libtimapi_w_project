/**
 * \file
 * \brief Receipt item.
 * \details Object type \em receipt_item.
 */

#ifndef TA_RECEIPT_ITEM_H
#define TA_RECEIPT_ITEM_H

#include "common/object.h"
#include "constants/receipt_item_type.h"
#include "constants/recipient.h"


#ifdef __cplusplus
extern "C" {
#endif


/**
 * \brief Type of receipt item.
 * 
 * \param[in] receipt_item Object instance of type [receipt_item](\ref receipt_item.h).
 * \param[out] receipt_item_type Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Object instance written to \em receipt_item_type.
 * \retval ta_c_rc_invalid_argument \em receipt_item is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em receipt_item is not of type [receipt_item](\ref receipt_item.h).
 * \retval ta_c_rc_invalid_argument \em receipt_item_type is \em null-pointer.
 */
extern ta_e_result_code_t ta_receipt_item_get_receipt_item_type(
	ta_object_t receipt_item,
	ta_e_receipt_item_type_t* receipt_item_type );

/**
 * \brief Recipient.
 * 
 * \param[in] receipt_item Object instance of type [receipt_item](\ref receipt_item.h).
 * \param[out] recipient Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Object instance written to \em recipient.
 * \retval ta_c_rc_invalid_argument \em receipt_item is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em receipt_item is not of type [receipt_item](\ref receipt_item.h).
 * \retval ta_c_rc_invalid_argument \em recipient is \em null-pointer.
 */
extern ta_e_result_code_t ta_receipt_item_get_recipient(
	ta_object_t receipt_item,
	ta_e_recipient_t* recipient );

/**
 * \brief Value of the receipt item.
 * 
 * \param[in] receipt_item Object instance of type [receipt_item](\ref receipt_item.h).
 * \param[out] value Pointer to variable to write object instance to. Object instance is of
 *                   type \em string and is not retained.
 * 
 * \retval ta_c_rc_ok Object instance written to \em value.
 * \retval ta_c_rc_invalid_argument \em receipt_item is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em receipt_item is not of type [receipt_item](\ref receipt_item.h).
 * \retval ta_c_rc_invalid_argument \em value is \em null-pointer.
 */
extern ta_e_result_code_t ta_receipt_item_get_value(
	ta_object_t receipt_item,
	ta_object_t* value );


#ifdef __cplusplus
}
#endif

#endif
