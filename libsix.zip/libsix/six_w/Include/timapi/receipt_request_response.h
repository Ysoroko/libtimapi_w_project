/**
 * \file
 * \brief Receipt request Response.
 * \details Object type \em receipt_request_response.
 */

#ifndef TA_RECEIPT_REQUEST_RESPONSE_H
#define TA_RECEIPT_REQUEST_RESPONSE_H

#include "common/object.h"
#include "common/boolean.h"


#ifdef __cplusplus
extern "C" {
#endif


/**
 * \brief Print information for receipts to print by the ECR.
 * 
 * \param[in] response Object instance of type [receipt_request_response](\ref receipt_request_response.h).
 * \param[out] print_data Pointer to variable to write object instance to. Object instance is
 *                        of type [print_data](\ref print_data.h) and is not retained. Object instance is
 *                        \em ta_object_invalid if value is not set in \em response.
 * 
 * \retval ta_c_rc_ok Object instance written to \em print_data.
 * \retval ta_c_rc_invalid_argument \em response is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em response is not of type [receipt_request_response](\ref receipt_request_response.h).
 * \retval ta_c_rc_invalid_argument \em print_data is \em null-pointer.
 */
extern ta_e_result_code_t ta_receipt_request_response_get_print_data(
	ta_object_t response,
	ta_object_t* print_data );

/**
 * \brief More receipts can be requested (maximum transmit receipts limit).
 * 
 * \param[in] response Object instance of type [receipt_request_response](\ref receipt_request_response.h).
 * \param[out] has_more_receipts Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Object instance written to \em has_more_receipts.
 * \retval ta_c_rc_invalid_argument \em response is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em response is not of type [receipt_request_response](\ref receipt_request_response.h).
 * \retval ta_c_rc_invalid_argument \em has_more_receipts is \em null-pointer.
 */
extern ta_e_result_code_t ta_receipt_request_response_get_has_more_receipts(
	ta_object_t response,
	ta_e_boolean_t* has_more_receipts );


#ifdef __cplusplus
}
#endif

#endif
