/**
 * \file
 * \brief Screenshot information.
 * \details Object type \em screenshot_information.
 */

#ifndef TA_SCREENSHOT_INFORMATION_H
#define TA_SCREENSHOT_INFORMATION_H

#include "color.h"
#include "common/object.h"
#include "common/boolean.h"
#include "constants/image_file_format.h"


#ifdef __cplusplus
extern "C" {
#endif


/**
 * \brief File format of image data.
 * 
 * \param[in] info Object instance of type [screenshot_information](\ref screenshot_information.h).
 * \param[out] image_file_format Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Object instance written to \em image_file_format.
 * \retval ta_c_rc_invalid_argument \em info is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em info is not of type [screenshot_information](\ref screenshot_information.h).
 * \retval ta_c_rc_invalid_argument \em image_file_format is \em null-pointer.
 */
extern ta_e_result_code_t ta_screenshot_information_get_image_file_format(
	ta_object_t info,
	ta_e_image_file_format_t* image_file_format );

/**
 * \brief Image width in pixels.
 * 
 * \param[in] info Object instance of type [screenshot_information](\ref screenshot_information.h).
 * \param[out] image_width Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Object instance written to \em image_width.
 * \retval ta_c_rc_invalid_argument \em info is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em info is not of type [screenshot_information](\ref screenshot_information.h).
 * \retval ta_c_rc_invalid_argument \em image_width is \em null-pointer.
 */
extern ta_e_result_code_t ta_screenshot_information_get_image_width(
	ta_object_t info,
	int* image_width );

/**
 * \brief Image height in pixels.
 * 
 * \param[in] info Object instance of type [screenshot_information](\ref screenshot_information.h).
 * \param[out] image_height Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Object instance written to \em image_height.
 * \retval ta_c_rc_invalid_argument \em info is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em info is not of type [screenshot_information](\ref screenshot_information.h).
 * \retval ta_c_rc_invalid_argument \em image_height is \em null-pointer.
 */
extern ta_e_result_code_t ta_screenshot_information_get_image_height(
	ta_object_t info,
	int* image_height );

/**
 * \brief Image data.
 * 
 * See ta_string_get_length for the size of the data and ta_string_get_pointer to get
 * access to the data. Data can contain 0-bytes so always use the string length.
 * 
 * \param[in] info Object instance of type [screenshot_information](\ref screenshot_information.h).
 * \param[out] image_data Pointer to variable to write object instance to. Object
 *                        instance is of type [string](\ref string.h) and is not retained.
 * 
 * \retval ta_c_rc_ok Object instance written to \em image_data.
 * \retval ta_c_rc_invalid_argument \em info is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em info is not of type [screenshot_information](\ref screenshot_information.h).
 * \retval ta_c_rc_invalid_argument \em image_data is \em null-pointer.
 */
extern ta_e_result_code_t ta_screenshot_information_get_image_data(
	ta_object_t info,
	ta_object_t* image_data );


#ifdef __cplusplus
}
#endif

#endif
