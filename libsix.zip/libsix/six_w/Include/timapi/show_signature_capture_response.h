/**
 * \file
 * \brief Show signature capture response.
 * \details Object type \em show_signature_capture_response.
 */

#ifndef TA_SHOW_SIGNATURE_CAPTURE_RESPONSE_H
#define TA_SHOW_SIGNATURE_CAPTURE_RESPONSE_H

#include "color.h"
#include "common/object.h"
#include "common/boolean.h"
#include "constants/reason.h"
#include "constants/image_file_format.h"


#ifdef __cplusplus
extern "C" {
#endif


/**
 * \brief Reason for closing dialog.
 * 
 * \param[in] response Object instance of type [show_signature_capture_response](\ref show_signature_capture_response.h).
 * \param[out] reason Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Object instance written to \em reason.
 * \retval ta_c_rc_invalid_argument \em response is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em response is not of type [show_signature_capture_response](\ref show_signature_capture_response.h).
 * \retval ta_c_rc_invalid_argument \em reason is \em null-pointer.
 */
extern ta_e_result_code_t ta_show_signature_capture_response_get_reason(
	ta_object_t response,
	ta_e_reason_t* reason );

/**
 * \brief File format of image data.
 * 
 * \param[in] response Object instance of type [show_signature_capture_response](\ref show_signature_capture_response.h).
 * \param[out] image_file_format Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Object instance written to \em image_file_format.
 * \retval ta_c_rc_invalid_argument \em response is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em response is not of type [show_signature_capture_response](\ref show_signature_capture_response.h).
 * \retval ta_c_rc_invalid_argument \em image_file_format is \em null-pointer.
 */
extern ta_e_result_code_t ta_show_signature_capture_response_get_image_file_format(
	ta_object_t response,
	ta_e_image_file_format_t* image_file_format );

/**
 * \brief Image width in pixels.
 * 
 * \param[in] response Object instance of type [show_signature_capture_response](\ref show_signature_capture_response.h).
 * \param[out] image_width Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Object instance written to \em image_width.
 * \retval ta_c_rc_invalid_argument \em response is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em response is not of type [show_signature_capture_response](\ref show_signature_capture_response.h).
 * \retval ta_c_rc_invalid_argument \em image_width is \em null-pointer.
 */
extern ta_e_result_code_t ta_show_signature_capture_response_get_image_width(
	ta_object_t response,
	int* image_width );

/**
 * \brief Image height in pixels.
 * 
 * \param[in] response Object instance of type [show_signature_capture_response](\ref show_signature_capture_response.h).
 * \param[out] image_height Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Object instance written to \em image_height.
 * \retval ta_c_rc_invalid_argument \em response is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em response is not of type [show_signature_capture_response](\ref show_signature_capture_response.h).
 * \retval ta_c_rc_invalid_argument \em image_height is \em null-pointer.
 */
extern ta_e_result_code_t ta_show_signature_capture_response_get_image_height(
	ta_object_t response,
	int* image_height );

/**
 * \brief Image data.
 * 
 * See ta_string_get_length for the size of the data and ta_string_get_pointer to get
 * access to the data. Data can contain 0-bytes so always use the string length.
 * 
 * \param[in] response Object instance of type [show_signature_capture_response](\ref show_signature_capture_response.h).
 * \param[out] image_data Pointer to variable to write object instance to. Object
 *                        instance is of type [string](\ref string.h) and is not retained.
 * 
 * \retval ta_c_rc_ok Object instance written to \em image_data.
 * \retval ta_c_rc_invalid_argument \em response is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em response is not of type [show_signature_capture_response](\ref show_signature_capture_response.h).
 * \retval ta_c_rc_invalid_argument \em image_data is \em null-pointer.
 */
extern ta_e_result_code_t ta_show_signature_capture_response_get_image_data(
	ta_object_t response,
	ta_object_t* image_data );


#ifdef __cplusplus
}
#endif

#endif
