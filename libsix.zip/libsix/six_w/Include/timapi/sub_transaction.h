/**
 * \file
 * \brief Sub transaction.
 * \details Object type \em sub_transaction.
 */

#ifndef TA_SUB_TRANSACTION_H
#define TA_SUB_TRANSACTION_H

#include "common/object.h"
#include "common/boolean.h"
#include "constants/transaction_type.h"


#ifdef __cplusplus
extern "C" {
#endif


/**
 * \brief Create sub transaction.
 * 
 * \param[out] sub_transaction Pointer to variable to write created object instance to.
 *                             Created object instance is retained.
 * 
 * \retval ta_c_rc_ok Object instance has been created and written to \em sub_transaction.
 * \retval ta_c_rc_invalid_argument \em sub_transaction is \em null-pointer.
 * \retval ta_c_rc_out_of_memory Failed allocating memory.
 */
extern ta_e_result_code_t ta_sub_transaction_create(
	ta_object_t *sub_transaction );

/**
 * \brief Create copy of sub transaction.
 * 
 * \param[out] sub_transaction Pointer to variable to write created object instance to.
 *                             Created object instance is retained.
 * \param[in] source_sub_transaction Object of type [sub_transaction](\ref sub_transaction.h) to create copy of.
 * 
 * \retval ta_c_rc_ok Object instance has been created and written to \em sub_transaction.
 * \retval ta_c_rc_invalid_argument \em sub_transaction is \em null-pointer.
 * \retval ta_c_rc_invalid_argument \em source_sub_transaction is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em source_sub_transaction is not of type [sub_transaction](\ref sub_transaction.h).
 * \retval ta_c_rc_out_of_memory Failed allocating memory.
 */
extern ta_e_result_code_t ta_sub_transaction_copy(
	ta_object_t *sub_transaction,
	const ta_object_t* source_sub_transaction );



/**
 * \brief Transaction function. Allowed are: purchase, giro, cash_advance.
 * 
 * Available if \em Banking guide is enabled.
 * 
 * \param[in] sub_transaction Object instance of type [sub_transaction](\ref sub_transaction.h).
 * \param[out] function Pointer to variable to write value to. Value is
 *                      \em ta_c_tt_undefined if value is not set in \em sub_transaction.
 * 
 * \retval ta_c_rc_ok Value written to \em function.
 * \retval ta_c_rc_invalid_argument \em sub_transaction is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em sub_transaction is not of type [sub_transaction](\ref sub_transaction.h).
 * \retval ta_c_rc_invalid_argument \em function is \em null-pointer.
 */
extern ta_e_result_code_t ta_sub_transaction_get_function(
	ta_object_t sub_transaction,
	ta_e_transaction_type_t* function );

/**
 * \brief Transaction function. Allowed are: purchase, giro, cash_advance.
 * 
 * Available if \em Banking guide is enabled.
 * 
 * \param[in] sub_transaction Object instance of type [sub_transaction](\ref sub_transaction.h).
 * \param[in] function Value to set. Value can be \em ta_c_tt_undefined to clear
 *                     the value in \em sub_transaction.
 * 
 * \retval ta_c_rc_ok Value assigned to \em sub_transaction.
 * \retval ta_c_rc_invalid_argument \em sub_transaction is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em sub_transaction is not of type [sub_transaction](\ref sub_transaction.h).
 * \retval ta_c_rc_invalid_argument \em function is \em null-pointer.
 * \retval ta_c_rc_invalid_argument \em function is not purchase, giro or cash_advance.
 */
extern ta_e_result_code_t ta_sub_transaction_set_function(
	ta_object_t sub_transaction,
	ta_e_transaction_type_t function );



/**
 * \brief Amount.
 * 
 * In a request defines the original amount for the transaction (given by ECR), in response
 * the final authorized amount (given by host) in minor units.
 * 
 * In a transaction request this field defines the amount in minor units that shall be
 * authorized for this transaction.
 * 
 * In a transcation response this field defines the amount in minor units that has actually
 * been authorized. If the full amount has been authorized as sent in the transaction request,
 * the value of the <sixml:Amount> field in the request and the response is equal.
 * 
 * PartialApproval: If the transaction has been approved only partially by the aquiring host,
 * the terminal must return on SIXml the actual authorized amount that has been returned from
 * host to terminal in the authorization response.
 * 
 * Example for ep2: The ECR sends an <sixml:Amount>10000</sixml:Amount> field on SIXml to the
 * terminal in the transaction request and the terminal sends this amount as
 * <ep2:AmtAuth>10000</ep2:AmtAuth> (=100 CHF) in the authorization request to the ep2 aquiring
 * host. The host then only can partially approve the transaction and returns the partial
 * approval amount <ep2:AmtAuth>8000</ep2:AmtAuth> (= 80 CHF) in the authorization response to
 * the terminal. The terminal then must return the actually approved amount back to the ECR,
 * <sixml:Amount Currency='CHF' Exponent='2'>8000</sixml:Amount>
 * 
 * The amount is additionally defined by the corresponding sixml:Currency and sixml:Exponent
 * attributes. An amount can have a negative value, e.g. in case of returning a gas
 * canister.
 * 
 * Example: <sixml:Amount Currency='CHF' Exponent='2'>10000</sixml:Amount> This is CHF 100.00
 * Example: <sixml:Amount Currency='CHF' Exponent='2'>-10000</sixml:Amount> This is CHF -100.00
 * Specification: <em>banking</em>.
 * 
 * \param[in] sub_transaction Object instance of type [sub_transaction](\ref sub_transaction.h).
 * \param[out] amount Pointer to variable to write object instance to. Object
 *                    instance is of type [amount](\ref amount.h) and is not retained. Object
 *                    instance is \em ta_object_invalid if value is not set in \em sub_transaction.
 * 
 * \retval ta_c_rc_ok Object instance written to \em amount.
 * \retval ta_c_rc_invalid_argument \em sub_transaction is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em sub_transaction is not of type [sub_transaction](\ref sub_transaction.h).
 * \retval ta_c_rc_invalid_argument \em amount is \em null-pointer.
 */
extern ta_e_result_code_t ta_sub_transaction_get_amount(
	ta_object_t sub_transaction,
	ta_object_t* amount );

/**
 * \brief Amount.
 * 
 * In a request defines the original amount for the transaction (given by ECR), in response
 * the final authorized amount (given by host) in minor units.
 * 
 * In a transaction request this field defines the amount in minor units that shall be
 * authorized for this transaction.
 * 
 * In a transcation response this field defines the amount in minor units that has actually
 * been authorized. If the full amount has been authorized as sent in the transaction request,
 * the value of the <sixml:Amount> field in the request and the response is equal.
 * 
 * PartialApproval: If the transaction has been approved only partially by the aquiring host,
 * the terminal must return on SIXml the actual authorized amount that has been returned from
 * host to terminal in the authorization response.
 * 
 * Example for ep2: The ECR sends an <sixml:Amount>10000</sixml:Amount> field on SIXml to the
 * terminal in the transaction request and the terminal sends this amount as
 * <ep2:AmtAuth>10000</ep2:AmtAuth> (=100 CHF) in the authorization request to the ep2 aquiring
 * host. The host then only can partially approve the transaction and returns the partial
 * approval amount <ep2:AmtAuth>8000</ep2:AmtAuth> (= 80 CHF) in the authorization response to
 * the terminal. The terminal then must return the actually approved amount back to the ECR,
 * <sixml:Amount Currency='CHF' Exponent='2'>8000</sixml:Amount>
 * 
 * The amount is additionally defined by the corresponding sixml:Currency and sixml:Exponent
 * attributes. An amount can have a negative value, e.g. in case of returning a gas
 * canister.
 * 
 * Example: <sixml:Amount Currency='CHF' Exponent='2'>10000</sixml:Amount> This is CHF 100.00
 * Example: <sixml:Amount Currency='CHF' Exponent='2'>-10000</sixml:Amount> This is CHF -100.00
 * Specification: <em>banking</em>.
 * 
 * \param[in] sub_transaction Object instance of type [sub_transaction](\ref sub_transaction.h).
 * \param[in] amount Object instance to set. Object instance can be
 *                   \em ta_object_invalid to clear the value in \em sub_transaction. If
 *                   object instance is not ta_object_invalid is has to be of type \em amount.
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em sub_transaction.
 * \retval ta_c_rc_invalid_argument \em sub_transaction is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em sub_transaction is not of type [sub_transaction](\ref sub_transaction.h).
 * \retval ta_c_rc_invalid_argument \em amount is not \em ta_object_invalid and
 *                                  is not of type [amount](\ref amount.h).
 */
extern ta_e_result_code_t ta_sub_transaction_set_amount(
	ta_object_t sub_transaction,
	ta_object_t amount );



/**
 * \brief DCC excange rate.
 * 
 * The DCC amount (sixml:AmuntDcc) will be calculated as follows: transaction amount
 * (sixml:Amount) / DCC rate (sixml:Rate).
 * 
 * Example: <sixml:Amount Currency="EUR" Exponent="2">2000</sixml:Amount> and the DCC
 * currency is "CHF", the sixml:Rate="8623328" and sixml:RateExponent="7" => 20.00 EUR /
 * 0.8623328 => 23.19 CHF
 * 
 * Optional: Only in multi currency situations
 * Specification: <em>banking</em>.
 * 
 * \param[in] sub_transaction Object instance of type [sub_transaction](\ref sub_transaction.h).
 * \param[out] rate Pointer to variable to write object instance to. Object instance is of type
 *                  [integer](\ref integer.h) and is not retained. Object instance is
 *                  \em ta_object_invalid if value is not set in \em sub_transaction.
 * 
 * \retval ta_c_rc_ok Object instance written to \em rate.
 * \retval ta_c_rc_invalid_argument \em sub_transaction is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em sub_transaction is not of type [sub_transaction](\ref sub_transaction.h).
 * \retval ta_c_rc_invalid_argument \em rate is \em null-pointer.
 */
extern ta_e_result_code_t ta_sub_transaction_get_rate(
	ta_object_t sub_transaction,
	ta_object_t* rate );

/**
 * \brief DCC excange rate.
 * 
 * The DCC amount (sixml:AmuntDcc) will be calculated as follows: transaction amount
 * (sixml:Amount) / DCC rate (sixml:Rate).
 * 
 * Example: <sixml:Amount Currency="EUR" Exponent="2">2000</sixml:Amount> and the DCC
 * currency is "CHF", the sixml:Rate="8623328" and sixml:RateExponent="7" => 20.00 EUR /
 * 0.8623328 => 23.19 CHF
 * 
 * Optional: Only in multi currency situations
 * Specification: <em>banking</em>.
 * 
 * \param[in] sub_transaction Object instance of type [sub_transaction](\ref sub_transaction.h).
 * \param[in] rate Object instance to set. Object instance can be \em ta_object_invalid to clear
 *                 the value in \em sub_transaction. If object instance is not ta_object_invalid
 *                 is has to be of type [integer](\ref integer.h).
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em sub_transaction.
 * \retval ta_c_rc_invalid_argument \em sub_transaction is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em sub_transaction is not of type [sub_transaction](\ref sub_transaction.h).
 * \retval ta_c_rc_invalid_argument \em rate is not \em ta_object_invalid and
 *                                  is not of type [integer](\ref integer.h).
 */
extern ta_e_result_code_t ta_sub_transaction_set_rate(
	ta_object_t sub_transaction,
	ta_object_t rate );



/**
 * \brief DCC excange rate exponent.
 * 
 * \param[in] sub_transaction Object instance of type [sub_transaction](\ref sub_transaction.h).
 * \param[out] rate_exponent Pointer to variable to write object instance to. Object instance is of type
 *                           [integer](\ref integer.h) and is not retained. Object instance is
 *                           \em ta_object_invalid if value is not set in \em sub_transaction.
 * 
 * \retval ta_c_rc_ok Object instance written to \em rate.
 * \retval ta_c_rc_invalid_argument \em sub_transaction is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em sub_transaction is not of type [sub_transaction](\ref sub_transaction.h).
 * \retval ta_c_rc_invalid_argument \em rate_exponent is \em null-pointer.
 */
extern ta_e_result_code_t ta_sub_transaction_get_rate_exponent(
	ta_object_t sub_transaction,
	ta_object_t* rate_exponent );

/**
 * \brief DCC excange rate exponent.
 * 
 * \param[in] sub_transaction Object instance of type [sub_transaction](\ref sub_transaction.h).
 * \param[in] rate_exponent Object instance to set. Object instance can be \em ta_object_invalid to clear
 *                          the value in \em sub_transaction. If object instance is not ta_object_invalid
 *                          is has to be of type [integer](\ref integer.h).
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em sub_transaction.
 * \retval ta_c_rc_invalid_argument \em sub_transaction is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em sub_transaction is not of type [sub_transaction](\ref sub_transaction.h).
 * \retval ta_c_rc_invalid_argument \em rate_exponent is not \em ta_object_invalid and
 *                                  is not of type [integer](\ref integer.h).
 */
extern ta_e_result_code_t ta_sub_transaction_set_rate_exponent(
	ta_object_t sub_transaction,
	ta_object_t rate_exponent );



#ifdef __cplusplus
}
#endif

#endif
