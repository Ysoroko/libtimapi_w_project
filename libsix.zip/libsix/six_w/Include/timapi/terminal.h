/**
 * \file
 * \brief Terminal.
 * 
 * Object type \em terminal.
 * 
 * \note
 * In contrary to other object types getter functions for the object type
 * \em terminal retains object instances returned to the caller.
 * 
 * \note
 * Once a terminal object instance has been disposed all future function
 * calls will fail with error ta_c_rc_invalid_argument.
 * 
 * \note
 * Terminal object instances operate using internal multi-threading structures.
 * Always call setter and action functions on the terminal object instances from the
 * main application thread. Never call these functions from inside \em terminal_listener
 * callbacks. If you need to call such functions in response to terminal events you have
 * to delay the function calls to be issued on the main thread. Main thread in this
 * context means the one and only thread issuing these kinds of function calls. Getter
 * functions on the other hand can be used during \em terminal_listener callbacks.
 */

#ifndef TA_TERMINAL_H
#define TA_TERMINAL_H

#include "features.h"
#include "logging.h"
#include "constants/result_code.h"
#include "constants/counter_type.h"
#include "constants/receipt_request_type.h"
#include "constants/transaction_type.h"
#include "constants/update_status.h"
#include "constants/loyalty_function_type.h"
#include "constants/function_hint.h"
#include "constants/maintenance_type.h"
#include "constants/mobile_topup_type.h"
#include "constants/additional_info_item.h"
#include "common/object.h"


#ifdef __cplusplus
extern "C" {
#endif


/**
 * \brief Tim Api Build Version.
 */
extern const char *ta_terminal_get_tim_api_version();


/**
 * \brief Create terminal instance. 
 * 
 * Caller retains a reference to the created instance. Different users can
 * individually retain the terminal instance themselves by calling
 * ta_object_retain. Each call to \ref ta_object_retain and \ref ta_terminal_create
 * has to be matched with a call to \ref ta_object_release. The terminal instance
 * is destroyed once nobody retains the terminal instance anymore.
 * 
 * The provided terminal settings instance is not change nor stored. Instead
 * an immutable copy thereof is stored.
 * 
 * \param[out] terminal Pointer to variable to write created object instance to.
 *                    Created object instance is retained.
 * \param[in] settings Object instance of type [terminal_settings](\ref terminal_settings.h). Terminal object
 *                     stores an internal read-only copy of the terminal settings.
 *                     It is safe to change the object instance after this call without
 *                     affecting the terminal object.
 * 
 * \retval ta_c_rc_ok Object instance has been created and written to \em terminal.
 * \retval ta_c_rc_invalid_argument \em terminal is \em null-pointer.
 * \retval ta_c_rc_invalid_argument \em settings is \ref ta_object_invalid.
 * \retval ta_c_rc_out_of_memory Failed allocating memory.
 */
extern ta_e_result_code_t ta_terminal_create(
	ta_object_t *terminal,
	ta_object_t settings );

/**
 * \brief Dispose of terminal.
 * 
 * Once disposed all terminal functionality returns ta_c_rc_invalid_argument if called.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * 
 * \retval ta_c_rc_ok Terminal has been disposed.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 */
extern ta_e_result_code_t ta_terminal_dispose(
	ta_object_t terminal );


/**
 * \brief Immutable terminal settings.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[out] settings Pointer to variable to write object instance to. Object
 *                      instance is of type [terminal_settings](\ref terminal_settings.h). Object instance
 *                      is retained.
 * 
 * \retval ta_c_rc_ok Object instance written to \em settings. Object instance has been retained.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 * \retval ta_c_rc_invalid_argument \em settings is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_get_settings(
	ta_object_t terminal,
	ta_object_t *settings );

/**
 * \brief Terminal identifier of connected terminal.
 * 
 * Returns ta_object_invalid if the terminal identifier is not known. The terminal identifier
 * is available after logging in to the terminal. The terminal identifier obtained from
 * the terminal is potentially different from the terminal identifier set in the
 * terminal_settings. This is especially true if ta_c_cm_on_fix_ip is used.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[out] terminal_id Pointer to variable to write object instance to. Object
 *                         instance is of type [string](\ref string.h). Object instance
 *                         is retained.
 * 
 * \retval ta_c_rc_ok Object instance written to \em settings. Object instance has been retained.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 * \retval ta_c_rc_invalid_argument \em terminal_id is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_get_terminal_id(
	ta_object_t terminal,
	ta_object_t *terminal_id );

/**
 * \brief POS identifier.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[out] pos_id Pointer to variable to write object instance to. Object
 *                    instance is of type [string](\ref string.h). Object instance
 *                    is retained.
 * 
 * \retval ta_c_rc_ok Object instance written to \em pos_id. Object instance has been retained.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 * \retval ta_c_rc_invalid_argument \em pos_id is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_get_pos_id(
	ta_object_t terminal,
	ta_object_t *pos_id );

/**
 * \brief Set POS identifier.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[in] pos_id Object instance to set. Object instance has to be of type [string](\ref string.h).
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em terminal.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 * \retval ta_c_rc_invalid_argument \em pos_id is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em pos_id is not of type [string](\ref string.h).
 */
extern ta_e_result_code_t ta_terminal_set_pos_id(
	ta_object_t terminal,
	ta_object_t pos_id );

/**
 * \brief User identifier.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[out] user_id Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Value written to \em user_id.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 * \retval ta_c_rc_invalid_argument \em user_id is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_get_user_id(
	ta_object_t terminal,
	int *user_id );

/**
 * \brief Set User identifier.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[in] user_id Value to set.
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em terminal.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 * \retval ta_c_rc_invalid_argument \em user_id is less than 0.
 */
extern ta_e_result_code_t ta_terminal_set_user_id(
	ta_object_t terminal,
	int user_id );

/**
 * \brief ECR Data.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[out] ecr_data Pointer to variable to write object instance to. Object
 *                      instance is of type [list](\ref list.h). Object instance is retained.
 *                      Elements in the list are of type [ecr_info](\ref ecr_info.h).
 * 
 * \retval ta_c_rc_ok Object instance written to \em ecr_data. Object instance has been retained.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 * \retval ta_c_rc_invalid_argument \em ecr_data is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_get_ecr_data(
	ta_object_t terminal,
	ta_object_t *ecr_data );

/**
 * \brief Set ECR Data.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[in] ecr_data Object instance to set. Object instance has to be of type [list](\ref list.h).
 *                     Elements in the list have to be of type [ecr_info](\ref ecr_info.h).
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em terminal.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 * \retval ta_c_rc_invalid_argument \em ecr_data is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em ecr_data is not of type [list](\ref list.h).
 * \retval ta_c_rc_invalid_argument Element in \em ecr_data is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument Element in \em ecr_data is not of type [ecr_info](\ref ecr_info.h).
 */
extern ta_e_result_code_t ta_terminal_set_ecr_data(
	ta_object_t terminal,
	ta_object_t ecr_data );

/**
 * \brief Add ECR data replacing existing one if present.
 * 
 * To remove elements use ta_terminal_set_ecr_data instead.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[in] ecr_info Object instance to add. Object instance has to be of type [ecr_info](\ref ecr_info.h).
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em terminal.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 * \retval ta_c_rc_invalid_argument \em ecr_info is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em ecr_info is not of type [ecr_info](\ref ecr_info.h).
 */
extern ta_e_result_code_t ta_terminal_add_ecr_data(
	ta_object_t terminal,
	ta_object_t ecr_info );

/**
 * \brief Allowed third party apps.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[out] allowed_third_party_apps OR combined flags from ta_e_allowed_third_party_apps_t.
 * 
 * \retval ta_c_rc_ok Object instance written to \em allowed_third_party_apps. Object instance has been retained.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 * \retval ta_c_rc_invalid_argument \em allowed_third_party_apps is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_get_allowed_third_party_apps(
	ta_object_t terminal,
	int* allowed_third_party_apps );

/**
 * \brief Set allowed third party apps.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[in] allowed_third_party_apps OR combined flags from ta_e_allowed_third_party_apps_t.
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em terminal.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 * \retval ta_c_rc_invalid_argument \em allowed_third_party_apps is \ref null-pointer.
 */
extern ta_e_result_code_t ta_terminal_set_allowed_third_party_apps(
	ta_object_t terminal,
	int allowed_third_party_apps );

/**
 * \brief Print options.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[out] print_options Pointer to variable to write object instance to. Object
 *                           instance is of type [list](\ref list.h). Object instance is retained.
 *                           Elements in the list are of type [print_option](\ref print_option.h).
 * 
 * \retval ta_c_rc_ok Object instance written to \em print_options.
 *                    Object instance has been retained.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 * \retval ta_c_rc_invalid_argument \em print_options is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_get_print_options(
	ta_object_t terminal,
	ta_object_t *print_options );

/**
 * \brief Set Print options.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[in] print_options Object instance to set. Object instance has to be of type [list](\ref list.h).
 *                          Elements in the list have to be of type [print_option](\ref print_option.h).
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em terminal.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 * \retval ta_c_rc_invalid_argument \em print_options is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em print_options is not of type [list](\ref list.h).
 * \retval ta_c_rc_invalid_argument Element in \em print_options is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument Element in \em print_options is not of type [print_option](\ref print_option.h).
 */
extern ta_e_result_code_t ta_terminal_set_print_options(
	ta_object_t terminal,
	ta_object_t print_options );

/**
 * \brief Merchant options.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[out] merchant_options Pointer to variable to write object instance to. Object
 *                              instance is of type [list](\ref list.h). Object instance is retained.
 *                              Elements in the list are of type [merchant_option](\ref merchant_option.h).
 * 
 * \retval ta_c_rc_ok Object instance written to \em merchant_options.
 *                    Object instance has been retained.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 * \retval ta_c_rc_invalid_argument \em merchant_options is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_get_merchant_options(
	ta_object_t terminal,
	ta_object_t *merchant_options );

/**
 * \brief Set Merchant options.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[in] merchant_options Object instance to set. Object instance has to be of type [list](\ref list.h).
 *                             Elements in the list have to be of type [merchant_option](\ref merchant_option.h).
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em terminal.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 * \retval ta_c_rc_invalid_argument \em merchant_options is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em merchant_options is not of type [list](\ref list.h).
 * \retval ta_c_rc_invalid_argument Element in \em merchant_options is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument Element in \em merchant_options is not of
 *                                  type \em merchant_option.
 */
extern ta_e_result_code_t ta_terminal_set_merchant_options(
	ta_object_t terminal,
	ta_object_t merchant_options );

/**
 * \brief Customer data.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[out] customer_data Pointer to variable to write object instance to. Object instance is
 *                           of type [map](\ref map.h). Object instance is retained. Elements in
 *                           the map are of key type [integer](\ref integer.h) containing values
 *                           of enumeration \ref ta_e_customer_data_type_t and value type
 *                           [string](\ref string.h).
 * 
 * \retval ta_c_rc_ok Object instance written to \em customer_data.
 *                    Object instance has been retained.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 * \retval ta_c_rc_invalid_argument \em customer_data is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_get_customer_data(
	ta_object_t terminal,
	ta_object_t *customer_data );

/**
 * \brief Set Customer data.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[in] customer_data Object instance to set. Object instance has to be of type [map](\ref map.h).
 *                          Elements in the list have to be of key type [integer](\ref integer.h)
 *                          with values from enumeration \ref ta_e_customer_data_type_t and value
 *                          type [string](\ref string.h).
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em terminal.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 * \retval ta_c_rc_invalid_argument \em customer_data is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em customer_data is not of type [map](\ref map.h).
 * \retval ta_c_rc_invalid_argument Element value in \em customer_data is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument Element key in \em customer_data is not of type
 *                                  [integer](\ref integer.h) with values from enumeration
 *                                  \ref ta_e_customer_data_type_t.
 * \retval ta_c_rc_invalid_argument Element value in \em customer_data is not of
 *                                  type [string](\ref string.h).
 */
extern ta_e_result_code_t ta_terminal_set_customer_data(
	ta_object_t terminal,
	ta_object_t customer_data );

/**
 * \brief Transaction data to use for transaction requests unless set manually.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[out] transaction_data Pointer to variable to write object instance to. Object
 *                              instance is \ref ta_object_invalid if not set in \em terminal.
 *                              If object instance is not ta_object_invalid it is of type
 *                              \em transaction_data and will be retained.
 * 
 * \retval ta_c_rc_ok Object instance written to \em transaction_data.
 *                    Object instance has been retained.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 * \retval ta_c_rc_invalid_argument \em transaction_data is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_get_transaction_data(
	ta_object_t terminal,
	ta_object_t *transaction_data );

/**
 * \brief Set transaction data to use for transaction requests unless set manually.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[in] transaction_data Object instance to set. Object instance can be
 *                             \ref ta_object_invalid to clear the value in \em terminal.
 *                             If object instance is not ta_object_invalid it has to be of
 *                             type \em transaction_data.
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em terminal.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 * \retval ta_c_rc_invalid_argument \em transaction_data is not ta_object_invalid and is not
 *                                  of type [transaction_data](\ref transaction_data.h).
 */
extern ta_e_result_code_t ta_terminal_set_transaction_data(
	ta_object_t terminal,
	ta_object_t transaction_data );



/**
 * \brief Receipt formatter.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[out] formatter Pointer to variable to write object instance to. Object instance is
 *                       \ref ta_object_invalid if not set in \em terminal. If object instance
 *                       is not ta_object_invalid it is of type
 *                       [receipt_formatter](\ref receipt_formatter.h) and will be retained.
 * 
 * \retval ta_c_rc_ok Object instance written to \em formatter. Object instance has been retained.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 * \retval ta_c_rc_invalid_argument \em formatter is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_get_receipt_formatter(
	ta_object_t terminal,
	ta_object_t *formatter );

/**
 * \brief Set receipt formatter.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[in] formatter Object instance to set. Object instance can be \ref ta_object_invalid
 *                      to clear the value in \em terminal. If object instance is not
 *                      ta_object_invalid it has to be of type
 *                      [receipt_formatter](\ref receipt_formatter.h).
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em terminal.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 * \retval ta_c_rc_invalid_argument \em formatter is not ta_object_invalid and is not of type
 *                                  [receipt_formatter](\ref receipt_formatter.h).
 */
extern ta_e_result_code_t ta_terminal_set_receipt_formatter(
	ta_object_t terminal,
	ta_object_t formatter );


/**
 * \brief Get terminal status.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[out] terminal_status Pointer to variable to write object instance to. Object instance
 *                             is of type [terminal_status](\ref terminal_status.h). Object instance is retained.
 * 
 * \retval ta_c_rc_ok Object instance written to \em terminal_status.
 *                    Object instance has been retained.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 * \retval ta_c_rc_invalid_argument \em terminal_status is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_get_terminal_status(
	ta_object_t terminal,
	ta_object_t *terminal_status );

/**
 * \brief Get brands or 0 if not retrieved yet.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[out] brands Pointer to variable to write object instance to. Object instance is
 *                    \ref ta_object_invalid if not set in \em terminal. Otherwise object
 *                    instance is of type [list](\ref list.h) and object instance is retained.
 *                    Elements in the list are of type [brand](\ref brand.h).
 * 
 * \retval ta_c_rc_ok Object instance written to \em brands.
 *                    Object instance has been retained.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 * \retval ta_c_rc_invalid_argument \em brands is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_get_brands(
	ta_object_t terminal,
	ta_object_t *brands );

/**
 * \brief Get features if known.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[out] features Pointer to variable to write values to if features are known.
 *                      Pointer can be \em null-pointer if only feature presence is of interest.
 * \param[out] has_features Pointer to variable to write presence of features. Set to
 *                          \ref ta_c_b_true if features are present otherwise \ref ta_c_b_false.
 * 
 * \retval ta_c_rc_ok Feature presence written to \em has_features. If \em has_features is
 *                    \ref ta_c_b_true values are also written to \em features.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 * \retval ta_c_rc_invalid_argument \em has_features is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_get_features(
	ta_object_t terminal,
	ta_s_features_t *features,
	ta_e_boolean_t *has_features );

/**
 * \brief Get supported languages or \em ta_object_invalid if unknown.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[out] languages Pointer to variable to write object instance to. Object instance is
 *                       \ref ta_object_invalid if not set in \em terminal. Otherwise object
 *                       instance is of type [list](\ref list.h) and object instance is retained.
 *                       Elements in the list are of type [string](\ref string.h).
 * 
 * \retval ta_c_rc_ok Object instance written to \em languages.
 *                    Object instance has been retained.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 * \retval ta_c_rc_invalid_argument \em languages is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_get_supported_languages(
	ta_object_t terminal,
	ta_object_t *languages );

/**
 * \brief Activation sequence counter.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[out] act_seq_counter Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Value written to \em act_seq_counter.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 * \retval ta_c_rc_invalid_argument \em act_seq_counter is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_get_act_seq_counter(
	ta_object_t terminal,
	int *act_seq_counter );

/**
 * \brief Get configuration data.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[out] config_data Pointer to variable to write object instance to. Object instance is
 *                    \ref ta_object_invalid if not set in \em terminal. Otherwise object
 *                    instance is of type [config_data](\ref config_data.h) and object instance is retained.
 * 
 * \retval ta_c_rc_ok Object instance written to \em config_data.
 *                    Object instance has been retained.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 * \retval ta_c_rc_invalid_argument \em config_data is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_get_config_data(
	ta_object_t terminal,
	ta_object_t *config_data );

/**
 * \brief Supported licensed features as 8 bytes hex encoded bitmap.
 * 
 * \deprecated Functionality removed.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[out] license Pointer to variable to write object instance to. Object instance is
 *                     \ref ta_object_invalid if not set in \em terminal. Otherwise object
 *                     instance is of type [string](\ref string.h) and object instance is retained.
 * 
 * \retval ta_c_rc_ok Object instance written to \em license.
 *                    Object instance has been retained.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 * \retval ta_c_rc_invalid_argument \em license is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_get_license(
	ta_object_t terminal,
	ta_object_t *license );


#ifndef DISABLE_SYNC_CALLS
/**
 * \brief Opens a user shift.
 * 
 * If the shift is already open, no error is returned.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[out] response Pointer to variable to write object instance to. Object instance is
 *                      of type [activate_response](\ref activate_response.h). Object instance is retained.
 * 
 * \retval ta_c_rc_ok Request finished successfully. Object instance written to \em response.
 *                    Object instance has been retained.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 * \retval ta_c_rc_invalid_argument \em response is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_activate(
	ta_object_t terminal,
	ta_object_t* response );
#endif

/**
 * \brief Opens a user shift.
 * 
 * If the shift is already open, no error is returned.
 * 
 * Asynchronous version of \ref ta_terminal_activate.
 * Callback function is \ref ta_cb_terminal_activate_completed.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * 
 * \retval ta_c_rc_ok Request send successfully.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 */
extern ta_e_result_code_t ta_terminal_activate_async(
	ta_object_t terminal );

#ifndef DISABLE_SYNC_CALLS
/**
 * \brief Requests the list of brands available on the terminal.
 * 
 * \par Side-Effect:
 * Updates Brands member with all brands available on the terminal.
 * Use \ref ta_terminal_get_brands to retrieve them.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * 
 * \retval ta_c_rc_ok Request finished successfully.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 */
extern ta_e_result_code_t ta_terminal_application_information(
	ta_object_t terminal );
#endif

/**
 * \brief Requests the list of brands available on the terminal.
 * 
 * Asynchronous version of \ref ta_terminal_application_information.
 * Callback function is \ref ta_cb_terminal_application_information_completed.
 * 
 * \par Side-Effect:
 * Updates Brands member with all brands available on the terminal.
 * Use \ref ta_terminal_get_brands to retrieve them.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * 
 * \retval ta_c_rc_ok Request send successfully.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 */
extern ta_e_result_code_t ta_terminal_application_information_async(
	ta_object_t terminal );

#ifndef DISABLE_SYNC_CALLS
/**
 * \brief Forces the EFT Terminal to transmit all transactions to the host system
 *        as well to do the daily closing.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[out] response Pointer to variable to write object instance to. Object instance is
 *                      of type [balance_response](\ref balance_response.h). Object instance is retained.
 * 
 * \retval ta_c_rc_ok Request finished successfully. Object instance written to \em response.
 *                    Object instance has been retained.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 * \retval ta_c_rc_invalid_argument \em response is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_balance(
	ta_object_t terminal,
	ta_object_t* response );
#endif

/**
 * \brief Forces the EFT Terminal to transmit all transactions to the host system
 *        as well to do the daily closing.
 * 
 * Asynchronous version of \ref ta_terminal_balance.
 * Callback function is \ref ta_cb_terminal_balance_completed.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * 
 * \retval ta_c_rc_ok Request send successfully.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 */
extern ta_e_result_code_t ta_terminal_balance_async(
	ta_object_t terminal );

/**
 * \brief Aborts an open asynchronous Financial Transaction or Non-Financial Transaction
 *        request, except for a ta_terminal_commit or ta_terminal_rollback_async request,
 *        which cannot be cancelled.
 * 
 * Further information: A Cancel-request is a best effort request. The EFT
 * Terminal can ignore the Cancel-request if the request in progress is in a state
 * it can not be cancelled. A Cancel-request has no effect if there's no open
 * request of a Financial Transaction or Non-financial Transaction. If the EFT
 * Terminal cancels the request in progress an error response is send back for the
 * cancelled request (see chapter Abort Purchase for an example). Cancel-requests
 * can be send multiple times in an attempt to cancel a request in progress but
 * should be spaced by a few seconds. Cancel-requests themselves are never
 * acknowledged by the EFT Terminal.
 * 
 * The Transaction request can only be cancelled before a Commit has been
 * performed. Also the underlying payment protocol can restrict this functionality.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * 
 * \retval ta_c_rc_ok Cancel send to terminal.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 */
extern ta_e_result_code_t ta_terminal_cancel(
	ta_object_t terminal );

/**
 * \brief Aborts an open asynchronous Financial Transaction or Non-Financial Transaction
 *        request, except for a ta_terminal_commit or ta_terminal_rollback_async request,
 *        which cannot be cancelled.
 * 
 * Further information: A Cancel-request is a best effort request. The EFT
 * Terminal can ignore the Cancel-request if the request in progress is in a state
 * it can not be cancelled. A Cancel-request has no effect if there's no open
 * request of a Financial Transaction or Non-financial Transaction. If the EFT
 * Terminal cancels the request in progress an error response is send back for the
 * cancelled request (see chapter Abort Purchase for an example). Cancel-requests
 * can be send multiple times in an attempt to cancel a request in progress but
 * should be spaced by a few seconds. Cancel-requests themselves are never
 * acknowledged by the EFT Terminal.
 * 
 * The Transaction request can only be cancelled before a Commit has been
 * performed. Also the underlying payment protocol can restrict this functionality.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[in] silent \ref ta_c_b_true to not show an abort screen otherwise \ref ta_c_b_false.
 * \param[in] retain_card \ref ta_c_b_true to not eject card otherwise \ref ta_c_b_false.
 * 
 * \retval ta_c_rc_ok Cancel send to terminal.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 */
extern ta_e_result_code_t ta_terminal_cancel2(
	ta_object_t terminal,
	ta_e_boolean_t silent,
	ta_e_boolean_t retain_card );

#ifndef DISABLE_SYNC_CALLS
/**
 * \brief Changes configuration parameters of the EFT Terminal.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[in] settings Object instance with settings. Object instance has to be of type [map](\ref map.h).
 *                     Keys in the map have to be of type [integer](\ref integer.h) matching
 *                     \em ta_e_setting_type_t. Values in the map have to be of type [string](\ref string.h).
 * 
 * \retval ta_c_rc_ok Request finished successfully.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 * \retval ta_c_rc_invalid_argument \em settings is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em settings is not of type [map](\ref map.h).
 * \retval ta_c_rc_invalid_argument Key in \em settings is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument Key in \em settings is not of type [integer](\ref integer.h).
 * \retval ta_c_rc_invalid_argument Value in \em settings is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument Value in \em settings is not of type [string](\ref string.h).
 */
extern ta_e_result_code_t ta_terminal_change_settings(
	ta_object_t terminal,
	ta_object_t settings );
#endif

/**
 * \brief Changes configuration parameters of the EFT Terminal.
 * 
 * Asynchronous version of \ref ta_terminal_change_settings.
 * Callback function is \ref ta_cb_terminal_change_settings_completed.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[in] settings Object instance with settings. Object instance has to be of type [map](\ref map.h).
 *                     Keys in the map have to be of type [integer](\ref integer.h) matching
 *                     \em ta_e_setting_type_t. Values in the map have to be of type [string](\ref string.h).
 * 
 * \retval ta_c_rc_ok Request send successfully.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 * \retval ta_c_rc_invalid_argument \em settings is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em settings is not of type [map](\ref map.h).
 * \retval ta_c_rc_invalid_argument Key in \em settings is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument Key in \em settings is not of type [integer](\ref integer.h).
 * \retval ta_c_rc_invalid_argument Value in \em settings is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument Value in \em settings is not of type [string](\ref string.h).
 */
extern ta_e_result_code_t ta_terminal_change_settings_async(
	ta_object_t terminal,
	ta_object_t settings );

#ifndef DISABLE_SYNC_CALLS
/**
 * \brief Performs Commit-operation after a successful Transaction call.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * 
 * \retval ta_c_rc_ok Request finished successfully.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 */
extern ta_e_result_code_t ta_terminal_commit(
	ta_object_t terminal );
#endif

/**
 * \brief Performs Commit-operation after a successful Transaction call.
 * 
 * Asynchronous version of \ref ta_terminal_commit.
 * Callback function is \ref ta_cb_terminal_commit_completed.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * 
 * \retval ta_c_rc_ok Request started successfully.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 */
extern ta_e_result_code_t ta_terminal_commit_async(
	ta_object_t terminal );

#ifndef DISABLE_SYNC_CALLS
/**
 * \brief Performs Commit-operation after a successful Transaction call.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[in] amount Object instance of type [amount](\ref amount.h) or \em ta_object_invalid.
 * \param[out] response Pointer to write object instance of type [print_data](\ref print_data.h).
 * 
 * \retval ta_c_rc_ok Request finished successfully.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 * \retval ta_c_rc_invalid_argument \em amount is not \ref ta_object_invalid and object instance
 *                                  is not of type [amount](\ref amount.h).
 * \retval ta_c_rc_invalid_argument \em response is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_commit_amount(
	ta_object_t terminal,
	ta_object_t amount,
	ta_object_t *response );
#endif

/**
 * \brief Performs Commit-operation after a successful Transaction call.
 * 
 * Asynchronous version of \ref ta_terminal_commit.
 * Callback function is \ref ta_cb_terminal_commit_completed.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[in] amount Object instance of type [amount](\ref amount.h) or \em ta_object_invalid.
 * 
 * \retval ta_c_rc_ok Request started successfully.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 * \retval ta_c_rc_invalid_argument \em amount is not \ref ta_object_invalid and object instance
 *                                  is not of type [amount](\ref amount.h).
 */
extern ta_e_result_code_t ta_terminal_commit_amount_async(
	ta_object_t terminal,
	ta_object_t amount );

#ifndef DISABLE_SYNC_CALLS
/**
 * \brief Initiates a connection to the EFT Terminal.
 * 
 * Calling this function is not needed normally, because all methods make
 * first a connect, if not connected
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * 
 * \retval ta_c_rc_ok Connected to terminal.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 */
extern ta_e_result_code_t ta_terminal_connect(
	ta_object_t terminal );
#endif

/**
 * \brief Initiates a connection to the EFT Terminal.
 * 
 * Calling this function is not needed normally, because all methods make
 * first a connect, if not connected
 * 
 * Asynchronous version of \ref ta_terminal_connect.
 * Callback function is \ref ta_cb_terminal_connect_completed.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * 
 * \retval ta_c_rc_ok Started connecting to terminal.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 */
extern ta_e_result_code_t ta_terminal_connect_async(
	ta_object_t terminal );

#ifndef DISABLE_SYNC_CALLS
/**
 * \brief Get counter information's from the EFT Terminal.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[in] counter_type Type of counters to receive.
 * \param[out] response Pointer to variable to write object instance to. Object instance is
 *                      of type [counters](\ref counters.h). Object instance is retained.
 * 
 * \retval ta_c_rc_ok Request finished successfully. Object instance written to \em response.
 *                    Object instance has been retained.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 * \retval ta_c_rc_invalid_argument \em response is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_counter_request(
	ta_object_t terminal,
	ta_e_counter_type_t counter_type,
	ta_object_t* response );
#endif

/**
 * \brief Get counter information's from the EFT Terminal.
 * 
 * Asynchronous version of \ref ta_terminal_counter_request.
 * Callback function is \ref ta_cb_terminal_counter_request_completed.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[in] counter_type Type of counters to receive.
 * 
 * \retval ta_c_rc_ok Request started successfully.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 */
extern ta_e_result_code_t ta_terminal_counter_request_async(
	ta_object_t terminal,
	ta_e_counter_type_t counter_type );

#ifndef DISABLE_SYNC_CALLS
/**
 * \brief Closes a user shift.
 * 
 * If the shift is already closed, no error is returned.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[out] response Pointer to variable to write object instance to. Object instance is
 *                      of type [deactivate_response](\ref deactivate_response.h). Object instance is retained.
 * 
 * \retval ta_c_rc_ok Request finished successfully. Object instance written to \em response.
 *                    Object instance has been retained.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 * \retval ta_c_rc_invalid_argument \em response is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_deactivate(
	ta_object_t terminal,
	ta_object_t* response );
#endif

/**
 * \brief Closes a user shift.
 * 
 * If the shift is already closed, no error is returned.
 * 
 * Asynchronous version of \ref ta_terminal_deactivate.
 * Callback function is \ref ta_cb_terminal_deactivate_completed.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * 
 * \retval ta_c_rc_ok Request started successfully.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 */
extern ta_e_result_code_t ta_terminal_deactivate_async(
	ta_object_t terminal );

#ifndef DISABLE_SYNC_CALLS
/**
 * \brief Interrupts the connection to the EFT Terminal.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * 
 * \retval ta_c_rc_ok Disconnected from terminal.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 */
extern ta_e_result_code_t ta_terminal_disconnect(
	ta_object_t terminal );
#endif

/**
 * \brief Interrupts the connection to the EFT Terminal.
 * 
 * Asynchronous version of \ref ta_terminal_disconnect.
 * Callback function is \ref ta_cb_terminal_disconnected.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * 
 * \retval ta_c_rc_ok Started disconnecting from terminal.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 */
extern ta_e_result_code_t ta_terminal_disconnect_async(
	ta_object_t terminal );

#ifndef DISABLE_SYNC_CALLS
/**
 * \brief Requests DCC rates from the EFT Terminal.
 * 
 * The DCC rates are returned as receipt.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[out] response Pointer to variable to write object instance to. Object instance is
 *                      of type [print_data](\ref print_data.h). Object instance is retained.
 * 
 * \retval ta_c_rc_ok Request finished successfully. Object instance written to \em response.
 *                    Object instance has been retained.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 * \retval ta_c_rc_invalid_argument \em response is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_dcc_rates(
	ta_object_t terminal,
	ta_object_t* response );
#endif

/**
 * \brief Requests DCC rates from the EFT Terminal.
 * 
 * The DCC rates are returned as receipt.
 * 
 * Asynchronous version of \ref ta_terminal_dcc_rates.
 * Callback function is \ref ta_cb_terminal_dcc_rates_completed.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * 
 * \retval ta_c_rc_ok Request started successfully.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 */
extern ta_e_result_code_t ta_terminal_dcc_rates_async(
	ta_object_t terminal );

#ifndef DISABLE_SYNC_CALLS
/**
 * \brief Get hardware information from the EFT Terminal.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[out] response Pointer to variable to write object instance to. Object instance is
 *                      of type [hardware_information_response](\ref hardware_information_response.h). Object instance is retained.
 * 
 * \retval ta_c_rc_ok Request finished successfully. Object instance written to \em response.
 *                    Object instance has been retained.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 * \retval ta_c_rc_invalid_argument \em response is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_hardware_information(
	ta_object_t terminal,
	ta_object_t* response );
#endif

/**
 * \brief Get hardware information from the EFT Terminal.
 * 
 * Asynchronous version of \ref ta_terminal_hardware_information.
 * Callback function is \ref ta_cb_terminal_hardware_information_completed.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * 
 * \retval ta_c_rc_ok Request started successfully.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 */
extern ta_e_result_code_t ta_terminal_hardware_information_async(
	ta_object_t terminal );

#ifndef DISABLE_SYNC_CALLS
/**
 * \brief Initialize a transaction knowing the amount or the card type.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[in] display_amount \ref ta_c_b_true to display amount on screen. \ref ta_c_b_false
 *                           to not display amount on screen. \em ta_c_b_undefined to use
 *                           default behavior of terminal.
 * \param[in] amount Object instance of type [amount](\ref amount.h). Can be \ref ta_object_invalid to
 *                   not use an amount. \em display_amount has no effect if not amount is used.
 * \param[out] response Pointer to variable to write object instance to. Object instance is
 *                      \ref ta_object_invalid if not contained in the response. Otherwise
 *                      object instance is of type [card_data](\ref card_data.h). Object instance is retained.
 * 
 * \retval ta_c_rc_ok Request finished successfully. Object instance written to \em response.
 *                    If object instance is not ta_object_invalid object instance has
 *                    been retained.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 * \retval ta_c_rc_invalid_argument \em amount is not \ref ta_object_invalid and is not of
 *                                  type \em amount.
 * \retval ta_c_rc_invalid_argument \em response is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_init_transaction(
	ta_object_t terminal,
	ta_e_boolean_t display_amount,
	ta_object_t amount,
	ta_object_t* response );

/**
 * \brief Initialize a transaction knowing the amount or the card type.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[in] display_amount \ref ta_c_b_true to display amount on screen. \ref ta_c_b_false
 *                           to not display amount on screen. \em ta_c_b_undefined to use
 *                           default behavior of terminal.
 * \param[in] amount Object instance of type [amount](\ref amount.h). Can be \ref ta_object_invalid to
 *                   not use an amount. \em display_amount has no effect if not amount is used.
 * \param[in] function_hint Function hint.
 * \param[out] response Pointer to variable to write object instance to. Object instance is
 *                      \ref ta_object_invalid if not contained in the response. Otherwise
 *                      object instance is of type [card_data](\ref card_data.h). Object instance is retained.
 * 
 * \retval ta_c_rc_ok Request finished successfully. Object instance written to \em response.
 *                    If object instance is not ta_object_invalid object instance has
 *                    been retained.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 * \retval ta_c_rc_invalid_argument \em amount is not \ref ta_object_invalid and is not of type \em amount.
 * \retval ta_c_rc_invalid_argument \em response is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_init_transaction2(
	ta_object_t terminal,
	ta_e_boolean_t display_amount,
	ta_object_t amount,
	ta_e_function_hint_t function_hint,
	ta_object_t* response );
#endif

/**
 * \brief Initialize a transaction knowing the amount or the card type.
 * 
 * Asynchronous version of \ref ta_terminal_init_transaction.
 * Callback function is \ref ta_cb_terminal_init_transaction_completed.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[in] display_amount \ref ta_c_b_true to display amount on screen. \ref ta_c_b_false
 *                           to not display amount on screen. \em ta_c_b_undefined to use
 *                           default behavior of terminal.
 * \param[in] amount Object instance of type [amount](\ref amount.h). Can be \ref ta_object_invalid to
 *                   not use an amount. \em display_amount has no effect if not amount is used.
 * 
 * \retval ta_c_rc_ok Request started successfully.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 * \retval ta_c_rc_invalid_argument \em amount is not \ref ta_object_invalid and is not of
 *                                  type \em amount.
 */
extern ta_e_result_code_t ta_terminal_init_transaction_async(
	ta_object_t terminal,
	ta_e_boolean_t display_amount,
	ta_object_t amount );

/**
 * \brief Initialize a transaction knowing the amount or the card type.
 * 
 * Asynchronous version of \ref ta_terminal_init_transaction.
 * Callback function is \ref ta_cb_terminal_init_transaction_completed.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[in] display_amount \ref ta_c_b_true to display amount on screen. \ref ta_c_b_false
 *                           to not display amount on screen. \em ta_c_b_undefined to use
 *                           default behavior of terminal.
 * \param[in] amount Object instance of type [amount](\ref amount.h). Can be \ref ta_object_invalid to
 *                   not use an amount. \em display_amount has no effect if not amount is used.
 * \param[in] function_hint Function hint.
 * 
 * \retval ta_c_rc_ok Request started successfully.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 * \retval ta_c_rc_invalid_argument \em amount is not \ref ta_object_invalid and is not of
 *                                  type \em amount.
 */
extern ta_e_result_code_t ta_terminal_init_transaction2_async(
	ta_object_t terminal,
	ta_e_boolean_t display_amount,
	ta_object_t amount,
	ta_e_function_hint_t function_hint );



#ifndef DISABLE_SYNC_CALLS
/**
 * \brief Starts an EFT Client Identification.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[out] response Pointer to variable to write object instance to. Object instance is
 *                      \ref ta_object_invalid if not contained in the response. Otherwise
 *                      object instance is of type [client_identification_response](\ref client_identification_response.h).
 *                      Object instance is retained.
 * 
 * \retval ta_c_rc_ok Request finished successfully. Object instance written to \em response.
 *                    If object instance is not ta_object_invalid object instance has
 *                    been retained.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 * \retval ta_c_rc_invalid_argument \em response is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_client_identification(
	ta_object_t terminal,
	ta_object_t* response );
#endif

/**
 * \brief Starts an EFT Client Identification.
 * 
 * Asynchronous version of \ref ta_terminal_client_identification.
 * Callback function is \ref ta_cb_terminal_client_identification_completed.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * 
 * \retval ta_c_rc_ok Request started successfully.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 */
extern ta_e_result_code_t ta_terminal_client_identification_async(
	ta_object_t terminal );



#ifndef DISABLE_SYNC_CALLS
/**
 * \brief Initialize a transaction with dialog.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[in] amount Object instance of type [amount](\ref amount.h).
 * \param[in] function_hint Function hint.
 * \param[in] dialog Object instance of type [show_dialog_request](\ref show_dialog_request.h).
 * \param[out] response Pointer to variable to write object instance to. Object instance is
 *                      \ref ta_object_invalid if not contained in the response. Otherwise
 *                      object instance is of type [init_transaction_response](\ref init_transaction_response.h).
 *                      Object instance is retained.
 * 
 * \retval ta_c_rc_ok Request finished successfully. Object instance written to \em response.
 *                    If object instance is not ta_object_invalid object instance has
 *                    been retained.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 * \retval ta_c_rc_invalid_argument \em amount is not \ref ta_object_invalid and is not of
 *                                  type \em amount.
 * \retval ta_c_rc_invalid_argument \em dialog is not \ref ta_object_invalid and is not of
 *                                  type \em show_dialog_request.
 * \retval ta_c_rc_invalid_argument \em response is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_init_transaction_with_dialog(
	ta_object_t terminal,
	ta_object_t amount,
	ta_e_function_hint_t function_hint,
	ta_object_t dialog,
	ta_object_t* response );
#endif

/**
 * \brief Initialize a transaction with dialog.
 * 
 * Asynchronous version of \ref ta_terminal_init_transaction_with_dialog.
 * Callback function is \ref ta_cb_terminal_init_transaction_with_dialog_completed.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[in] amount Object instance of type [amount](\ref amount.h).
 * \param[in] function_hint Function hint.
 * \param[in] dialog Object instance of type [show_dialog_request](\ref show_dialog_request.h).
 * 
 * \retval ta_c_rc_ok Request started successfully.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 * \retval ta_c_rc_invalid_argument \em amount is not \ref ta_object_invalid and is not of
 *                                  type \em amount.
 * \retval ta_c_rc_invalid_argument \em dialog is not \ref ta_object_invalid and is not of
 *                                  type \em show_dialog_request.
 */
extern ta_e_result_code_t ta_terminal_init_transaction_with_dialog_async(
	ta_object_t terminal,
	ta_object_t amount,
	ta_e_function_hint_t function_hint,
	ta_object_t dialog );


#ifndef DISABLE_SYNC_CALLS
/**
 * \brief Activate a communication session between the ECR and the terminal.
 * 
 * \note Before calling set the print options, POS identifier and
 *       manufacturer flags set in the terminal instance.
 * 
 * \par Side-Effect:
 * 
 * After completing the request updates the features, brands and terminal identifier
 * in the terminal instance. Fetching these information can be disabled if
 * Auto-FetchBrands is disabled terminal_settings
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * 
 * \retval ta_c_rc_ok Request finished successfully.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 */
extern ta_e_result_code_t ta_terminal_login(
	ta_object_t terminal );
#endif

/**
 * \brief Activate a communication session between the ECR and the terminal.
 * 
 * Asynchronous version of \ref ta_terminal_login.
 * Callback function is \ref ta_cb_terminal_login_completed.
 * 
 * \note Before calling set the print options, POS identifier and
 *       manufacturer flags set in the terminal instance.
 * 
 * \par Side-Effect:
 * 
 * After completing the request updates the features, brands and terminal identifier
 * in the terminal instance. Fetching these information can be disabled if
 * Auto-FetchBrands is disabled terminal_settings
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * 
 * \retval ta_c_rc_ok Request started successfully.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 */
extern ta_e_result_code_t ta_terminal_login_async(
	ta_object_t terminal );

#ifndef DISABLE_SYNC_CALLS
/**
 * \brief Terminates an active communication session between the ECR and the terminal.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * 
 * \retval ta_c_rc_ok Request finished successfully.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 */
extern ta_e_result_code_t ta_terminal_logout(
	ta_object_t terminal );
#endif

/**
 * \brief Terminates an active communication session between the ECR and the terminal.
 * 
 * Asynchronous version of \ref ta_terminal_logout.
 * Callback function is \ref ta_cb_terminal_logout_completed.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * 
 * \retval ta_c_rc_ok Request started successfully.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 */
extern ta_e_result_code_t ta_terminal_logout_async(
	ta_object_t terminal );

#ifndef DISABLE_SYNC_CALLS
/**
 * \brief Force the EFT Terminal to reboot.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * 
 * \retval ta_c_rc_ok Request finished successfully.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 */
extern ta_e_result_code_t ta_terminal_reboot(
	ta_object_t terminal );
#endif

/**
 * \brief Force the EFT Terminal to reboot.
 * 
 * Asynchronous version of \ref ta_terminal_reboot.
 * Callback function is \ref ta_cb_terminal_reboot_completed.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * 
 * \retval ta_c_rc_ok Request started successfully.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 */
extern ta_e_result_code_t ta_terminal_reboot_async(
	ta_object_t terminal );

#ifndef DISABLE_SYNC_CALLS
/**
 * \brief Force the EFT Terminal to transmit all financial transactions to the host system.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[out] response Pointer to variable to write object instance to. Object instance is
 *                      of type [reconciliation_response](\ref reconciliation_response.h). Object instance is retained.
 * 
 * \retval ta_c_rc_ok Request finished successfully. Object instance written to \em response.
 *                    Object instance has been retained.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 * \retval ta_c_rc_invalid_argument \em response is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_reconciliation(
	ta_object_t terminal,
	ta_object_t* response );
#endif

/**
 * \brief Force the EFT Terminal to transmit all financial transactions to the host system.
 * 
 * Asynchronous version of \ref ta_terminal_reconciliation.
 * Callback function is \ref ta_cb_terminal_reconciliation_completed.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * 
 * \retval ta_c_rc_ok Request started successfully.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 */
extern ta_e_result_code_t ta_terminal_reconciliation_async(
	ta_object_t terminal );

#ifndef DISABLE_SYNC_CALLS
/**
 * \brief Receive the latest receipt or a list of silent receipts.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[in] type Type of receipts to receive.
 * \param[out] response Pointer to variable to write object instance to. Object instance is
 *                      of type [receipt_request_response](\ref receipt_request_response.h). Object instance is retained.
 * 
 * \retval ta_c_rc_ok Request finished successfully. Object instance written to \em response.
 *                    Object instance has been retained.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 * \retval ta_c_rc_invalid_argument \em response is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_receipt_request(
	ta_object_t terminal,
	ta_e_receipt_request_type_t type,
	ta_object_t* response );
#endif

/**
 * \brief Receive the latest receipt or a list of silent receipts.
 * 
 * Asynchronous version of \ref ta_terminal_receipt_request.
 * Callback function is \ref ta_cb_terminal_receipt_request_completed.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[in] type Type of receipts to receive.
 * 
 * \retval ta_c_rc_ok Request started successfully.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 */
extern ta_e_result_code_t ta_terminal_receipt_request_async(
	ta_object_t terminal,
	ta_e_receipt_request_type_t type );

#ifndef DISABLE_SYNC_CALLS
/**
 * \brief Receive the latest transaction information.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[out] response Pointer to variable to write object instance to. Object instance is
 *                      of type [transaction_info_request_response](\ref transaction_info_request_response.h). Object instance is retained.
 * 
 * \retval ta_c_rc_ok Request finished successfully. Object instance written to \em response.
 *                    Object instance has been retained.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 * \retval ta_c_rc_invalid_argument \em response is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_transaction_info_request(
	ta_object_t terminal,
	ta_object_t* response );
#endif

/**
 * \brief Receive the latest transaction information.
 * 
 * Asynchronous version of \ref ta_terminal_transaction_info_request.
 * Callback function is \ref ta_cb_terminal_transaction_info_request_completed.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * 
 * \retval ta_c_rc_ok Request started successfully.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 */
extern ta_e_result_code_t ta_terminal_transaction_info_request_async(
	ta_object_t terminal );

#ifndef DISABLE_SYNC_CALLS
/**
 * \brief Force the EFT Terminal to get the configuration from the service center.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[out] response Pointer to variable to write object instance to. Object instance is
 *                      \ref ta_object_invalid if not contained in response. Otherwise object
 *                      instance is of type [print_data](\ref print_data.h). Object instance is retained.
 * 
 * \retval ta_c_rc_ok Request finished successfully. Object instance written to \em response.
 *                    If object instance is not ta_object_invalid object instance has
 *                    been retained.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 * \retval ta_c_rc_invalid_argument \em response is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_reconfig(
	ta_object_t terminal,
	ta_object_t* response );
#endif

/**
 * \brief Force the EFT Terminal to get the configuration from the service center.
 * 
 * Asynchronous version of \ref ta_terminal_reconfig.
 * Callback function is \ref ta_cb_terminal_reconfig_completed.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * 
 * \retval ta_c_rc_ok Request started successfully.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 */
extern ta_e_result_code_t ta_terminal_reconfig_async(
	ta_object_t terminal );

#ifndef DISABLE_SYNC_CALLS
/**
 * \brief Prevents a transaction from being committed to the transaction log and
 *        generates a technical reversal of the authorization.
 * 
 * For payment protocols supporting the function a declined receipt may be generated.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[out] response Pointer to variable to write object instance to. Object instance is
 *                      \ref ta_object_invalid if not contained in response. Otherwise object
 *                      instance is of type [print_data](\ref print_data.h). Object instance is retained.
 * 
 * \retval ta_c_rc_ok Request finished successfully. Object instance written to \em response.
 *                    Object instance has been retained.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 * \retval ta_c_rc_invalid_argument \em response is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_rollback(
	ta_object_t terminal,
	ta_object_t* response );
#endif

/**
 * \brief Prevents a transaction from being committed to the transaction log and
 *        generates a technical reversal of the authorization.
 * 
 * For payment protocols supporting the function a declined receipt may be generated.
 * 
 * Asynchronous version of \ref ta_terminal_rollback.
 * Callback function is \ref ta_cb_terminal_rollback_completed.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * 
 * \retval ta_c_rc_ok Request started successfully.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 */
extern ta_e_result_code_t ta_terminal_rollback_async(
	ta_object_t terminal );

#ifndef DISABLE_SYNC_CALLS
/**
 * \brief Force the EFT Terminal to start a Software Update.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[out] response Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Request finished successfully. Value written to \em response.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 * \retval ta_c_rc_invalid_argument \em response is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_software_update(
	ta_object_t terminal,
	ta_e_update_status_t* response );
#endif

/**
 * \brief Force the EFT Terminal to start a Software Update.
 * 
 * Asynchronous version of \ref ta_terminal_software_update.
 * Callback function is \ref ta_cb_terminal_software_update_completed.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * 
 * \retval ta_c_rc_ok Request started successfully.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
*/
extern ta_e_result_code_t ta_terminal_software_update_async(
	ta_object_t terminal );

#ifndef DISABLE_SYNC_CALLS
/**
 * \brief Request system information from the EFT Terminal.
 * 
 * \note Set EcrData property before calling SystemInformation.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[out] response Pointer to variable to write object instance to. Object instance is
 *                      of type [system_information_response](\ref system_information_response.h).
 *                      Object instance is retained.
 * 
 * \retval ta_c_rc_ok Request finished successfully. Object instance written to \em response.
 *                    Object instance has been retained.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 * \retval ta_c_rc_invalid_argument \em response is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_system_information(
	ta_object_t terminal,
	ta_object_t* response );
#endif

/**
 * \brief Request system information from the EFT Terminal.
 * 
 * Asynchronous version of \ref ta_terminal_system_information.
 * Callback function is \ref ta_cb_terminal_system_information_completed.
 * 
 * \note Set EcrData property before calling SystemInformation.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * 
 * \retval ta_c_rc_ok Request started successfully.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 */
extern ta_e_result_code_t ta_terminal_system_information_async(
	ta_object_t terminal );

#ifndef DISABLE_SYNC_CALLS
/**
 * \brief Starts an EFT Terminal Transaction.
 * 
 * \note The transaction parameters are taken from TransactionRequest terminal
 *       property since those do not change often if at all (default parameters).
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[in] type Transaction type.
 * \param[in] amount Object instance of type [amount](\ref amount.h).
 * \param[out] response Pointer to variable to write object instance to. Object instance is
 *                      of type [transaction_response](\ref transaction_response.h). Object instance is retained.
 * 
 * \retval ta_c_rc_ok Request finished successfully. Object instance written to \em response.
 *                    Object instance has been retained.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 * \retval ta_c_rc_invalid_argument \em amount is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em response is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_transaction(
	ta_object_t terminal,
	ta_e_transaction_type_t type,
	ta_object_t amount,
	ta_object_t* response );
#endif
/**
 * \brief Starts an EFT Terminal Transaction.
 * 
 * Asynchronous version of \ref ta_terminal_transaction.
 * Callback function is \ref ta_cb_terminal_transaction_completed.
 * 
 * \note The transaction parameters are taken from TransactionRequest terminal
 *       property since those do not change often if at all (default parameters).
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[in] type Transaction type.
 * \param[in] amount Object instance of type [amount](\ref amount.h).
 * 
 * \retval ta_c_rc_ok Request started successfully.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 * \retval ta_c_rc_invalid_argument \em amount is \ref ta_object_invalid.
 */
extern ta_e_result_code_t ta_terminal_transaction_async(
	ta_object_t terminal,
	ta_e_transaction_type_t type,
	ta_object_t amount );

#ifndef DISABLE_SYNC_CALLS
/**
 * \brief Starts an EFT Terminal Transaction.
 * 
 * \note The transaction parameters are taken from TransactionRequest terminal
 *       property since those do not change often if at all (default parameters).
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[in] type Transaction type.
 * \param[in] request Object instance of type [transaction_request](\ref transaction_request.h).
 * \param[out] response Pointer to variable to write object instance to. Object instance is
 *                      of type [transaction_response](\ref transaction_response.h). Object instance is retained.
 * 
 * \retval ta_c_rc_ok Request finished successfully. Object instance written to \em response.
 *                    Object instance has been retained.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 * \retval ta_c_rc_invalid_argument \em request is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em request is not of type [transaction_request](\ref transaction_request.h).
 * \retval ta_c_rc_invalid_argument \em response is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_transaction2(
	ta_object_t terminal,
	ta_e_transaction_type_t type,
	ta_object_t request,
	ta_object_t* response );
#endif

/**
 * \brief Starts an EFT Terminal Transaction.
 * 
 * Asynchronous version of \ref ta_terminal_transaction2.
 * Callback function is \ref ta_cb_terminal_transaction_completed.
 * 
 * \note The transaction parameters are taken from TransactionRequest terminal
 *       property since those do not change often if at all (default parameters).
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[in] type Transaction type.
 * \param[in] request Object instance of type [transaction_request](\ref transaction_request.h).
 * 
 * \retval ta_c_rc_ok Request started successfully.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 * \retval ta_c_rc_invalid_argument \em request is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em request is not of type [transaction_request](\ref transaction_request.h).
 */
extern ta_e_result_code_t ta_terminal_transaction2_async(
	ta_object_t terminal,
	ta_e_transaction_type_t type,
	ta_object_t request );

#ifndef DISABLE_SYNC_CALLS
/**
 * \brief Starts an EFT Terminal Transaction.
 * 
 * \note The transaction parameters are taken from TransactionRequest terminal
 *       property since those do not change often if at all (default parameters).
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[in] type Transaction type.
 * \param[in] amount Object instance of type [amount](\ref amount.h).
 * \param[in] amount_tip Object instance of type [amount](\ref amount.h).
 * \param[out] response Pointer to variable to write object instance to. Object instance is
 *                      of type [transaction_response](\ref transaction_response.h). Object instance is retained.
 * 
 * \retval ta_c_rc_ok Request finished successfully. Object instance written to \em response.
 *                    Object instance has been retained.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 * \retval ta_c_rc_invalid_argument \em amount is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em amount_tip is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em response is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_transaction_tip(
	ta_object_t terminal,
	ta_e_transaction_type_t type,
	ta_object_t amount,
	ta_object_t amount_tip,
	ta_object_t* response );
#endif

/**
 * \brief Starts an EFT Terminal Transaction.
 * 
 * Asynchronous version of \ref ta_terminal_transaction_tip.
 * Callback function is \ref ta_cb_terminal_transaction_completed.
 * 
 * \note The transaction parameters are taken from TransactionRequest terminal
 *       property since those do not change often if at all (default parameters).
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[in] type Transaction type.
 * \param[in] amount Object instance of type [amount](\ref amount.h).
 * \param[in] amount_tip Object instance of type [amount](\ref amount.h).
 * 
 * \retval ta_c_rc_ok Request started successfully.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 * \retval ta_c_rc_invalid_argument \em amount is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em amount_tip is \ref ta_object_invalid.
 */
extern ta_e_result_code_t ta_terminal_transaction_tip_async(
	ta_object_t terminal,
	ta_e_transaction_type_t type,
	ta_object_t amount,
	ta_object_t amount_tip );

#ifndef DISABLE_SYNC_CALLS
/**
 * \brief Starts an EFT Terminal Transaction.
 * 
 * \note The transaction parameters are taken from TransactionRequest terminal
 *       property since those do not change often if at all (default parameters).
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[in] type Transaction type.
 * \param[in] amount Object instance of type [amount](\ref amount.h).
 * \param[in] amount_cashback Object instance of type [amount](\ref amount.h).
 * \param[out] response Pointer to variable to write object instance to. Object instance is
 *                      of type [transaction_response](\ref transaction_response.h). Object instance is retained.
 * 
 * \retval ta_c_rc_ok Request finished successfully. Object instance written to \em response.
 *                    Object instance has been retained.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 * \retval ta_c_rc_invalid_argument \em amount is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em amount_cashback is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em response is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_transaction_cashback(
	ta_object_t terminal,
	ta_e_transaction_type_t type,
	ta_object_t amount,
	ta_object_t amount_cashback,
	ta_object_t* response );
#endif

/**
 * \brief Starts an EFT Terminal Transaction.
 * 
 * Asynchronous version of \ref ta_terminal_transaction_cashback.
 * Callback function is \ref ta_cb_terminal_transaction_completed.
 * 
 * \note The transaction parameters are taken from TransactionRequest terminal
 *       property since those do not change often if at all (default parameters).
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[in] type Transaction type.
 * \param[in] amount Object instance of type [amount](\ref amount.h).
 * \param[in] amount_cashback Object instance of type [amount](\ref amount.h).
 * 
 * \retval ta_c_rc_ok Request started successfully.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 * \retval ta_c_rc_invalid_argument \em amount is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em amount_cashback is \ref ta_object_invalid.
 */
extern ta_e_result_code_t ta_terminal_transaction_cashback_async(
	ta_object_t terminal,
	ta_e_transaction_type_t type,
	ta_object_t amount,
	ta_object_t amount_cashback );


#ifndef DISABLE_SYNC_CALLS
/**
 * \brief Close the shutter of the card reader.
 * 
 * \note This method is only available if guide unattended is enabled.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * 
 * \retval ta_c_rc_ok Request finished successfully.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 */
extern ta_e_result_code_t ta_terminal_close_reader(
	ta_object_t terminal );
#endif

/**
 * \brief Close the shutter of the card reader.
 * 
 * Asynchronous version of \ref ta_terminal_close_reader.
 * Callback function is \ref ta_cb_terminal_close_reader_completed.
 * 
 * \note This method is only available if guide unattended is enabled.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * 
 * \retval ta_c_rc_ok Request started successfully.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 */
extern ta_e_result_code_t ta_terminal_close_reader_async(
	ta_object_t terminal );

#ifndef DISABLE_SYNC_CALLS
/**
 * \brief Open the shutter of the card reader.
 * 
 * \note This method is only available if guide unattended is enabled.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * 
 * \retval ta_c_rc_ok Request finished successfully.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 */
extern ta_e_result_code_t ta_terminal_open_reader(
	ta_object_t terminal );
#endif

/**
 * \brief Open the shutter of the card reader.
 * 
 * Asynchronous version of \ref ta_terminal_open_reader.
 * Callback function is \ref ta_cb_terminal_open_reader_completed.
 * 
 * \note This method is only available if guide unattended is enabled.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * 
 * \retval ta_c_rc_ok Request started successfully.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 */
extern ta_e_result_code_t ta_terminal_open_reader_async(
	ta_object_t terminal );

#ifndef DISABLE_SYNC_CALLS
/**
 * \brief Eject a card from the card reader.
 * 
 * \note This method is only available if guide unattended is enabled.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * 
 * \retval ta_c_rc_ok Request finished successfully.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 */
extern ta_e_result_code_t ta_terminal_eject_card(
	ta_object_t terminal );
#endif

/**
 * \brief Eject a card from the card reader.
 * 
 * Asynchronous version of \ref ta_terminal_eject_card.
 * Callback function is \ref ta_cb_terminal_eject_card_completed.
 * 
 * \note This method is only available if guide unattended is enabled.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * 
 * \retval ta_c_rc_ok Request started successfully.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 */
extern ta_e_result_code_t ta_terminal_eject_card_async(
	ta_object_t terminal );

#ifndef DISABLE_SYNC_CALLS
/**
 * \brief Opens the maintenance window to the terminal so it can perform collected
 *        maintenance requests on its own, without interaction with the ECR.
 * 
 * The terminal shall respond immediately to the ECR request whether it is able to handle
 * the request or not.
 * 
 * If the terminal is able to handle the request, the ECR is free itself to perform
 * maintenance as well or it can monitor the terminal by reading the terminal_status
 * notifications.
 * 
 * It is possible that the connection between ECR and EFT terminal is terminated due to
 * one or multiple reboot processes.
 * 
 * \note This method is only available if guide unattended is enabled.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * 
 * \retval ta_c_rc_ok Request finished successfully.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 */
extern ta_e_result_code_t ta_terminal_open_maintenance_window(
	ta_object_t terminal );
#endif

/**
 * \brief Opens the maintenance window to the terminal so it can perform collected
 *        maintenance requests on its own, without interaction with the ECR.
 * 
 * The terminal shall respond immediately to the ECR request whether it is able to handle
 * the request or not.
 * 
 * If the terminal is able to handle the request, the ECR is free itself to perform
 * maintenance as well or it can monitor the terminal by reading the terminal_status
 * notifications.
 * 
 * It is possible that the connection between ECR and EFT terminal is terminated due to
 * one or multiple reboot processes.
 * 
 * Asynchronous version of \ref ta_terminal_open_maintenance_window.
 * Callback function is \ref ta_cb_terminal_open_maintenance_window_completed.
 * 
 * \note This method is only available if guide unattended is enabled.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * 
 * \retval ta_c_rc_ok Request started successfully.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 */
extern ta_e_result_code_t ta_terminal_open_maintenance_window_async(
	ta_object_t terminal );

#ifndef DISABLE_SYNC_CALLS
/**
 * \brief Closes the maintenance window to the terminal so it can perform collected
 *        maintenance requests on its own, without interaction with the ECR.
 * 
 * The terminal shall respond immediately to the ECR request whether it is able to handle
 * the request or not.
 * 
 * If the terminal is able to handle the request, the ECR is free itself to perform
 * maintenance as well or it can monitor the terminal by reading the terminal_status
 * notifications.
 * 
 * It is possible that the connection between ECR and EFT terminal is terminated due to
 * one or multiple reboot processes.
 * 
 * \note This method is only available if guide unattended is enabled.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * 
 * \retval ta_c_rc_ok Request finished successfully.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 */
extern ta_e_result_code_t ta_terminal_close_maintenance_window(
	ta_object_t terminal );
#endif

/**
 * \brief Closes the maintenance window to the terminal so it can perform collected
 *        maintenance requests on its own, without interaction with the ECR.
 * 
 * The terminal shall respond immediately to the ECR request whether it is able to handle
 * the request or not.
 * 
 * If the terminal is able to handle the request, the ECR is free itself to perform
 * maintenance as well or it can monitor the terminal by reading the terminal_status
 * notifications.
 * 
 * It is possible that the connection between ECR and EFT terminal is terminated due to
 * one or multiple reboot processes.
 * 
 * Asynchronous version of \ref ta_terminal_close_maintenance_window.
 * Callback function is \ref ta_cb_terminal_close_maintenance_window_completed.
 * 
 * \note This method is only available if guide unattended is enabled.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * 
 * \retval ta_c_rc_ok Request started successfully.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 */
extern ta_e_result_code_t ta_terminal_close_maintenance_window_async(
	ta_object_t terminal );

/**
 * \brief Extends the Commit timeout if the terminal needs additional time before the
 *        Commit shall be performed.
 * 
 * An example could be on a public transport vending machine: if the machine is printing
 * multiple tickets and this printing action would extend the commit timeout, a hold_commit
 * notification shall be sent to extend the Commit timeout as well. If the printing action
 * fails after some tickets a partial commit can be performed.
 * 
 * \note This method is only available if guide unattended is enabled.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * 
 * \retval ta_c_rc_ok Hold commit send to terminal.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 */
extern ta_e_result_code_t ta_terminal_hold_commit(
	ta_object_t terminal );

#ifndef DISABLE_SYNC_CALLS
/**
 * \brief Activate service menu.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * 
 * \retval ta_c_rc_ok Request finished successfully.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 */
extern ta_e_result_code_t ta_terminal_activate_service_menu(
	ta_object_t terminal );
#endif

/**
 * \brief Activate service menu.
 * 
 * Asynchronous version of \ref ta_terminal_activate_service_menu.
 * Callback function is \ref ta_cb_terminal_activate_service_menu_completed.
 * 
 * \note This method is only available if guide unattended is enabled.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * 
 * \retval ta_c_rc_ok Request started successfully.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 */
extern ta_e_result_code_t ta_terminal_activate_service_menu_async(
	ta_object_t terminal );

/**
 * \brief Dynamically adjusts the transaction amount of an already running transaction.
 * 
 * This is a "best effort" function and will be processed as long as the underlaying payment
 * protocol supports it. The amount transmitted in the notification is the new total amount.
 * The EFT does \em not calculate amounts, this is the ECRs responsibility.
 * 
 * To be able to validate if this notification has been processed correctly the
 * \em TerminalStatus-notification must return the current adjusted \em Amount.
 * 
 * \note This method is only available if guide unattended is enabled.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[in] amount Object instance of type [amount](\ref amount.h).
 * 
 * \retval ta_c_rc_ok Hold commit send to terminal.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 * \retval ta_c_rc_invalid_argument \em amount is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em amount is not of type [amount](\ref amount.h).
 */
extern ta_e_result_code_t ta_terminal_amt_adjustment(
	ta_object_t terminal,
	ta_object_t amount );

/**
 * \brief Dynamically adjusts the transaction amount of an already running transaction.
 * 
 * This is a "best effort" function and will be processed as long as the underlaying payment
 * protocol supports it. The amount transmitted in the notification is the new total amount.
 * The EFT does \em not calculate amounts, this is the ECRs responsibility.
 * 
 * To be able to validate if this notification has been processed correctly the
 * \em TerminalStatus-notification must return the current adjusted \em Amount.
 * 
 * \note This method is only available if guide unattended is enabled.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[in] amount Object instance of type [amount](\ref amount.h).
 * \param[in] amount_discount Optional discount amount. If not \ref ta_object_invalid object instance
 *                            has to be of type [amount_discount](\ref amount_discount.h).
 * \param[in] loyalty_coupon_list Optional list of loyalty coupons. If not \ref ta_object_invalid
 *                                object instance has to be of type [list](\ref list.h) with
 *                                elements inside have to be of type
 *                                [loyalty_coupon](\ref loyalty_coupon.h).
 * \param[in] loyalty_information_list Optional list of loyalty information. If not \ref ta_object_invalid
 *                                     object instance has to be of type [list](\ref list.h) with
 *                                     elements inside have to be of type
 *                                     [loyalty_information](\ref loyalty_information.h).
 * 
 * \retval ta_c_rc_ok Hold commit send to terminal.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 * \retval ta_c_rc_invalid_argument \em amount is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em amount is not of type [amount](\ref amount.h).
 * \retval ta_c_rc_invalid_argument \em amount_discount is not \ref ta_object_invalid and is not of
 *                                  type [amount_discount](\ref amount_discount.h).
 * \retval ta_c_rc_invalid_argument \em loyalty_coupon_list is not \ref ta_object_invalid and not of
 *                                  type [list](\ref list.h).
 * \retval ta_c_rc_invalid_argument Elements in \em loyalty_coupon_list are \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument Elements in \em loyalty_coupon_list are not of type
 *                                  [loyalty_coupon](\ref loyalty_coupon.h).
 * \retval ta_c_rc_invalid_argument \em loyalty_information_list is not \ref ta_object_invalid and not of
 *                                  type [list](\ref list.h).
 * \retval ta_c_rc_invalid_argument Elements in \em loyalty_information_list are \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument Elements in \em loyalty_information_list are not of type
 *                                  [loyalty_information](\ref loyalty_information.h).
 */
extern ta_e_result_code_t ta_terminal_amt_adjustment_2(
	ta_object_t terminal,
	ta_object_t amount,
	ta_object_t amount_discount,
	ta_object_t loyalty_coupon_list,
	ta_object_t loyalty_information_list );


#ifndef DISABLE_SYNC_CALLS
/**
 * \brief This function is used to query and configure loyalty information.
 * 
 * \note This method is only available if guide value added services is enabled.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[in] function_type Defines what kind of loyalty mode will be used.
 * \param[in] data_type Specifies type of loyalty data. Mandatory for function_type
 *                      \ref ta_c_lft_init, \ref ta_c_lft_update and \ref ta_c_lft_deinit.
 *                      If not \ref ta_object_invalid has to be of type [string](\ref string.h).
 * \param[in] data Loyalty data. Object of type [string](\ref string.h).
 * \param[in] retain_card \ref ta_c_b_true to not eject card otherwise \ref ta_c_b_false.
 * \param[out] response Variable to write object of type [card_data](\ref card_data.h).
 * 
 * \retval ta_c_rc_ok Request finished successfully.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 * \retval ta_c_rc_invalid_argument \em function_type is not a valid value of
 *                                  [ta_e_loyalty_function_type_t](\ref loyalty_function_type.h).
 * \retval ta_c_rc_invalid_argument \em data_type is not \ref ta_object_invalid and is not of
 *                                  type [string](\ref string.h).
 * \retval ta_c_rc_invalid_argument \em data is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em data is not of type [string](\ref string.h).
 * \retval ta_c_rc_invalid_argument \em retain_card is \ref ta_c_b_undefined.
 * \retval ta_c_rc_invalid_argument \em response is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_loyalty_data(
	ta_object_t terminal,
	ta_e_loyalty_function_type_t function_type,
	ta_object_t data_type,
	ta_object_t data,
	ta_e_boolean_t retain_card,
	ta_object_t* response );
#endif

/**
 * \brief This function is used to query and configure loyalty information.
 * 
 * Asynchronous version of \ref ta_terminal_loyalty_data.
 * Callback function is \ref ta_cb_terminal_loyalty_data_completed.
 * 
 * \note This method is only available if guide dialog is enabled.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[in] function_type Defines what kind of loyalty mode will be used.
 * \param[in] data_type Specifies type of loyalty data. Mandatory for function_type
 *                      \ref ta_c_lft_init, \ref ta_c_lft_update and \ref ta_c_lft_deinit.
 *                      If not \ref ta_object_invalid has to be of type [string](\ref string.h).
 * \param[in] data Loyalty data. Object of type [string](\ref string.h).
 * \param[in] retain_card \ref ta_c_b_true to not eject card otherwise \ref ta_c_b_false.
 * 
 * \retval ta_c_rc_ok Request started successfully.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 * \retval ta_c_rc_invalid_argument \em function_type is not a valid value of
 *                                  [ta_e_loyalty_function_type_t](\ref loyalty_function_type.h).
 * \retval ta_c_rc_invalid_argument \em data_type is not \ref ta_object_invalid and is not of
 *                                  type [string](\ref string.h).
 * \retval ta_c_rc_invalid_argument \em data is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em data is not of type [string](\ref string.h).
 * \retval ta_c_rc_invalid_argument \em retain_card is \ref ta_c_b_undefined.
 */
extern ta_e_result_code_t ta_terminal_loyalty_data_async(
	ta_object_t terminal,
	ta_e_loyalty_function_type_t function_type,
	ta_object_t data_type,
	ta_object_t data,
	ta_e_boolean_t retain_card );


#ifndef DISABLE_SYNC_CALLS
/**
 * \brief This function is used to start a Checkout process at the POS to collect card
 *        and/or cardholder loyalty information before a transaction is started.
 * 
 * Therefore the Worldline QR code is displayed at the terminal. The timeout how long the QR
 * code shall be displayed on the terminal before returning to its Idle screen can be
 * defined in the Login request using the OptionType - QRCTimeout, see
 * SIXml Book C: Appendix for further information.
 * 
 * \note This method is only available if guide value added services is enabled.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * 
 * \retval ta_c_rc_ok Request finished successfully.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 */
extern ta_e_result_code_t ta_terminal_start_checkout(
	ta_object_t terminal );
#endif

/**
 * \brief This function is used to start a Checkout process at the POS to collect card
 *        and/or cardholder loyalty information before a transaction is started.
 * 
 * Therefore the Worldline QR code is displayed at the terminal. The timeout how long the QR
 * code shall be displayed on the terminal before returning to its Idle screen can be
 * defined in the Login request using the OptionType - QRCTimeout, see
 * SIXml Book C: Appendix for further information.
 * 
 * Asynchronous version of \ref ta_terminal_start_checkout.
 * Callback function is \ref ta_cb_terminal_start_checkout_completed.
 * 
 * \note This method is only available if guide dialog is enabled.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * 
 * \retval ta_c_rc_ok Request started successfully.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 */
extern ta_e_result_code_t ta_terminal_start_checkout_async(
	ta_object_t terminal );


#ifndef DISABLE_SYNC_CALLS
/**
 * \brief This function is used to finish a previously started checkout process with
 *        StartCheckout and to retrieve consumer loyalty data from the terminal that
 *        has been collected during this checkout process.
 * 
 * \note This method is only available if guide value added services is enabled.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[out] response Variable to write object of type [vas_checkout_information](\ref vas_checkout_information.h).
 * 
 * \retval ta_c_rc_ok Request finished successfully.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 * \retval ta_c_rc_invalid_argument \em response is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_finish_checkout(
	ta_object_t terminal,
	ta_object_t* response );
#endif

/**
 * \brief This function is used to finish a previously started checkout process with
 *        StartCheckout and to retrieve consumer loyalty data from the terminal that
 *        has been collected during this checkout process.
 * 
 * Asynchronous version of \ref ta_terminal_finish_checkout.
 * Callback function is \ref ta_cb_terminal_finish_checkout_completed.
 * 
 * \note This method is only available if guide dialog is enabled.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * 
 * \retval ta_c_rc_ok Request started successfully.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 */
extern ta_e_result_code_t ta_terminal_finish_checkout_async(
	ta_object_t terminal );


#ifndef DISABLE_SYNC_CALLS
/**
 * \brief This function is used to provide the terminal with a LoyaltyBasket if the
 *        corresponding loyalty scheme requires it.
 * 
 * \note This method is only available if guide value added services is enabled.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[in] basket Object of type [list](\ref list.h) to send. Object contains elements
 *                   of type [loyalty_item](\ref loyalty_item.h).
 * \param[out] response Variable to write object of type [list](\ref list.h). Object contains
 *                      elements of type [loyalty_item](\ref loyalty_item.h).
 * 
 * \retval ta_c_rc_ok Request finished successfully.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 * \retval ta_c_rc_invalid_argument \em basket is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em basket is not of type [list](\ref list.h).
 * \retval ta_c_rc_invalid_argument Element in \em basket is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument Element in \em basket is not of type [loyalty_item](\ref loyalty_item.h).
 * \retval ta_c_rc_invalid_argument \em response is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_provide_loyalty_basket(
	ta_object_t terminal,
	ta_object_t basket,
	ta_object_t* response );
#endif

/**
 * \brief This function is used to provide the terminal with a LoyaltyBasket if the
 *        corresponding loyalty scheme requires it.
 * 
 * Asynchronous version of \ref ta_terminal_provide_loyalty_basket.
 * Callback function is \ref ta_cb_terminal_provide_loyalty_basket_completed.
 * 
 * \note This method is only available if guide dialog is enabled.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[in] basket Object of type [list](\ref list.h) to send. Object contains elements
 *                   of type [loyalty_item](\ref loyalty_item.h).
 * 
 * \retval ta_c_rc_ok Request started successfully.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 */
extern ta_e_result_code_t ta_terminal_provide_loyalty_basket_async(
	ta_object_t terminal,
	ta_object_t basket );


#ifndef DISABLE_SYNC_CALLS
/**
 * \brief This function is used to provide the terminal with a LoyaltyBasket if the
 *        corresponding loyalty scheme requires it.
 * 
 * \note This method is only available if guide value added services is enabled.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[in] result Object of type [vas_result](\ref vas_result.h) to send.
 * \param[out] response Variable to write object of type [vas_result](\ref vas_result.h).
 * 
 * \retval ta_c_rc_ok Request finished successfully.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 * \retval ta_c_rc_invalid_argument \em result is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em result is not of type [vas_result](\ref vas_result.h).
 * \retval ta_c_rc_invalid_argument \em response is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_provide_vas_result(
	ta_object_t terminal,
	ta_object_t result,
	ta_object_t* response );
#endif

/**
 * \brief This function is used to provide the terminal with a LoyaltyBasket if the
 *        corresponding loyalty scheme requires it.
 * 
 * Asynchronous version of \ref ta_terminal_provide_vas_result.
 * Callback function is \ref ta_cb_terminal_provide_vas_result_completed.
 * 
 * \note This method is only available if guide dialog is enabled.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[in] result Object of type [vas_result](\ref vas_result.h) to send.
 * 
 * \retval ta_c_rc_ok Request started successfully.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 */
extern ta_e_result_code_t ta_terminal_provide_vas_result_async(
	ta_object_t terminal,
	ta_object_t result );


#ifndef DISABLE_SYNC_CALLS
/**
 * \brief Request Mobile Topup Issuer information.
 * 
 * \note This method is only available if guide value added services is enabled.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[out] response Variable to write object of type [list](\ref list.h) with entries
 *                      of type [mobile_topup_value](\ref mobile_topup_value.h).
 * 
 * \retval ta_c_rc_ok Request finished successfully.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 * \retval ta_c_rc_invalid_argument \em response is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_mobile_topup_issuer_info(
	ta_object_t terminal,
	ta_object_t* response );
#endif

/**
 * \brief Request Mobile Topup Issuer information.
 * 
 * Asynchronous version of \ref ta_terminal_mobile_topup_issuer_info.
 * Callback function is \ref ta_cb_terminal_mobile_topup_issuer_info_completed.
 * 
 * \note This method is only available if guide dialog is enabled.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * 
 * \retval ta_c_rc_ok Request started successfully.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 */
extern ta_e_result_code_t ta_terminal_mobile_topup_issuer_info_async(
	ta_object_t terminal );


#ifndef DISABLE_SYNC_CALLS
/**
 * \brief Mobile Topup transaction. Supported transaction type are PURCHASE and REVERSAL.
 * 
 * To use REVERSAL terminal has to be configured to support credit transactions.
 * 
 * \note This method is only available if guide value added services is enabled.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[in] type Transaction type.
 * \param[in] issuer_name Object of type [string](\ref string.h).
 * \param[in] amount Object of type [amount](\ref amount.h).
 * \param[out] response Variable to write object of type [mobile_topup_data](\ref mobile_topup_data.h).
 * 
 * \retval ta_c_rc_ok Request finished successfully.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 * \retval ta_c_rc_invalid_argument \em result is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em result is not of type [mobile_topup_data](\ref mobile_topup_data.h).
 * \retval ta_c_rc_invalid_argument \em response is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_mobile_topup(
	ta_object_t terminal,
	ta_e_mobile_topup_type_t type,
	ta_object_t issuer_name,
	ta_object_t amount,
	ta_object_t* response );

/**
 * \brief Mobile Topup transaction. Supported transaction type are PURCHASE and REVERSAL.
 * 
 * To use REVERSAL terminal has to be configured to support credit transactions.
 * 
 * \note This method is only available if guide value added services is enabled.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[in] type Transaction type.
 * \param[in] value Object of type [mobile_topup_value](\ref mobile_topup_value.h).
 * \param[out] response Variable to write object of type [mobile_topup_data](\ref mobile_topup_data.h).
 * 
 * \retval ta_c_rc_ok Request finished successfully.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 * \retval ta_c_rc_invalid_argument \em result is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em result is not of type [mobile_topup_data](\ref mobile_topup_data.h).
 * \retval ta_c_rc_invalid_argument \em response is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_mobile_topup2(
	ta_object_t terminal,
	ta_e_mobile_topup_type_t type,
	ta_object_t value,
	ta_object_t* response );
#endif

/**
 * \brief Mobile Topup transaction. Supported transaction type are PURCHASE and REVERSAL.
 * 
 * To use REVERSAL terminal has to be configured to support credit transactions.
 * 
 * Asynchronous version of \ref ta_terminal_mobile_topup.
 * Callback function is \ref ta_cb_terminal_mobile_topup_completed.
 * 
 * \note This method is only available if guide dialog is enabled.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[in] type Transaction type.
 * \param[in] issuer_name Object of type [string](\ref string.h).
 * \param[in] amount Object of type [amount](\ref amount.h).
 * 
 * \retval ta_c_rc_ok Request started successfully.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 */
extern ta_e_result_code_t ta_terminal_mobile_topup_async(
	ta_object_t terminal,
	ta_e_mobile_topup_type_t type,
	ta_object_t issuer_name,
	ta_object_t amount );

/**
 * \brief Mobile Topup transaction. Supported transaction type are PURCHASE and REVERSAL.
 * 
 * To use REVERSAL terminal has to be configured to support credit transactions.
 * 
 * Asynchronous version of \ref ta_terminal_mobile_topup.
 * Callback function is \ref ta_cb_terminal_mobile_topup_completed.
 * 
 * \note This method is only available if guide dialog is enabled.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[in] type Transaction type.
 * \param[in] value Object of type [mobile_topup_value](\ref mobile_topup_value.h).
 * 
 * \retval ta_c_rc_ok Request started successfully.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 */
extern ta_e_result_code_t ta_terminal_mobile_topup2_async(
	ta_object_t terminal,
	ta_e_mobile_topup_type_t type,
	ta_object_t value );


#ifndef DISABLE_SYNC_CALLS
/**
 * \brief Open dialog mode on the terminal.
 * 
 * \note This method is only available if guide dialog is enabled.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * 
 * \retval ta_c_rc_ok Request finished successfully.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 */
extern ta_e_result_code_t ta_terminal_open_dialog_mode(
	ta_object_t terminal );

/**
 * \brief Open dialog mode on the terminal.
 * 
 * \note This method is only available if guide dialog is enabled.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[in] silent After opening the Dialog Mode the last screen content is retained until
 *                   the the first ShowDialog is received
 * 
 * \retval ta_c_rc_ok Request finished successfully.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 */
extern ta_e_result_code_t ta_terminal_open_dialog_mode2(
	ta_object_t terminal, ta_e_boolean_t silent );
#endif

/**
 * \brief Open dialog mode on the terminal.
 * 
 * Asynchronous version of \ref ta_terminal_open_dialog_mode.
 * Callback function is \ref ta_cb_terminal_open_dialog_mode_completed.
 * 
 * \note This method is only available if guide dialog is enabled.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * 
 * \retval ta_c_rc_ok Request started successfully.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 */
extern ta_e_result_code_t ta_terminal_open_dialog_mode_async(
	ta_object_t terminal );

/**
 * \brief Open dialog mode on the terminal.
 * 
 * Asynchronous version of \ref ta_terminal_open_dialog_mode.
 * Callback function is \ref ta_cb_terminal_open_dialog_mode_completed.
 * 
 * \note This method is only available if guide dialog is enabled.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[in] silent After opening the Dialog Mode the last screen content is retained until
 *                   the the first ShowDialog is received
 * 
 * \retval ta_c_rc_ok Request started successfully.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 */
extern ta_e_result_code_t ta_terminal_open_dialog_mode2_async(
	ta_object_t terminal, ta_e_boolean_t silent );

#ifndef DISABLE_SYNC_CALLS
/**
 * \brief Close dialog mode on the terminal.
 * 
 * \note This method is only available if guide dialog is enabled.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * 
 * \retval ta_c_rc_ok Request finished successfully.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 */
extern ta_e_result_code_t ta_terminal_close_dialog_mode(
	ta_object_t terminal );
#endif

/**
 * \brief Close dialog mode on the terminal.
 * 
 * Asynchronous version of \ref ta_terminal_close_dialog_mode.
 * Callback function is \ref ta_cb_terminal_close_dialog_mode_completed.
 * 
 * \note This method is only available if guide dialog is enabled.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * 
 * \retval ta_c_rc_ok Request started successfully.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 */
extern ta_e_result_code_t ta_terminal_close_dialog_mode_async(
	ta_object_t terminal );

#ifndef DISABLE_SYNC_CALLS
/**
 * \brief Show signature capture on the terminal.
 * 
 * Can be called only if dialog mode is open.
 * 
 * \note This method is only available if guide dialog is enabled.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[in] request Object instance of type [show_signature_capture_request](\ref show_signature_capture_request.h).
 * \param[out] response Pointer to variable to write object instance to. Object instance is
 *                      of type [show_signature_capture_response](\ref show_signature_capture_response.h). Object instance is retained.
 * 
 * \retval ta_c_rc_ok Request finished successfully. Object instance written to \em response.
 *                    Object instance has been retained.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 * \retval ta_c_rc_invalid_argument \em request is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em request is not of type [show_signature_capture_request](\ref show_signature_capture_request.h).
 * \retval ta_c_rc_invalid_argument \em response is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_show_signature_capture(
	ta_object_t terminal,
	ta_object_t request,
	ta_object_t* response );
#endif

/**
 * \brief Request system information from the EFT Terminal.
 * 
 * Asynchronous version of \ref ta_terminal_show_signature_capture.
 * Callback function is \ref ta_cb_terminal_show_signature_capture_completed.
 * 
 * \note This method is only available if guide dialog is enabled.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[in] request Object instance of type [show_signature_capture_request](\ref show_signature_capture_request.h).
 * 
 * \retval ta_c_rc_ok Request started successfully.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 * \retval ta_c_rc_invalid_argument \em request is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em request is not of type [show_signature_capture_request](\ref show_signature_capture_request.h).
 */
extern ta_e_result_code_t ta_terminal_show_signature_capture_async(
	ta_object_t terminal,
	ta_object_t request );

#ifndef DISABLE_SYNC_CALLS
/**
 * \brief Show dialog on the terminal.
 * 
 * Can be called only if dialog mode is open.
 * 
 * \note This method is only available if guide dialog is enabled.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[in] request Object instance of type [show_dialog_request](\ref show_dialog_request.h).
 * \param[out] response Pointer to variable to write object instance to. Object instance is
 *                      of type [show_dialog_response](\ref show_dialog_response.h). Object instance is retained.
 * 
 * \retval ta_c_rc_ok Request finished successfully. Object instance written to \em response.
 *                    Object instance has been retained.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 * \retval ta_c_rc_invalid_argument \em request is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em request is not of type [show_dialog_request](\ref show_dialog_request.h).
 * \retval ta_c_rc_invalid_argument \em response is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_show_dialog(
	ta_object_t terminal,
	ta_object_t request,
	ta_object_t* response );
#endif

/**
 * \brief Show dialog on the terminal.
 * 
 * Asynchronous version of \ref ta_terminal_show_dialog.
 * Callback function is \ref ta_cb_terminal_show_dialog_completed.
 * 
 * \note This method is only available if guide dialog is enabled.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[in] request Object instance of type [show_dialog_request](\ref show_dialog_request.h).
 * 
 * \retval ta_c_rc_ok Request started successfully.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 * \retval ta_c_rc_invalid_argument \em request is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em request is not of type [show_dialog_request](\ref show_dialog_request.h).
 */
extern ta_e_result_code_t ta_terminal_show_dialog_async(
	ta_object_t terminal,
	ta_object_t request );

#ifndef DISABLE_SYNC_CALLS
/**
 * \brief The <em>PrintOnTerminal</em>-function is used to send a freetext preformatted ticket from ECR to terminal.
 * 
 * The ticket is then printed on the terminal printer. The ticket must be formatted according [B39].
 * 
 * \note This method is only available if guide dialog is enabled.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[in] ticket_data Object instance of type [string](\ref string.h).
 * 
 * \retval ta_c_rc_ok Request finished successfully. Object instance written to \em response.
 *                    Object instance has been retained.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 * \retval ta_c_rc_invalid_argument \em ticket_data is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em ticket_data is not of type [string](\ref string.h).
 */
extern ta_e_result_code_t ta_terminal_print_on_terminal(
	ta_object_t terminal,
	ta_object_t ticket_data );
#endif

/**
 * \brief The <em>PrintOnTerminal</em>-function is used to send a freetext preformatted ticket from ECR to terminal.
 * 
 * The ticket is then printed on the terminal printer. The ticket must be formatted according [B39].
 * 
 * Asynchronous version of \ref ta_terminal_print_on_terminal.
 * Callback function is \ref ta_cb_terminal_print_on_terminal_completed.
 * 
 * \note This method is only available if guide dialog is enabled.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[in] ticket_data Object instance of type [string](\ref string.h).
 * 
 * \retval ta_c_rc_ok Request started successfully.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 * \retval ta_c_rc_invalid_argument \em ticket_data is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em ticket_data is not of type [string](\ref string.h).
 */
extern ta_e_result_code_t ta_terminal_print_on_terminal_async(
	ta_object_t terminal,
	ta_object_t ticket_data );

#ifndef DISABLE_SYNC_CALLS
/**
 * \brief Send card command.
 * 
 * This function is used for a direct communication with the inserted card using APDUs.
 * It is possible to send a list of APDU command in the request
 * (\em sixml:CommandRequestList) and to set responses that shall be accepted as
 * "Positive" responses using \em sixml:PositiveAnswerList
 * 
 * Each \em sixml:CommandRequest is numbered with a unique order number
 * (starting with 1). In the response, the terminal sends the response of the device for
 * each \em CommandRequest, including the order number of the request.
 * 
 * If the device answers with a negative response (i.e. SW1SW2 != 9000 or other as
 * "positive" defined answers using \em sixml:PositiveAnswerList), the processing of
 * the \em sixml:CommandRequests is aborted, and the remaining commands are not sent
 * to the device.
 * 
 * Furthermore it can be defined which dialogs shall be shown using the container
 * sixml:CommandResources in the following use cases:
 * 
 * <ul>
 * <li>Dialog shown as preparation before sending an APDU command: sixml:PreResource</li>
 * <li>Dialog shown during APDU command execution: sixml:ExecutionResource</li>
 * <li>Dialog shown after receiving a positive response: sixml:PositiveResource</li>
 * <li>Dialog shown after receiving a negative response: sixml:NegativeResource</li>
 * </ul>
 * 
 * \note This method is only available if guide dialog is enabled.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[in] requests Object instance of type [list](\ref list.h). Elements in the list have to be of
 *                    type \em command_request.
 * \param[out] responses Pointer to variable to write object instance to. Object instance is
 *                      of type [list](\ref list.h). Object instance is retained. Elements in the list
 *                      are of type [command_response](\ref command_response.h).
 * 
 * \retval ta_c_rc_ok Request finished successfully. Object instance written to \em response.
 *                    Object instance has been retained.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 * \retval ta_c_rc_invalid_argument \em requests is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em requests is not of type [list](\ref list.h).
 * \retval ta_c_rc_invalid_argument Element in \em requests is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument Element in \em requests is not of type [command_request](\ref command_request.h).
 * \retval ta_c_rc_invalid_argument \em responses is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_send_card_command(
	ta_object_t terminal,
	ta_object_t requests,
	ta_object_t* responses );
#endif

/**
 * \brief Send card command.
 * 
 * Asynchronous version of \ref ta_terminal_send_card_command.
 * Callback function is \ref ta_cb_terminal_send_card_command_completed.
 * 
 * \note This method is only available if guide dialog is enabled.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[in] requests Object instance of type [list](\ref list.h). Elements in the list have to be of
 *                    type \em command_request.
 * 
 * \retval ta_c_rc_ok Request finished successfully. Object instance written to \em response.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 * \retval ta_c_rc_invalid_argument Element in \em requests is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument Element in \em requests is not of type [command_request](\ref command_request.h).
 */
extern ta_e_result_code_t ta_terminal_send_card_command_async(
	ta_object_t terminal,
	ta_object_t requests );


#ifndef DISABLE_SYNC_CALLS
/**
 * \brief Get information about the current account balance of the inserted card.
 * 
 * \note This method is only available if guide advanced_retail is enabled.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[out] response Pointer to variable to write object instance to. Object instance is
 *                      of type [balance_inquiry_response](\ref balance_inquiry_response.h). Object instance is retained.
 * 
 * \retval ta_c_rc_ok Request finished successfully. Object instance written to \em response.
 *                    Object instance has been retained.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 * \retval ta_c_rc_invalid_argument \em response is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_balance_inquiry(
	ta_object_t terminal,
	ta_object_t* response );
#endif

/**
 * \brief Get information about the current account balance of the inserted card.
 * 
 * Asynchronous version of \ref ta_terminal_balance_inquiry.
 * Callback function is \ref ta_cb_terminal_balance_inquiry_completed.
 * 
 * \note This method is only available if guide advanced_retail is enabled.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * 
 * \retval ta_c_rc_ok Request started successfully.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 */
extern ta_e_result_code_t ta_terminal_balance_inquiry_async(
	ta_object_t terminal );


#ifndef DISABLE_SYNC_CALLS
/**
 * \brief The RequestAlias-function is used to request a Saferpay Alias for
 *        Alias-based transactions.
 * 
 * Saferpay offers these kind of transactions which can be performed only using a secure
 * Alias that can be created out of card information from a precious transaction. This
 * Alias then can be used to perform a transaction without having the same card present.
 * 
 * An Alias can be used for the following transactions:
 * - Purchase
 * - Credit
 * - Reservation
 * - Recurring
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[in] six_trans_ref Object instance of type [string](\ref string.h).
 * \param[out] response Pointer to variable to write object instance to. Object instance is
 *                      of type [string](\ref string.h). Object instance is retained.
 * 
 * \retval ta_c_rc_ok Request finished successfully. Object instance written to \em response.
 *                    Object instance has been retained.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 * \retval ta_c_rc_invalid_argument \em six_trans_ref is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em six_trans_ref is not of type [string](\ref string.h).
 * \retval ta_c_rc_invalid_argument \em response is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_request_alias(
	ta_object_t terminal,
	ta_object_t six_trans_ref,
	ta_object_t* response );
#endif

/**
 * \brief The RequestAlias-function is used to request a Saferpay Alias for
 *        Alias-based transactions.
 * 
 * Saferpay offers these kind of transactions which can be performed only using a secure
 * Alias that can be created out of card information from a precious transaction. This
 * Alias then can be used to perform a transaction without having the same card present.
 * 
 * An Alias can be used for the following transactions:
 * - Purchase
 * - Credit
 * - Reservation
 * - Recurring
 * 
 * Asynchronous version of \ref ta_terminal_request_alias.
 * Callback function is \ref ta_cb_terminal_request_alias_completed.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[in] six_trans_ref Object instance of type [string](\ref string.h).
 * 
 * \retval ta_c_rc_ok Request started successfully.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 * \retval ta_c_rc_invalid_argument \em six_trans_ref is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em six_trans_ref is not of type [string](\ref string.h).
 */
extern ta_e_result_code_t ta_terminal_request_alias_async(
	ta_object_t terminal,
	ta_object_t six_trans_ref );



#ifndef DISABLE_SYNC_CALLS
/**
 * \brief Perform device maintenance.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[in] type Type of maintenance to perform.
 * 
 * \retval ta_c_rc_ok Request finished successfully.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 */
extern ta_e_result_code_t ta_terminal_device_maintenance(
	ta_object_t terminal,
	ta_e_maintenance_type_t type );
#endif

/**
 * \brief Perform device maintenance.
 * 
 * Asynchronous version of \ref ta_terminal_device_maintenance.
 * Callback function is \ref ta_cb_terminal_device_maintenance_completed.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[in] type Type of maintenance to perform.
 * 
 * \retval ta_c_rc_ok Request started successfully.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 */
extern ta_e_result_code_t ta_terminal_device_maintenance_async(
	ta_object_t terminal,
	ta_e_maintenance_type_t type );



/**
 * \brief Send notification to request EFT make a screenshot.
 * 
 * This is a "best effort" function.
 * 
 * \note This method is only available if guide remote is enabled.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * 
 * \retval ta_c_rc_ok Hold commit send to terminal.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 */
extern ta_e_result_code_t ta_terminal_screenshot(
	ta_object_t terminal );



/**
 * \brief Send third_party_app_data to request EFT make a screenshot.
 * 
 * This is a "best effort" function.
 * 
 * \note This method is only available if guide value_added_services is enabled.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[in] payload Object instance of type [third_party_app_payload](\ref third_party_app_payload.h).
 * 
 * \retval ta_c_rc_ok third_party_app_data send to terminal.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 * \retval ta_c_rc_invalid_argument \em terminal is \em ta_object_invalid or not of type
 *                                  [third_party_app_payload](\ref third_party_app_payload.h).
 */
extern ta_e_result_code_t ta_terminal_third_party_app_data(
	ta_object_t terminal,
	ta_object_t data );



/**
 * \brief Change the cardholder language for the duration of the current process / open request. 
 *
 * The language is set back to standard after the current request returns. Following 
 * interactions need to set the language again. For the main use case in focus, InitTransaction,
 * this means that the language of the InitTransaction idle screen is changed until the
 * InitTransaction finished event occurs. The last screen set by the process is not changed back
 * to the default language.
 * 
 * This is a "best effort" function.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[in] language Object instance of type [string](\ref string.h).
 * 
 * \retval ta_c_rc_ok Hold commit send to terminal.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 * \retval ta_c_rc_invalid_argument \em language is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em language is not of type [string](\ref string.h).
 */
extern ta_e_result_code_t ta_terminal_change_language_for_request(
	ta_object_t terminal,
	ta_object_t language );


#ifndef DISABLE_SYNC_CALLS
/**
 * \brief This function is used to start an age check on the terminal.
 * 
 * \note This method is only available if guide value added services is enabled.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[in] age_to_check Object of type [integer](\ref integer.h) with the age to check.
 * \param[out] response Variable to write object of type
 *                      [transaction information](\ref transaction_information.h).
 *                      Object is retained.
 * 
 * \retval ta_c_rc_ok Request finished successfully.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 * \retval ta_c_rc_invalid_argument \em age_to_check is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em age_to_check is not of type [transaction information](\ref transaction_information.h).
 * \retval ta_c_rc_invalid_argument \em response is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_age_check(
	ta_object_t terminal,
	ta_object_t age_to_check,
	ta_object_t* response );
#endif

/**
 * \brief This function is used to start an age check on the terminal.
 * 
 * Asynchronous version of \ref ta_terminal_age_check.
 * Callback function is \ref ta_cb_terminal_age_check_completed.
 * 
 * \note This method is only available if guide dialog is enabled.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[in] age_to_check Object of type [integer](\ref integer.h) with the age to check.
 * 
 * \retval ta_c_rc_ok Request started successfully.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 * \retval ta_c_rc_invalid_argument \em age_to_check is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em age_to_check is not of type [transaction information](\ref transaction_information.h).
 */
extern ta_e_result_code_t ta_terminal_age_check_async(
	ta_object_t terminal,
	ta_object_t age_to_check );



/**
 * \brief Returns true if at least one payment protocol and the terminal configuration
 *        offer DCC i.e. if there is a chance to do a DCC transaction.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[out] result Pointer to variable to write result to.
 * 
 * \retval ta_c_rc_ok Result written to \em result.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 * \retval ta_c_rc_invalid_argument \em result is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_can_dcc(
	ta_object_t terminal,
	ta_e_boolean_t* result );

/**
 * \brief Support for "Declined Receipts" in at least one payment protocol.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[out] result Pointer to variable to write result to.
 * 
 * \retval ta_c_rc_ok Result written to \em result.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 * \retval ta_c_rc_invalid_argument \em result is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_can_declined_receipts(
	ta_object_t terminal,
	ta_e_boolean_t* result );

/**
 * \brief Support for multiple account selection.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[out] result Pointer to variable to write result to.
 * 
 * \retval ta_c_rc_ok Result written to \em result.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 * \retval ta_c_rc_invalid_argument \em result is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_can_multi_account_selection(
	ta_object_t terminal,
	ta_e_boolean_t* result );

/**
 * \brief Software update is available.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[out] result Pointer to variable to write result to.
 * 
 * \retval ta_c_rc_ok Result written to \em result.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 * \retval ta_c_rc_invalid_argument \em result is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_has_sw_update(
	ta_object_t terminal,
	ta_e_boolean_t* result );



/**
 * \brief Convert item text code to AdditionalInfoItem value.
 * \param[out] result Pointer to variable to write result to.
 * 
 * \retval ta_c_rc_ok Result written to \em result.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 * \retval ta_c_rc_invalid_argument \em result is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_get_item_textcode(
	ta_object_t terminal,
	int item_text_code,
	ta_e_additional_info_item_t* result );

/**
 * \brief Get text description of AdditionalInfoItem.
 * \param[out] result Pointer to variable to write result to.
 * 
 * \retval ta_c_rc_ok Result written to \em result.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 * \retval ta_c_rc_invalid_argument \em result is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_get_item_textcode_description(
	ta_object_t terminal,
	ta_e_additional_info_item_t item,
	const char** result );



/**
 * \brief This function tries to convert a SIXTransRef of type X:Y:4 into A SIXTransRef of type X:Y:1 .
 * 
 * For all other SIXTransRef values the value will be returned unchanged.
 * 
 * \param[in] six_trans_ref SIX Transaction Reference to convert.
 * \param[out] result Pointer to variable to write result to. Result is of type [string](\ref string.h).
 * 
 * \retval ta_c_rc_ok Result written to \em result.
 * \retval ta_c_rc_invalid_argument \em six_trans_ref is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em result is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_convert_six_trans_ref_to_legacy(
	ta_object_t six_trans_ref,
	ta_object_t* result );



/**
 * \brief Register listener.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[in] listener Object instance of type [terminal_listener](\ref terminal_listener.h).
 * 
 * \retval ta_c_rc_ok Listener added to \em terminal.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 * \retval ta_c_rc_invalid_argument \em listener is \ref ta_object_invalid.
 */
extern ta_e_result_code_t ta_terminal_add_listener(
	ta_object_t terminal,
	ta_object_t listener );

/**
 * \brief Unregister listener.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[in] listener Object instance of type [terminal_listener](\ref terminal_listener.h).
 * 
 * \retval ta_c_rc_ok Listener removed from \em terminal.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 * \retval ta_c_rc_invalid_argument \em terminal has been disposed.
 * \retval ta_c_rc_invalid_argument \em listener is \ref ta_object_invalid.
 */
extern ta_e_result_code_t ta_terminal_remove_listener(
	ta_object_t terminal,
	ta_object_t listener );



/**
 * \brief Set custom terminal logger callback.
 * 
 * If not null-pointer the callback is used whenever the terminal logger needs to publish a
 * new log record. The terminal logger is used whenever a terminal function is called, hence
 * any function of ta_terminal_*. In all other cases the global logger is used. You can use
 * the same logger for both global and terminal specific logging. If no custom terminal
 * logger is set the global one is used if set.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h).
 * \param[in] callback Callback to set. Can be \em null-pointer to disable.
 * \param[in] user_pointer User pointer to use in the callback.
 * 
 * \retval ta_c_rc_ok Listener removed from \em terminal.
 * \retval ta_c_rc_invalid_argument \em terminal is \ref ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal is not of type [terminal](\ref terminal.h).
 */
extern ta_e_result_code_t ta_terminal_set_custom_logger(
	ta_object_t terminal,
	ta_cb_publish_log_record callback,
	void *user_pointer );


#ifdef __cplusplus
}
#endif

#endif
