/**
 * \file
 * \brief Terminal listener.
 * \details Object type \em terminal_listener.
 */

#ifndef TA_TERMINAL_LISTENER_H
#define TA_TERMINAL_LISTENER_H

#include "common/object.h"
#include "constants/result_code.h"
#include "constants/request_type.h"
#include "constants/update_status.h"


#ifdef __cplusplus
extern "C" {
#endif



/**
 * \brief Contains event information for asynchronous method calls.
 */
typedef struct ta_s_event {
	/**
	 * \brief Terminal instance sending event.
	 * 
	 * Object instance of type [terminal](\ref terminal.h). Object instance is not retained.
	 */
	ta_object_t terminal;
	
	/**
	 * \brief Result code.
	 */
	ta_e_result_code_t result_code;
	
	/**
	 * \brief Type of request this event has been send for.
	 */
	ta_e_request_type_t request_type;
	
	/**
	 * \brief Additional error information present if send by terminal.
	 * 
	 * Is \em ta_object_invalid if not set. Otherwise object instance is of type
	 * [tim_error](\ref tim_error.h). Object instance is not retained.
	 */
	ta_object_t error;
} ta_s_event_t;



/**
 * \brief Called if a ta_terminal_connect started request finished.
 * 
 * \param[in] event Pointer to struct containing information about the event.
 * \param[in] user_pointer User pointer value used while creating the listener.
 */
typedef void ( *ta_cb_terminal_connect_completed )(
	const ta_s_event_t *event,
	void *user_pointer );

/**
 * \brief Called if an ta_terminal_activate_async started request finished.
 * 
 * \param[in] event Pointer to struct containing information about the event.
 * \param[in] data Object instance of type [activate_response](\ref activate_response.h). Object instance is
 *                 \em ta_object_invalid if request failed. Object instance is not retained.
 * \param[in] user_pointer User pointer value used while creating the listener.
 */
typedef void ( *ta_cb_terminal_activate_completed )(
	const ta_s_event_t *event,
	ta_object_t data,
	void *user_pointer );

/**
 * \brief Called if an ta_terminal_application_information_async started request finished.
 * 
 * \param[in] event Pointer to struct containing information about the event.
 * \param[in] user_pointer User pointer value used while creating the listener.
 */
typedef void ( *ta_cb_terminal_application_information_completed )(
	const ta_s_event_t *event,
	void *user_pointer );

/**
 * \brief Called if an ta_terminal_balance_async started request finished.
 * 
 * \param[in] event Pointer to struct containing information about the event.
 * \param[in] data Object instance of type [balance_response](\ref balance_response.h). Object instance is
 *                 \em ta_object_invalid if request failed. Object instance is not retained.
 * \param[in] user_pointer User pointer value used while creating the listener.
 */
typedef void ( *ta_cb_terminal_balance_completed )(
	const ta_s_event_t *event,
	ta_object_t data,
	void *user_pointer );

/**
 * \brief Called if an ta_terminal_change_settings_async started request finished.
 * 
 * \param[in] event Pointer to struct containing information about the event.
 * \param[in] user_pointer User pointer value used while creating the listener.
 */
typedef void ( *ta_cb_terminal_change_settings_completed )(
	const ta_s_event_t *event,
	void *user_pointer );

/**
 * \brief Called if an ta_terminal_commit_async started request finished.
 * 
 * \param[in] event Pointer to struct containing information about the event.
 * \param[in] data Object instance of type [print_data](\ref print_data.h). Object instance is
 *                 \em ta_object_invalid if request failed or NoPrint mode has been used
 *                 during login. Object instance is not retained.
 * \param[in] user_pointer User pointer value used while creating the listener.
 */
typedef void ( *ta_cb_terminal_commit_completed )(
	const ta_s_event_t *event,
	ta_object_t data,
	void *user_pointer );

/**
 * \brief Called if an ta_terminal_counter_request_async started request finished.
 * 
 * \param[in] event Pointer to struct containing information about the event.
 * \param[in] data Object instance of type [counters](\ref counters.h). Object instance is
 *                 \em ta_object_invalid if request failed. Object instance is not retained.
 * \param[in] user_pointer User pointer value used while creating the listener.
 */
typedef void ( *ta_cb_terminal_counter_request_completed )(
	const ta_s_event_t *event,
	ta_object_t data,
	void *user_pointer );

/**
 * \brief Called if an ta_terminal_deactivate_async started request finished.
 * 
 * \param[in] event Pointer to struct containing information about the event.
 * \param[in] data Object instance of type [deactivate_response](\ref deactivate_response.h). Object instance is
 *                 \em ta_object_invalid if request failed. Object instance is not retained.
 * \param[in] user_pointer User pointer value used while creating the listener.
 */
typedef void ( *ta_cb_terminal_deactivate_completed )(
	const ta_s_event_t *event,
	ta_object_t data,
	void *user_pointer );

/**
 * \brief Called if an ta_terminal_dcc_rates_async started request finished.
 * 
 * \param[in] event Pointer to struct containing information about the event.
 * \param[in] data Object instance of type [print_data](\ref print_data.h). Object instance is
 *                 \em ta_object_invalid if request failed. Object instance is not retained.
 * \param[in] user_pointer User pointer value used while creating the listener.
 */
typedef void ( *ta_cb_terminal_dcc_rates_completed )(
	const ta_s_event_t *event,
	ta_object_t data,
	void *user_pointer );

/**
 * \brief Called if an ta_terminal_hardware_information_async started request finished.
 * 
 * \param[in] event Pointer to struct containing information about the event.
 * \param[in] data Object instance of type [hardware_information_response](\ref hardware_information_response.h). Object
 *                 instance can be \em ta_object_invalid if request failed.
 *                 Object instance is not retained.
 * \param[in] user_pointer User pointer value used while creating the listener.
 */
typedef void ( *ta_cb_terminal_hardware_information_completed )(
	const ta_s_event_t *event,
	ta_object_t data,
	void *user_pointer );

/**
 * \brief Called if an ta_terminal_init_transaction_async started request finished.
 * 
 * \param[in] event Pointer to struct containing information about the event.
 * \param[in] data Object instance of type [card_data](\ref card_data.h). Object instance is
 *                 \em ta_object_invalid if request failed or finished request
 *                 does not contain card data. Object instance is not retained.
 * \param[in] user_pointer User pointer value used while creating the listener.
 */
typedef void ( *ta_cb_terminal_init_transaction_completed )(
	const ta_s_event_t *event,
	ta_object_t data,
	void *user_pointer );

/**
 * \brief Called if an ta_terminal_init_transaction_with_dialog_async started request finished.
 * 
 * \param[in] event Pointer to struct containing information about the event.
 * \param[in] data Object instance of type [init_transaction_response](\ref init_transaction_response.h).
 *                 Object instance is \em ta_object_invalid if request failed or finished request
 *                 does not contain response data. Object instance is not retained.
 * \param[in] user_pointer User pointer value used while creating the listener.
 */
typedef void ( *ta_cb_terminal_init_transaction_with_dialog_completed )(
	const ta_s_event_t *event,
	ta_object_t data,
	void *user_pointer );

/**
 * \brief Called if an ta_terminal_client_identification_async started request finished.
 * 
 * \param[in] event Pointer to struct containing information about the event.
 * \param[in] data Object instance of type [client_identification_response](\ref client_identification_response.h).
 *                 Object instance is \em ta_object_invalid if request failed or finished
 *                 request does not contain client identification data. Object instance is
 *                 not retained.
 * \param[in] user_pointer User pointer value used while creating the listener.
 */
typedef void ( *ta_cb_terminal_client_identification_completed )(
	const ta_s_event_t *event,
	ta_object_t data,
	void *user_pointer );

/**
 * \brief Called if an ta_terminal_login_async started request finished.
 * 
 * \param[in] event Pointer to struct containing information about the event.
 * \param[in] user_pointer User pointer value used while creating the listener.
 */
typedef void ( *ta_cb_terminal_login_completed )(
	const ta_s_event_t *event,
	void *user_pointer );

/**
 * \brief Called if an ta_terminal_logout_async started request finished.
 * 
 * \param[in] event Pointer to struct containing information about the event.
 * \param[in] user_pointer User pointer value used while creating the listener.
 */
typedef void ( *ta_cb_terminal_logout_completed )(
	const ta_s_event_t *event,
	void *user_pointer );

/**
 * \brief Called if an ta_terminal_reboot_async started request finished.
 * 
 * \param[in] event Pointer to struct containing information about the event.
 * \param[in] user_pointer User pointer value used while creating the listener.
 */
typedef void ( *ta_cb_terminal_reboot_completed )(
	const ta_s_event_t *event,
	void *user_pointer );

/**
 * \brief Called if an ta_terminal_reconciliation_async started request finished.
 * 
 * \param[in] event Pointer to struct containing information about the event.
 * \param[in] data Object instance of type [reconciliation_response](\ref reconciliation_response.h). Object instance is
 *                 \em ta_object_invalid if request failed. Object instance is not retained.
 * \param[in] user_pointer User pointer value used while creating the listener.
 */
typedef void ( *ta_cb_terminal_reconciliation_completed )(
	const ta_s_event_t *event,
	ta_object_t data,
	void *user_pointer );

/**
 * \brief Called if an ta_terminal_receipt_request_async started request finished.
 * 
 * \param[in] event Pointer to struct containing information about the event.
 * \param[in] data Object instance of type [receipt_request_response](\ref receipt_request_response.h). Object instance is
 *                 \em ta_object_invalid if request failed. Object instance is not retained.
 * \param[in] user_pointer User pointer value used while creating the listener.
 */
typedef void ( *ta_cb_terminal_receipt_request_completed )(
	const ta_s_event_t *event,
	ta_object_t data,
	void *user_pointer );

/**
 * \brief Called if an ta_terminal_transaction_info_request_async started request finished.
 * 
 * \param[in] event Pointer to struct containing information about the event.
 * \param[in] data Object instance of type [transaction_info_request_response](\ref transaction_info_request_response.h). Object instance is
 *                 \em ta_object_invalid if request failed. Object instance is not retained.
 * \param[in] user_pointer User pointer value used while creating the listener.
 */
typedef void ( *ta_cb_terminal_transaction_info_request_completed )(
	const ta_s_event_t *event,
	ta_object_t data,
	void *user_pointer );

/**
 * \brief Called if an ta_terminal_reconfig_async started request finished.
 * 
 * \param[in] event Pointer to struct containing information about the event.
 * \param[in] data Object instance of type [print_data](\ref print_data.h). Object instance is
 *                 \em ta_object_invalid if request failed or finished request does
 *                 not contain print data. Object instance is not retained.
 * \param[in] user_pointer User pointer value used while creating the listener.
 */
typedef void ( *ta_cb_terminal_reconfig_completed )(
	const ta_s_event_t *event,
	ta_object_t data,
	void *user_pointer );

/**
 * \brief Called if an ta_terminal_rollback_async started request finished.
 * 
 * \param[in] event Pointer to struct containing information about the event.
 * \param[in] data Object instance of type [print_data](\ref print_data.h). Object instance is
 *                 \em ta_object_invalid if request failed or finished request does
 *                 not contain print data. Object instance is not retained.
 * \param[in] user_pointer User pointer value used while creating the listener.
 */
typedef void ( *ta_cb_terminal_rollback_completed )(
	const ta_s_event_t *event,
	ta_object_t data,
	void *user_pointer );

/**
 * \brief Called if an ta_terminal_software_update_async started request finished.
 * 
 * \param[in] event Pointer to struct containing information about the event.
 * \param[in] data Object instance of type [integer](\ref integer.h). Object instance is
 *                 \em ta_object_invalid if request failed. Object instance is
 *                 not retained. Value of integer matches \em ta_e_update_status_t.
 * \param[in] user_pointer User pointer value used while creating the listener.
 */
typedef void ( *ta_cb_terminal_software_update_completed )(
	const ta_s_event_t *event,
	ta_object_t data,
	void *user_pointer );

/**
 * \brief Called if an ta_terminal_system_information_async started request finished.
 * 
 * \param[in] event Pointer to struct containing information about the event.
 * \param[in] data Object instance of type [system_information_response](\ref system_information_response.h).
 *                 Object instance is \em ta_object_invalid if request failed.
 *                 Object instance is not retained.
 * \param[in] user_pointer User pointer value used while creating the listener.
 */
typedef void ( *ta_cb_terminal_system_information_completed )(
	const ta_s_event_t *event,
	ta_object_t data,
	void *user_pointer );

/**
 * \brief Called if an ta_terminal_transaction_async started request finished.
 * 
 * \param[in] event Pointer to struct containing information about the event.
 * \param[in] data Object instance of type [transaction_response](\ref transaction_response.h). Object instance is
 *                 \em ta_object_invalid if request failed. Object instance is not retained.
 * \param[in] user_pointer User pointer value used while creating the listener.
 */
typedef void ( *ta_cb_terminal_transaction_completed )(
	const ta_s_event_t *event,
	ta_object_t data,
	void *user_pointer );

/**
 * \brief Called if the state of the terminal changed.
 * 
 * Retrieve the state using ta_terminal_get_terminal_state.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h). Object instance is not retained.
 * \param[in] user_pointer User pointer value used while creating the listener.
 */
typedef void ( *ta_cb_terminal_terminal_status_changed )(
	ta_object_t terminal,
	void *user_pointer );

/**
 * \brief Connection to terminal closed.
 * 
 * Called if user disconnected or connection has been lost.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h). Object instance is not retained.
 * \param[in] result_code Result code.
 * \param[in] user_pointer User pointer value used while creating the listener.
 */
typedef void ( *ta_cb_terminal_disconnected )(
	ta_object_t terminal,
	ta_e_result_code_t result_code,
	void *user_pointer );

/**
 * \brief Called if VAS information has been received from the terminal.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h). Object instance is not retained.
 * \param[in] vas_info Object instance of type [vas_checkout_information](\ref vas_checkout_information.h).
 *                     Object instance is not retained.
 * \param[in] user_pointer User pointer value used while creating the listener.
 */
typedef void ( *ta_cb_terminal_vas_info )(
	ta_object_t terminal,
	ta_object_t vas_checkout_information,
	void *user_pointer );

/**
 * \brief Called if deferred authorization has been received from the terminal.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h). Object instance is not retained.
 * \param[in] response Object instance of type [transaction_response](\ref transaction_response.h).
 *                     Object instance is not retained.
 * \param[in] user_pointer User pointer value used while creating the listener.
 */
typedef void ( *ta_cb_terminal_deferred_auth )(
	ta_object_t terminal,
	ta_object_t response,
	void *user_pointer );

/**
 * \brief Called if key pressed has been received from the terminal.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h). Object instance is not retained.
 * \param[in] response Object instance of type [integer](\ref integer.h) containing pressed
 *                     key from enumeration \ref ta_e_reason_t. Object instance is not retained.
 * \param[in] user_pointer User pointer value used while creating the listener.
 */
typedef void ( *ta_cb_terminal_key_pressed )(
	ta_object_t terminal,
	ta_object_t reason,
	void *user_pointer );

/**
 * \brief Called if license changed notification has been received from the terminal.
 * 
 * \deprecated Functionality removed.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h). Object instance is not retained.
 * \param[in] user_pointer User pointer value used while creating the listener.
 */
typedef void ( *ta_cb_terminal_license_changed )(
	ta_object_t terminal,
	void *user_pointer );

/**
 * \brief Called if screenshot has been received from the terminal.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h). Object instance is not retained.
 * \param[in] info Object instance of type [screenshot_information](\ref screenshot_information.h).
 *                 Object instance is not retained.
 * \param[in] user_pointer User pointer value used while creating the listener.
 */
typedef void ( *ta_cb_terminal_screenshot )(
	ta_object_t terminal,
	ta_object_t info,
	void *user_pointer );

/**
 * \brief Called if third_party_app_data has been received from the terminal.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h). Object instance is not retained.
 * \param[in] data Object instance of type [third_party_app_payload](\ref third_party_app_payload.h).
 *                 Object instance is not retained.
 * \param[in] user_pointer User pointer value used while creating the listener.
 */
typedef void ( *ta_cb_terminal_third_party_app_data )(
	ta_object_t terminal,
	ta_object_t data,
	void *user_pointer );

/**
 * \brief Called if error notification has been received from the terminal.
 * 
 * \param[in] terminal Object instance of type [terminal](\ref terminal.h). Object instance is not retained.
 * \param[in] response Object instance of type [tim_error](\ref tim_error.h).
 *                     Object instance is not retained.
 * \param[in] user_pointer User pointer value used while creating the listener.
 */
typedef void ( *ta_cb_terminal_error_notification )(
	ta_object_t terminal,
	ta_object_t tim_error,
	void *user_pointer );



/**
 * \brief Called if an ta_terminal_close_reader_async started request finished.
 * 
 * Supported only if guide unattended is enabled.
 * 
 * \param[in] event Pointer to struct containing information about the event.
 * \param[in] user_pointer User pointer value used while creating the listener.
 */
typedef void ( *ta_cb_terminal_close_reader_completed )(
	const ta_s_event_t *event,
	void *user_pointer );

/**
 * \brief Called if an ta_terminal_open_reader_async started request finished.
 * 
 * Supported only if guide unattended is enabled.
 * 
 * \param[in] event Pointer to struct containing information about the event.
 * \param[in] user_pointer User pointer value used while creating the listener.
 */
typedef void ( *ta_cb_terminal_open_reader_completed )(
	const ta_s_event_t *event,
	void *user_pointer );

/**
 * \brief Called if an ta_terminal_eject_card_async started request finished.
 * 
 * Supported only if guide unattended is enabled.
 * 
 * \param[in] event Pointer to struct containing information about the event.
 * \param[in] user_pointer User pointer value used while creating the listener.
 */
typedef void ( *ta_cb_terminal_eject_card_completed )(
	const ta_s_event_t *event,
	void *user_pointer );

/**
 * \brief Called if an ta_terminal_open_maintenance_window_async started request finished.
 * 
 * Supported only if guide unattended is enabled.
 * 
 * \param[in] event Pointer to struct containing information about the event.
 * \param[in] user_pointer User pointer value used while creating the listener.
 */
typedef void ( *ta_cb_terminal_open_maintenance_window_completed )(
	const ta_s_event_t *event,
	void *user_pointer );

/**
 * \brief Called if an ta_terminal_close_maintenance_window_async started request finished.
 * 
 * Supported only if guide unattended is enabled.
 * 
 * \param[in] event Pointer to struct containing information about the event.
 * \param[in] user_pointer User pointer value used while creating the listener.
 */
typedef void ( *ta_cb_terminal_close_maintenance_window_completed )(
	const ta_s_event_t *event,
	void *user_pointer );

/**
 * \brief Called if an ta_terminal_activate_service_menu_async started request finished.
 * 
 * Supported only if guide unattended is enabled.
 * 
 * \param[in] event Pointer to struct containing information about the event.
 * \param[in] user_pointer User pointer value used while creating the listener.
 */
typedef void ( *ta_cb_terminal_activate_service_menu_completed )(
	const ta_s_event_t *event,
	void *user_pointer );



/**
 * \brief Called if an ta_terminal_open_dialog_mode_async started request finished.
 * 
 * Supported only if guide dialog is enabled.
 * 
 * \param[in] event Pointer to struct containing information about the event.
 * \param[in] user_pointer User pointer value used while creating the listener.
 */
typedef void ( *ta_cb_terminal_open_dialog_mode_completed )(
	const ta_s_event_t *event,
	void *user_pointer );

/**
 * \brief Called if an ta_terminal_close_dialog_mode_async started request finished.
 * 
 * Supported only if guide dialog is enabled.
 * 
 * \param[in] event Pointer to struct containing information about the event.
 * \param[in] user_pointer User pointer value used while creating the listener.
 */
typedef void ( *ta_cb_terminal_close_dialog_mode_completed )(
	const ta_s_event_t *event,
	void *user_pointer );

/**
 * \brief Called if an ta_terminal_show_signature_capture_async started request finished.
 * 
 * Supported only if guide dialog is enabled.
 * 
 * \param[in] event Pointer to struct containing information about the event.
 * \param[in] data Object instance of type [show_signature_capture_response](\ref show_signature_capture_response.h).
 *                 Object instance is \em ta_object_invalid if request failed.
 *                 Object instance is not retained.
 * \param[in] user_pointer User pointer value used while creating the listener.
 */
typedef void ( *ta_cb_terminal_show_signature_capture_completed )(
	const ta_s_event_t *event,
	ta_object_t data,
	void *user_pointer );

/**
 * \brief Called if an ta_terminal_show_dialog_async started request finished.
 * 
 * Supported only if guide dialog is enabled.
 * 
 * \param[in] event Pointer to struct containing information about the event.
 * \param[in] data Object instance of type [show_dialog_response](\ref show_dialog_response.h). Object instance is
 *                 \em ta_object_invalid if request failed. Object instance is not retained.
 * \param[in] user_pointer User pointer value used while creating the listener.
 */
typedef void ( *ta_cb_terminal_show_dialog_completed )(
	const ta_s_event_t *event,
	ta_object_t data,
	void *user_pointer );

/**
 * \brief Called if an ta_terminal_send_card_command_async started request finished.
 * 
 * Supported only if guide dialog is enabled.
 * 
 * \param[in] event Pointer to struct containing information about the event.
 * \param[in] data Object instance of type [list](\ref list.h). Object instance is
 *                 \em ta_object_invalid if request failed. Object instance is not
 *                 retained. Elements in list are of type [command_response](\ref command_response.h).
 * \param[in] user_pointer User pointer value used while creating the listener.
 */
typedef void ( *ta_cb_terminal_send_card_command_completed )(
	const ta_s_event_t *event,
	ta_object_t data,
	void *user_pointer );

/**
 * \brief Called if an ta_terminal_print_on_terminal_async started request finished.
 * 
 * Supported only if guide dialog is enabled.
 * 
 * \param[in] event Pointer to struct containing information about the event.
 * \param[in] user_pointer User pointer value used while creating the listener.
 */
typedef void ( *ta_cb_terminal_print_on_terminal_completed )(
	const ta_s_event_t *event,
	void *user_pointer );



/**
 * \brief Called if an ta_terminal_balance_inquiry_async started request finished.
 * 
 * Supported only if guide advanced retail is enabled.
 * 
 * \param[in] event Pointer to struct containing information about the event.
 * \param[in] data Object instance of type [balance_inquiry_response](\ref balance_inquiry_response.h). Object instance is
 *                 \em ta_object_invalid if request failed. Object instance is not retained.
 * \param[in] user_pointer User pointer value used while creating the listener.
 */
typedef void ( *ta_cb_terminal_balance_inquiry_completed )(
	const ta_s_event_t *event,
	ta_object_t data,
	void *user_pointer );



/**
 * \brief Called if an ta_terminal_loyalty_data_async started request finished.
 * 
 * Supported only if guide value added services is enabled.
 * 
 * \param[in] event Pointer to struct containing information about the event.
 * \param[in] data Object instance of type [card_data](\ref card_data.h). Object instance is
 *                 \em ta_object_invalid if request failed. Object instance is not retained.
 * \param[in] user_pointer User pointer value used while creating the listener.
 */
typedef void ( *ta_cb_terminal_loyalty_data_completed )(
	const ta_s_event_t *event,
	ta_object_t data,
	void *user_pointer );

/**
 * \brief Called if an ta_terminal_start_checkout_async started request finished.
 * 
 * Supported only if guide value added services is enabled.
 * 
 * \param[in] event Pointer to struct containing information about the event.
 * \param[in] user_pointer User pointer value used while creating the listener.
 */
typedef void ( *ta_cb_terminal_start_checkout_completed )(
	const ta_s_event_t *event,
	void *user_pointer );

/**
 * \brief Called if an ta_terminal_finish_checkout_async started request finished.
 * 
 * Supported only if guide value added services is enabled.
 * 
 * \param[in] event Pointer to struct containing information about the event.
 * \param[in] data Object instance of type [vas_checkout_information](\ref vas_checkout_information.h).
 *                 Object instance is \em ta_object_invalid if request failed. Object instance is not retained.
 * \param[in] user_pointer User pointer value used while creating the listener.
 */
typedef void ( *ta_cb_terminal_finish_checkout_completed )(
	const ta_s_event_t *event,
	ta_object_t data,
	void *user_pointer );

/**
 * \brief Called if an ta_terminal_provide_loyalty_basket_async started request finished.
 * 
 * Supported only if guide value added services is enabled.
 * 
 * \param[in] event Pointer to struct containing information about the event.
 * \param[in] data Object instance of type [list](\ref list.h) with list elements of type
 *                 [loyalty_item](\ref loyalty_item.h). List object instance is
 *                 \em ta_object_invalid if request failed. Object instance is not retained.
 * \param[in] user_pointer User pointer value used while creating the listener.
 */
typedef void ( *ta_cb_terminal_provide_loyalty_basket_completed )(
	const ta_s_event_t *event,
	ta_object_t data,
	void *user_pointer );

/**
 * \brief Called if an ta_terminal_provide_vas_result_async started request finished.
 * 
 * Supported only if guide value added services is enabled.
 * 
 * \param[in] event Pointer to struct containing information about the event.
 * \param[in] data Object instance of type [list](\ref list.h) with list elements of type
 *                 [loyalty_item](\ref loyalty_item.h). List object instance is
 *                 \em ta_object_invalid if request failed. Object instance is not retained.
 * \param[in] user_pointer User pointer value used while creating the listener.
 */
typedef void ( *ta_cb_terminal_provide_vas_result_completed )(
	const ta_s_event_t *event,
	ta_object_t data,
	void *user_pointer );

/**
 * \brief Called if an ta_terminal_mobile_topup_issuer_info_async started request finished.
 * 
 * Supported only if guide value added services is enabled.
 * 
 * \param[in] event Pointer to struct containing information about the event.
 * \param[in] data Object instance of type [list](\ref list.h) with list elements of type
 *                 [mobile_topup_value](\ref mobile_topup_value.h). List object instance is
 *                 \em ta_object_invalid if request failed. Object instance is not retained.
 * \param[in] user_pointer User pointer value used while creating the listener.
 */
typedef void ( *ta_cb_terminal_mobile_topup_issuer_info_completed )(
	const ta_s_event_t *event,
	ta_object_t data,
	void *user_pointer );

/**
 * \brief Called if an ta_terminal_mobile_topup_async started request finished.
 * 
 * Supported only if guide value added services is enabled.
 * 
 * \param[in] event Pointer to struct containing information about the event.
 * \param[in] data Object instance of type [mobile_topup_data](\ref mobile_topup_data.h).
 *                 Object instance is \em ta_object_invalid if request failed.
 *                 Object instance is not retained.
 * \param[in] user_pointer User pointer value used while creating the listener.
 */
typedef void ( *ta_cb_terminal_mobile_topup_completed )(
	const ta_s_event_t *event,
	ta_object_t data,
	void *user_pointer );



/**
 * \brief Called if an ta_terminal_request_alias_async started request finished.
 * 
 * \param[in] event Pointer to struct containing information about the event.
 * \param[in] data Object instance of type [string](\ref string.h). Object instance is
 *                 \em ta_object_invalid if request failed. Object instance is not retained.
 * \param[in] user_pointer User pointer value used while creating the listener.
 */
typedef void ( *ta_cb_terminal_request_alias_completed )(
	const ta_s_event_t *event,
	ta_object_t data,
	void *user_pointer );



/**
 * \brief Called if an ta_terminal_device_maintenance_async started request finished.
 * 
 * \param[in] event Pointer to struct containing information about the event.
 * \param[in] user_pointer User pointer value used while creating the listener.
 */
typedef void ( *ta_cb_terminal_device_maintenance_completed )(
	const ta_s_event_t *event,
	void *user_pointer );

/**
 * \brief Called if an ta_terminal_age_check_async started request finished.
 * 
 * Supported only if guide value added services is enabled.
 * 
 * \param[in] event Pointer to struct containing information about the event.
 * \param[in] data Object instance of type [transaction_information](\ref transaction_information.h).
 *                 Object instance is not retained.
 * \param[in] user_pointer User pointer value used while creating the listener.
 */
typedef void ( *ta_cb_terminal_age_check_completed )(
	const ta_s_event_t *event,
	ta_object_t data,
	void *user_pointer );



/**
 * \brief Called for all completed requests.
 * 
 * Convience function to get notified about any kind of request having completed.
 * 
 * \param[in] event Pointer to struct containing information about the event.
 * \param[in] data Object instance with additional data. Object instance is
 *                 \em ta_object_invalid if request failed or finished request does
 *                 not contain additional data. Object instance is not retained.
 * \param[in] user_pointer User pointer value used while creating the listener.
 */
typedef void ( *ta_cb_terminal_request_completed )(
	const ta_s_event_t *event,
	ta_object_t data,
	void *user_pointer );

/**
 * \brief Called for all requests containing print data.
 * 
 * Convenience method to print all receipts send by the terminal. Contains
 * final receipts to print. If the print data sent to the request completed
 * functions contains fields only ta_terminaL_get_receipt_formatter() is
 * used to create final receipts for printing.
 * 
 * The following request completed methods contain receipts send to this method:
 * <ul>
 * <li>ta_cb_terminal_activate_completed</li>
 * <li>ta_cb_terminal_balance_completed</li>
 * <li>ta_cb_terminal_deactivate_completed</li>
 * <li>ta_cb_terminal_dcc_rates_completed</li>
 * <li>ta_cb_terminal_receipt_request_completed</li>
 * <li>ta_cb_terminal_reconciliation_completed</li>
 * <li>ta_cb_terminal_reconfig_completed</li>
 * <li>ta_cb_terminal_rollback_completed</li>
 * <li>ta_cb_terminal_transaction_completed</li>
 * </ul>
 * 
 * ta_cb_terminal_print_receipts is called before ta_cb_terminal_request_completed.
 * 
 * \param[in] event Pointer to struct containing information about the event.
 * \param[in] data Object instance of type [print_data](\ref print_data.h). Object instance is not retained.
 * \param[in] user_pointer User pointer value used while creating the listener.
 */
typedef void ( *ta_cb_terminal_print_receipts )(
	const ta_s_event_t *event,
	ta_object_t data,
	void *user_pointer );



/**
 * \brief Listener for asynchronous terminal events.
 * 
 * Use memset to clear struct to 0. Then set the callbacks you want to use.
 * Callbacks set to 0 are ignored.
 * 
 * This struct is only used to initialize the listener during a call to
 * ta_terminal_listener_create. Afterwards the callbacks can not be changed
 * anymore as long as the listener is alive.
 */
typedef struct ta_s_terminal_listener{
	/** \brief Connect completed. */
	ta_cb_terminal_connect_completed connect_completed;
	
	/** \brief Activate completed. */
	ta_cb_terminal_activate_completed activate_completed;
	
	/** \brief Application information completed. */
	ta_cb_terminal_application_information_completed application_information_completed;
	
	/** \brief Balance completed. */
	ta_cb_terminal_balance_completed balance_completed;
	
	/** \brief Change settings completed. */
	ta_cb_terminal_change_settings_completed change_settings_completed;
	
	/** \brief Commit completed. */
	ta_cb_terminal_commit_completed commit_completed;
	
	/** \brief Counter request completed. */
	ta_cb_terminal_counter_request_completed counter_request_completed;
	
	/** \brief Deactivate completed. */
	ta_cb_terminal_deactivate_completed deactivate_completed;
	
	/** \brief DCC rates completed. */
	ta_cb_terminal_dcc_rates_completed dcc_rates_completed;
	
	/** \brief Hardware information completed. */
	ta_cb_terminal_hardware_information_completed hardware_information_completed;
	
	/** \brief Init transaction completed. */
	ta_cb_terminal_init_transaction_completed init_transaction_completed;
	
	/** \brief Init transaction with dialog completed. */
	ta_cb_terminal_init_transaction_with_dialog_completed init_transaction_with_dialog_completed;
	
	/** \brief Client identification completed. */
	ta_cb_terminal_client_identification_completed client_identification_completed;
	
	/** \brief Login completed. */
	ta_cb_terminal_login_completed login_completed;
	
	/** \brief Logout completed. */
	ta_cb_terminal_logout_completed logout_completed;
	
	/** \brief Reboot completed. */
	ta_cb_terminal_reboot_completed reboot_completed;
	
	/** \brief Reconciliation completed. */
	ta_cb_terminal_reconciliation_completed reconciliation_completed;
	
	/** \brief Receipt request completed. */
	ta_cb_terminal_receipt_request_completed receipt_request_completed;
	
	/** \brief Transaction info request completed. */
	ta_cb_terminal_transaction_info_request_completed transaction_info_request_completed;
	
	/** \brief Reconfig completed. */
	ta_cb_terminal_reconfig_completed reconfig_completed;
	
	/** \brief Rollback completed. */
	ta_cb_terminal_rollback_completed rollback_completed;
	
	/** \brief Software information completed. */
	ta_cb_terminal_software_update_completed software_update_completed;
	
	/** \brief System information completed. */
	ta_cb_terminal_system_information_completed system_information_completed;
	
	/** \brief Transaction completed. */
	ta_cb_terminal_transaction_completed transaction_completed;
	
	/** \brief Terminal status changed. */
	ta_cb_terminal_terminal_status_changed terminal_status_changed;
	
	/** \brief Terminal disconnected. */
	ta_cb_terminal_disconnected disconnected;
	
	/** \brief VAS information received. */
	ta_cb_terminal_vas_info vas_info;
	
	/** \brief Deferred auth received. */
	ta_cb_terminal_deferred_auth deferred_auth;
	
	/** \brief Key pressed received. */
	ta_cb_terminal_key_pressed key_pressed;
	
	/**
	 * \brief License changed notification received.
	 * 
	 * \deprecated Functionality removed.
	 */
	ta_cb_terminal_license_changed license_changed;
	
	/** \brief Screenshot received. */
	ta_cb_terminal_screenshot screenshot;
	
	/** \brief third_party_app_data received. */
	ta_cb_terminal_third_party_app_data third_party_app_data;
	
	/** \brief Error notification received. */
	ta_cb_terminal_error_notification error_notification;
	
	/** \brief Close reader completed. */
	ta_cb_terminal_close_reader_completed close_reader_completed;
	
	/** \brief Open reader completed. */
	ta_cb_terminal_open_reader_completed open_reader_completed;
	
	/** \brief Eject card completed. */
	ta_cb_terminal_eject_card_completed eject_card_completed;
	
	/** \brief Open maintenance window completed. */
	ta_cb_terminal_open_maintenance_window_completed open_maintenance_window_completed;
	
	/** \brief Close maintenance window completed. */
	ta_cb_terminal_close_maintenance_window_completed close_maintenance_window_completed;
	
	/** \brief Activate service menu completed. */
	ta_cb_terminal_activate_service_menu_completed activate_service_menu_completed;
	
	/** \brief Open dialog mode completed. */
	ta_cb_terminal_open_dialog_mode_completed open_dialog_mode_completed;
	
	/** \brief Close dialog mode completed. */
	ta_cb_terminal_close_dialog_mode_completed close_dialog_mode_completed;
	
	/** \brief Show signature capture completed. */
	ta_cb_terminal_show_signature_capture_completed show_signature_capture_completed;
	
	/** \brief Show dialog completed. */
	ta_cb_terminal_show_dialog_completed show_dialog_completed;
	
	/** \brief Show dialog completed. */
	ta_cb_terminal_print_on_terminal_completed print_on_terminal_completed;
	
	/** \brief Send card command completed. */
	ta_cb_terminal_send_card_command_completed send_card_command_completed;
	
	/** \brief Balance inquiry completed. */
	ta_cb_terminal_balance_inquiry_completed balance_inquiry_completed;
	
	/** \brief Loyalty data completed. */
	ta_cb_terminal_loyalty_data_completed loyalty_data_completed;
	
	/** \brief Start checkout completed. */
	ta_cb_terminal_start_checkout_completed start_checkout_completed;
	
	/** \brief Finish checkout completed. */
	ta_cb_terminal_finish_checkout_completed finish_checkout_completed;
	
	/** \brief Provide loyalty basket completed. */
	ta_cb_terminal_provide_loyalty_basket_completed provide_loyalty_basket_completed;
	
	/** \brief Provide vas result completed. */
	ta_cb_terminal_provide_vas_result_completed provide_vas_result_completed;
	
	/** \brief Mobile topup issuer info completed. */
	ta_cb_terminal_mobile_topup_issuer_info_completed mobile_topup_issuer_info_completed;
	
	/** \brief Mobile topup completed. */
	ta_cb_terminal_mobile_topup_completed mobile_topup_completed;
	
	/** \brief Request alias completed. */
	ta_cb_terminal_request_alias_completed request_alias_completed;
	
	/** \brief Device maintenance completed. */
	ta_cb_terminal_device_maintenance_completed device_maintenance_completed;
	
	/** \brief Age check completed. */
	ta_cb_terminal_age_check_completed age_check_completed;
	
	
	/** \brief Called all completed requests. */
	ta_cb_terminal_request_completed request_completed;
	
	/** \brief Called by default callbacks for all requests containing print data. */
	ta_cb_terminal_print_receipts print_receipts;
	
	
	/** \brief User pointer. */
	void *user_pointer;
} ta_s_terminal_listener_t;



/**
 * \brief Create terminal listener.
 * 
 * Caller retains a reference to the created instance. While adding to a terminal
 * instance the terminal instance retains the reference. The user can release the
 * reference directly afterwards. In this case the listener is destroyed once no
 * terminal instance requires the listener anymore. The user has to retain the
 * reference to be able to remove the listener from a terminal instance. This
 * allows the listener to be used across different terminal instances.
 * 
 * \param[out] listener Pointer to variable to write created object instance to.
 *                      Created object instance is retained.
 * \param[in] configuration Pointer to struct containinig listener configuration.
 * 
 * \retval ta_c_rc_ok Object instance has been created and written to \em listener.
 * \retval ta_c_rc_invalid_argument \em listener is \em null-pointer.
 * \retval ta_c_rc_invalid_argument \em configuration is \em null-pointer.
 * \retval ta_c_rc_out_of_memory Failed allocating memory.
 */
extern ta_e_result_code_t ta_terminal_listener_create(
	ta_object_t *listener,
	const ta_s_terminal_listener_t * configuration );



/**
 * \brief Process print receipts.
 * 
 * Use this method inside \em print_receipts in \em ta_s_terminal_listener_t if you
 * use receipt items. This uses the [receipt_formatter](\ref receipt_formatter.h)
 * set in the terminal instance to format the receipts. Without this method only receipt
 * items will be returned and no receipts.
 * 
 * \param[in] terminal Terminal object provided by print_receipts callback.
 * \param[in] data Print data object provided by print_receipts callback.
 *                 If \em ta_object_invalid no processing is done. Otherwise receipt
 *                 items are processed and placed in \em data.
 * \deprecated PrintData receipts are formatted by TIM API before send to the listeners.
 *             Returns print data unmodified.
 */
extern ta_e_result_code_t ta_process_print_receipts(
	ta_object_t terminal,
	ta_object_t data );


#ifdef __cplusplus
}
#endif

#endif
