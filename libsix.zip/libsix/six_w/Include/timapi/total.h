/**
 * \file
 * \brief Contains information about the total for one currency.
 * \details Object type \em total.
 */

#ifndef TA_TOTAL_H
#define TA_TOTAL_H

#include "common/object.h"
#include "common/boolean.h"
#include "constants/currency.h"


#ifdef __cplusplus
extern "C" {
#endif


/**
 * \brief Number of transactions.
 * 
 * \param[in] total Object instance of type [total](\ref total.h).
 * \param[out] count Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Object instance written to \em count.
 * \retval ta_c_rc_invalid_argument \em total is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em total is not of type [total](\ref total.h).
 * \retval ta_c_rc_invalid_argument \em count is \em null-pointer.
 */
extern ta_e_result_code_t ta_total_get_count(
	ta_object_t total,
	int* count );

/**
 * \brief Total amount per currency.
 * 
 * \param[in] total Object instance of type [total](\ref total.h).
 * \param[out] amount_sum Pointer to variable to write object instance to. Object instance
 *                        is of type [amount](\ref amount.h) and is not retained.
 * 
 * \retval ta_c_rc_ok Object instance written to \em amount_sum.
 * \retval ta_c_rc_invalid_argument \em total is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em total is not of type [total](\ref total.h).
 * \retval ta_c_rc_invalid_argument \em amount_sum is \em null-pointer.
 */
extern ta_e_result_code_t ta_total_get_amount_sum(
	ta_object_t total,
	ta_object_t* amount_sum );

/**
 * \brief Total tip amount per currency.
 * 
 * \param[in] total Object instance of type [total](\ref total.h).
 * \param[out] amount_sum Pointer to variable to write object instance to. Object instance
 *                        is of type [amount](\ref amount.h) and is not retained.
 * 
 * \retval ta_c_rc_ok Object instance written to \em amount_sum.
 * \retval ta_c_rc_invalid_argument \em total is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em total is not of type [total](\ref total.h).
 * \retval ta_c_rc_invalid_argument \em amount_sum is \em null-pointer.
 */
extern ta_e_result_code_t ta_total_get_amount_sum_tip(
	ta_object_t total,
	ta_object_t* amount_sum );

/**
 * \brief Total other amount per currency.
 * 
 * \param[in] total Object instance of type [total](\ref total.h).
 * \param[out] amount_sum Pointer to variable to write object instance to. Object instance
 *                        is of type [amount](\ref amount.h) and is not retained.
 * 
 * \retval ta_c_rc_ok Object instance written to \em amount_sum.
 * \retval ta_c_rc_invalid_argument \em total is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em total is not of type [total](\ref total.h).
 * \retval ta_c_rc_invalid_argument \em amount_sum is \em null-pointer.
 */
extern ta_e_result_code_t ta_total_get_amount_sum_other(
	ta_object_t total,
	ta_object_t* amount_sum );

/**
 * \brief List of transaction details.
 * 
 * \param[in] total Object instance of type [total](\ref total.h).
 * \param[out] trx_details Pointer to variable to write object instance to. Object instance
 *                         is of type [list](\ref list.h) and is not retained. The list contains elements
 *                         of type [trx_detail](\ref trx_detail.h).
 * 
 * \retval ta_c_rc_ok Object instance written to \em trx_details.
 * \retval ta_c_rc_invalid_argument \em total is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em total is not of type [total](\ref total.h).
 * \retval ta_c_rc_invalid_argument \em trx_details is \em null-pointer.
 */
extern ta_e_result_code_t ta_total_get_trx_details(
	ta_object_t total,
	ta_object_t* trx_details );

/**
 * \brief Currency.
 * 
 * \param[in] total Object instance of type [total](\ref total.h).
 * \param[out] currency Pointer to variable to write currency to.
 * 
 * \retval ta_c_rc_ok Object instance written to \em currency.
 * \retval ta_c_rc_invalid_argument \em total is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em total is not of type [total](\ref total.h).
 * \retval ta_c_rc_invalid_argument \em currency is \em null-pointer.
 */
extern ta_e_result_code_t ta_total_get_currency(
	ta_object_t total,
	ta_e_currency_t* currency );

/**
 * \brief Exponent.
 * 
 * \param[in] total Object instance of type [total](\ref total.h).
 * \param[out] exponent Pointer to variable to write exponent to.
 * 
 * \retval ta_c_rc_ok Object instance written to \em currency.
 * \retval ta_c_rc_invalid_argument \em total is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em total is not of type [total](\ref total.h).
 * \retval ta_c_rc_invalid_argument \em exponent is \em null-pointer.
 */
extern ta_e_result_code_t ta_total_get_exponent(
	ta_object_t total,
	int* exponent );


#ifdef __cplusplus
}
#endif

#endif
