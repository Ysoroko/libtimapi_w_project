/**
 * \file
 * \brief Transaction info request Response.
 * \details Object type \em transaction_info_request_response.
 */

#ifndef TA_transaction_info_request_RESPONSE_H
#define TA_transaction_info_request_RESPONSE_H

#include "common/object.h"
#include "common/boolean.h"
#include "constants/result_code.h"
#include "constants/outcome.h"
#include "constants/transaction_type.h"


#ifdef __cplusplus
extern "C" {
#endif


/**
 * \brief Transaction type.
 * 
 * \param[in] response Object instance of type [transaction_info_request_response](\ref transaction_info_request_response.h).
 * \param[out] function Pointer to variable to write object instance to. Object instance is
 *                      of type [string](\ref string.h) and is not retained. Object instance is
 *                      \em ta_object_invalid if value is not set in \em response.
 * 
 * \retval ta_c_rc_ok Object instance written to \em function.
 * \retval ta_c_rc_invalid_argument \em response is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em response is not of type [transaction_info_request_response](\ref transaction_info_request_response.h).
 * \retval ta_c_rc_invalid_argument \em function is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_info_request_response_get_transaction_type(
	ta_object_t response,
	ta_e_transaction_type_t* transaction_type );


/**
 * \brief Outcome.
 * 
 * \param[in] response Object instance of type [transaction_info_request_response](\ref transaction_info_request_response.h).
 * \param[out] outcome Pointer to variable to write result code to. Variable is set to
 *                     \em ta_c_o_undefined if value is not set in \em response.
 * 
 * \retval ta_c_rc_ok Value written to \em outcome.
 * \retval ta_c_rc_invalid_argument \em response is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em response is not of type [transaction_info_request_response](\ref transaction_info_request_response.h).
 * \retval ta_c_rc_invalid_argument \em outcome is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_info_request_response_get_outcome(
	ta_object_t response,
	ta_e_outcome_t* outcome );


/**
 * \brief Transaction response.
 * 
 * \param[in] response Object instance of type [transaction_info_request_response](\ref transaction_info_request_response.h).
 * \param[out] transaction_response Pointer to variable to write object instance to. Object instance is
 *                                  of type [transaction_response](\ref transaction_response.h) and is not retained.
 *                                  Object instance is \em ta_object_invalid if value is not set in \em response.
 * 
 * \retval ta_c_rc_ok Object instance written to \em print_data.
 * \retval ta_c_rc_invalid_argument \em response is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em response is not of type [transaction_info_request_response](\ref transaction_info_request_response.h).
 * \retval ta_c_rc_invalid_argument \em transaction_response is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_info_request_response_get_transaction_response(
	ta_object_t response,
	ta_object_t* transaction_response );


/**
 * \brief Error.
 * 
 * \param[in] response Object instance of type [transaction_info_request_response](\ref transaction_info_request_response.h).
 * \param[out] error Pointer to variable to write object instance to. Object instance is
 *                   of type [tim_error](\ref tim_error.h) and is not retained.
 *                   Object instance is \em ta_object_invalid if value is not set in \em response.
 * 
 * \retval ta_c_rc_ok Object instance written to \em print_data.
 * \retval ta_c_rc_invalid_argument \em response is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em response is not of type [transaction_info_request_response](\ref transaction_info_request_response.h).
 * \retval ta_c_rc_invalid_argument \em error is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_info_request_response_get_error(
	ta_object_t response,
	ta_object_t* error );


/**
 * \brief Last status receipt.
 * 
 * \param[in] response Object instance of type [transaction_info_request_response](\ref transaction_info_request_response.h).
 * \param[out] last_status_receipt Pointer to variable to write object instance to. Object instance is
 *                                 of type [print_data](\ref print_data.h) and is not retained.
 *                                 Object instance is \em ta_object_invalid if value is not set in \em response.
 * 
 * \retval ta_c_rc_ok Object instance written to \em print_data.
 * \retval ta_c_rc_invalid_argument \em response is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em response is not of type [transaction_info_request_response](\ref transaction_info_request_response.h).
 * \retval ta_c_rc_invalid_argument \em last_status_receipt is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_info_request_response_get_last_status_receipt(
	ta_object_t response,
	ta_object_t* last_status_receipt );


#ifdef __cplusplus
}
#endif

#endif
