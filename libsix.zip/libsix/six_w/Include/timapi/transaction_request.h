/**
 * \file
 * \brief Transaction request.
 * \details Object type \em transaction_request.
 */

#ifndef TA_TRANSACTION_REQUEST_H
#define TA_TRANSACTION_REQUEST_H

#include "common/object.h"
#include "common/boolean.h"
#include "constants/transaction_type.h"


#ifdef __cplusplus
extern "C" {
#endif


/**
 * \brief Create object of type [transaction_request](\ref transaction_request.h).
 * 
 * \param[out] request Pointer to variable to write created object instance to.
 *                     Created object instance is retained.
 * 
 * \retval ta_c_rc_ok Object instance has been created and written to \em request.
 * \retval ta_c_rc_invalid_argument \em request is \em null-pointer.
 * \retval ta_c_rc_out_of_memory Failed allocating memory.
 */
extern ta_e_result_code_t ta_transaction_request_create(
	ta_object_t *request );

/**
 * \brief Create deep copy of object instance of type [transaction_request](\ref transaction_request.h).
 * 
 * \param[out] request Pointer to variable to write created object instance to.
 *                     Created object instance is retained.
 * \param[in] source_request Object of type [transaction_request](\ref transaction_request.h) to create copy of.
 * 
 * \retval ta_c_rc_ok Object instance has been created and written to \em request.
 * \retval ta_c_rc_invalid_argument \em request is \em null-pointer.
 * \retval ta_c_rc_invalid_argument \em source_request is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em source_request is not of type [transaction_request](\ref transaction_request.h).
 * \retval ta_c_rc_out_of_memory Failed allocating memory.
 */
extern ta_e_result_code_t ta_transaction_request_copy(
	ta_object_t* request,
	const ta_object_t* source_request );



/**
 * \brief ECR user identifier.
 * 
 * \param[in] request Object instance of type [transaction_request](\ref transaction_request.h).
 * \param[out] user_id Pointer to variable to write object instance to. Object
 *                     instance is of type [integer](\ref integer.h) and is not retained. Object
 *                     instance is \em ta_object_invalid if value is not set
 *                     in \em request.
 * 
 * \retval ta_c_rc_ok Object instance written to \em user_id.
 * \retval ta_c_rc_invalid_argument \em request is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em request is not of type [transaction_request](\ref transaction_request.h).
 * \retval ta_c_rc_invalid_argument \em user_id is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_request_get_user_id(
	ta_object_t request,
	ta_object_t* user_id );

/**
 * \brief Set ECR user identifier.
 * 
 * \param[in] request Object instance of type [transaction_request](\ref transaction_request.h).
 * \param[in] user_id Object instance to set. Object instance can be
 *                    \em ta_object_invalid to clear the value in \em request. If
 *                    object instance is not ta_object_invalid is has to be of
 *                    type \em integer.
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em request.
 * \retval ta_c_rc_invalid_argument \em request is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em request is not of type [transaction_request](\ref transaction_request.h).
 * \retval ta_c_rc_invalid_argument \em user_id is not \em ta_object_invalid and
 *                                  is not of type [integer](\ref integer.h).
 */
extern ta_e_result_code_t ta_transaction_request_set_user_id(
	ta_object_t request,
	ta_object_t user_id );



/**
 * \brief Transaction amount and currency.
 * 
 * \param[in] request Object instance of type [transaction_request](\ref transaction_request.h).
 * \param[out] amount Pointer to variable to write object instance to. Object
 *                    instance is of type [amount](\ref amount.h) and is not retained. Object
 *                    instance is \em ta_object_invalid if value is not set
 *                    in \em request.
 * 
 * \retval ta_c_rc_ok Object instance written to \em amount.
 * \retval ta_c_rc_invalid_argument \em request is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em request is not of type [transaction_request](\ref transaction_request.h).
 * \retval ta_c_rc_invalid_argument \em amount is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_request_get_amount(
	ta_object_t request,
	ta_object_t* amount );

/**
 * \brief Set transaction amount and currency.
 * 
 * \param[in] request Object instance of type [transaction_request](\ref transaction_request.h).
 * \param[in] amount Object instance to set. Object instance can be
 *                   \em ta_object_invalid to clear the value in \em request. If
 *                   object instance is not ta_object_invalid is has to be of
 *                   type \em amount.
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em request.
 * \retval ta_c_rc_invalid_argument \em request is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em request is not of type [transaction_request](\ref transaction_request.h).
 * \retval ta_c_rc_invalid_argument \em amount is not \em ta_object_invalid and
 *                                  is not of type [amount](\ref amount.h).
 */
extern ta_e_result_code_t ta_transaction_request_set_amount(
	ta_object_t request,
	ta_object_t amount );



/**
 * \brief Transaction information.
 * 
 * \param[in] request Object instance of type [transaction_request](\ref transaction_request.h).
 * \param[out] transaction_data Pointer to variable to write object instance to. Object
 *                              instance is of type [transaction_data](\ref transaction_data.h) and is not retained.
 *                              Object instance is \em ta_object_invalid if value is not set
 *                              in \em request.
 * 
 * \retval ta_c_rc_ok Object instance written to \em transaction_data.
 * \retval ta_c_rc_invalid_argument \em request is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em request is not of type [transaction_request](\ref transaction_request.h).
 * \retval ta_c_rc_invalid_argument \em transaction_data is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_request_get_transaction_data(
	ta_object_t request,
	ta_object_t* transaction_data );

/**
 * \brief Set transaction information.
 * 
 * \param[in] request Object instance of type [transaction_request](\ref transaction_request.h).
 * \param[in] transaction_data Object instance to set. Object instance can be
 *                             \em ta_object_invalid to clear the value in \em request. If
 *                             object instance is not ta_object_invalid is has to be of type
 *                             \em transaction_data.
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em request.
 * \retval ta_c_rc_invalid_argument \em request is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em request is not of type [transaction_request](\ref transaction_request.h).
 * \retval ta_c_rc_invalid_argument \em transaction_data is not \em ta_object_invalid and
 *                                  is not of type [transaction_data](\ref transaction_data.h).
 */
extern ta_e_result_code_t ta_transaction_request_set_transaction_data(
	ta_object_t request,
	ta_object_t transaction_data );



/**
 * \brief Additional merchant options.
 * 
 * \param[in] request Object instance of type [transaction_request](\ref transaction_request.h).
 * \param[out] merchant_options Pointer to variable to write object instance to. Object
 *                              instance is of type [list](\ref list.h) and is not retained. The list
 *                              contains elements of type [merchant_option](\ref merchant_option.h).
 * 
 * \retval ta_c_rc_ok Object instance written to \em merchant_options.
 * \retval ta_c_rc_invalid_argument \em request is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em request is not of type [transaction_request](\ref transaction_request.h).
 * \retval ta_c_rc_invalid_argument \em merchant_options is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_request_get_merchant_options(
	ta_object_t request,
	ta_object_t* merchant_options );

/**
 * \brief Set additional merchant options.
 * 
 * \param[in] request Object instance of type [transaction_request](\ref transaction_request.h).
 * \param[in] merchant_options Object instance to set. Object instance has to be of type [list](\ref list.h).
 *                             The list has to contain elements of type [merchant_option](\ref merchant_option.h).
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em request.
 * \retval ta_c_rc_invalid_argument \em request is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em request is not of type [transaction_request](\ref transaction_request.h).
 * \retval ta_c_rc_invalid_argument \em merchant_options is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em merchant_options is not of type [list](\ref list.h).
 * \retval ta_c_rc_invalid_argument Element in \em merchant_options is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument Element in \em merchant_options is not of type
 *                                  \em merchant_option.
 */
extern ta_e_result_code_t ta_transaction_request_set_merchant_options(
	ta_object_t request,
	ta_object_t merchant_options );



/**
 * \brief Customer data.
 * 
 * \param[in] request Object instance of type [transaction_request](\ref transaction_request.h).
 * \param[out] customer_data Pointer to variable to write object instance to. Object instance is
 *                           of type [map](\ref map.h) and is not retained. The map contains
 *                           elements of key type [integer](\ref integer.h) with values from
 *                           enumeration \ref ta_e_customer_data_type_t and value type
 *                           [string](\ref string.h).
 * 
 * \retval ta_c_rc_ok Object instance written to \em customer_data.
 * \retval ta_c_rc_invalid_argument \em request is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em request is not of type [transaction_request](\ref transaction_request.h).
 * \retval ta_c_rc_invalid_argument \em customer_data is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_request_get_customer_data(
	ta_object_t request,
	ta_object_t* customer_data );

/**
 * \brief Set customer data.
 * 
 * \param[in] request Object instance of type [transaction_request](\ref transaction_request.h).
 * \param[in] customer_data Object instance to set. Object instance has to be of type [map](\ref map.h).
 *                          The map has to contain elements of key type [integer](\ref integer.h)
 *                          with values from enumeration \ref ta_e_customer_data_type_t and key
 *                          type [string](\ref string.h).
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em request.
 * \retval ta_c_rc_invalid_argument \em request is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em request is not of type [transaction_request](\ref transaction_request.h).
 * \retval ta_c_rc_invalid_argument \em customer_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em customer_data is not of type [map](\ref map.h).
 * \retval ta_c_rc_invalid_argument Key in \em customer_data is not of type [integer](\ref integer.h)
 *                                  with with values from enumeration \ref ta_e_customer_data_type_t.
 * \retval ta_c_rc_invalid_argument Value in \em customer_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument Value in \em customer_data is not of type [string](\ref string.h).
 */
extern ta_e_result_code_t ta_transaction_request_set_customer_data(
	ta_object_t request,
	ta_object_t customer_data );



/**
 * \brief Additional information list.
 * 
 * \param[in] request Object instance of type [transaction_request](\ref transaction_request.h).
 * \param[out] additional_info Pointer to variable to write object instance to. Object
 *                             instance is of type [map](\ref map.h) and is not retained. The map
 *                             contains keys of type [integer](\ref integer.h) and values of type [string](\ref string.h).
 * 
 * \retval ta_c_rc_ok Object instance written to \em additional_info.
 * \retval ta_c_rc_invalid_argument \em request is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em request is not of type [transaction_request](\ref transaction_request.h).
 * \retval ta_c_rc_invalid_argument \em additional_info is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_request_get_additional_info(
	ta_object_t request,
	ta_object_t* additional_info );

/**
 * \brief Set additional information list.
 * 
 * \param[in] request Object instance of type [transaction_request](\ref transaction_request.h).
 * \param[in] additional_info Object instance to set. Object instance has to be of type [map](\ref map.h).
 *                            The map has to contain keys of type [integer](\ref integer.h) and values of type
 *                            \em string.
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em request.
 * \retval ta_c_rc_invalid_argument \em request is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em request is not of type [transaction_request](\ref transaction_request.h).
 * \retval ta_c_rc_invalid_argument \em additional_info is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em additional_info is not of type [map](\ref map.h).
 * \retval ta_c_rc_invalid_argument Key in \em additional_info is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument Key in \em additional_info is not of type [integer](\ref integer.h).
 * \retval ta_c_rc_invalid_argument Value in \em additional_info is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument Value in \em additional_info is not of type [string](\ref string.h).
 */
extern ta_e_result_code_t ta_transaction_request_set_additional_info(
	ta_object_t request,
	ta_object_t additional_info );



/**
 * \brief Petrol: Basket.
 * 
 * \param[in] request Object instance of type [transaction_request](\ref transaction_request.h).
 * \param[out] basket Pointer to variable to write object instance to. Object
 *                    instance is of type [basket](\ref basket.h) and is not retained. Object
 *                    instance is \em ta_object_invalid if value is not set
 *                    in \em request.
 * 
 * \retval ta_c_rc_ok Object instance written to \em basket.
 * \retval ta_c_rc_invalid_argument \em request is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em request is not of type [transaction_request](\ref transaction_request.h).
 * \retval ta_c_rc_invalid_argument \em basket is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_request_get_basket(
	ta_object_t request,
	ta_object_t* basket );

/**
 * \brief Set request (petrol).
 * 
 * \param[in] request Object instance of type [transaction_request](\ref transaction_request.h).
 * \param[in] basket Object instance to set. Object instance can be
 *                   \em ta_object_invalid to clear the value in \em request. If
 *                   object instance is not ta_object_invalid is has to be of
 *                   type \em basket.
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em request.
 * \retval ta_c_rc_invalid_argument \em request is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em request is not of type [transaction_request](\ref transaction_request.h).
 * \retval ta_c_rc_invalid_argument \em basket is not \em ta_object_invalid and
 *                                  is not of type [basket](\ref basket.h).
 */
extern ta_e_result_code_t ta_transaction_request_set_basket(
	ta_object_t request,
	ta_object_t basket );


/**
 * \brief Proposed tip amount.
 * 
 * \param[in] request Object instance of type [transaction_request](\ref transaction_request.h).
 * \param[out] amount_tip Pointer to variable to write object instance to. Object
 *                        instance is of type [amount](\ref amount.h) and is not retained. Object
 *                        instance is \em ta_object_invalid if value is not set
 *                        in \em request.
 * 
 * \retval ta_c_rc_ok Object instance written to \em amount_tip.
 * \retval ta_c_rc_invalid_argument \em request is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em request is not of type [transaction_request](\ref transaction_request.h).
 * \retval ta_c_rc_invalid_argument \em amount_tip is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_request_get_amount_tip(
	ta_object_t request,
	ta_object_t* amount_tip );

/**
 * \brief Set proposed tip amount.
 * 
 * \param[in] request Object instance of type [transaction_request](\ref transaction_request.h).
 * \param[in] amount_tip Object instance to set. Object instance can be
 *                       \em ta_object_invalid to clear the value in \em request. If
 *                       object instance is not ta_object_invalid is has to be of
 *                       type \em amount.
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em request.
 * \retval ta_c_rc_invalid_argument \em request is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em request is not of type [transaction_request](\ref transaction_request.h).
 * \retval ta_c_rc_invalid_argument \em amount_tip is not \em ta_object_invalid and
 *                                  is not of type [amount](\ref amount.h).
 */
extern ta_e_result_code_t ta_transaction_request_set_amount_tip(
	ta_object_t request,
	ta_object_t amount_tip );



/**
 * \brief Cashback amount and currency.
 * 
 * \param[in] request Object instance of type [transaction_request](\ref transaction_request.h).
 * \param[out] amount_other Pointer to variable to write object instance to. Object
 *                          instance is of type [amount](\ref amount.h) and is not retained. Object
 *                          instance is \em ta_object_invalid if value is not set
 *                          in \em request.
 * 
 * \retval ta_c_rc_ok Object instance written to \em amount_other.
 * \retval ta_c_rc_invalid_argument \em request is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em request is not of type [transaction_request](\ref transaction_request.h).
 * \retval ta_c_rc_invalid_argument \em amount_other is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_request_get_amount_other(
	ta_object_t request,
	ta_object_t* amount_other );

/**
 * \brief Set cashback amount and currency.
 * 
 * \param[in] request Object instance of type [transaction_request](\ref transaction_request.h).
 * \param[in] amount_other Object instance to set. Object instance can be
 *                         \em ta_object_invalid to clear the value in \em request. If
 *                         object instance is not ta_object_invalid is has to be of
 *                         type \em amount.
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em request.
 * \retval ta_c_rc_invalid_argument \em request is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em request is not of type [transaction_request](\ref transaction_request.h).
 * \retval ta_c_rc_invalid_argument \em amount_other is not \em ta_object_invalid and
 *                                  is not of type [amount](\ref amount.h).
 */
extern ta_e_result_code_t ta_transaction_request_set_amount_other(
	ta_object_t request,
	ta_object_t amount_other );



/**
 * \brief Discount amount and currency.
 * 
 * \param[in] request Object instance of type [transaction_request](\ref transaction_request.h).
 * \param[out] amount_discount Pointer to variable to write object instance to. Object
 *                             instance is of type [amount](\ref amount.h) and is not retained.
 *                             Object instance is \em ta_object_invalid if value is not set
 *                             in \em request.
 * 
 * \retval ta_c_rc_ok Object instance written to \em amount_discount.
 * \retval ta_c_rc_invalid_argument \em request is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em request is not of type [transaction_request](\ref transaction_request.h).
 * \retval ta_c_rc_invalid_argument \em amount_discount is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_request_get_amount_discount(
	ta_object_t request,
	ta_object_t* amount_discount );

/**
 * \brief Set discount amount and currency.
 * 
 * \param[in] request Object instance of type [transaction_request](\ref transaction_request.h).
 * \param[in] amount_discount Object instance to set. Object instance can be \em ta_object_invalid
 *                            to clear the value in \em request. If object instance is not
 *                            ta_object_invalid is has to be of type [amount_discount](\ref amount_discount.h).
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em request.
 * \retval ta_c_rc_invalid_argument \em request is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em request is not of type [transaction_request](\ref transaction_request.h).
 * \retval ta_c_rc_invalid_argument \em amount_discount is not \em ta_object_invalid and
 *                                  is not of type [amount_discount](\ref amount_discount.h).
 */
extern ta_e_result_code_t ta_transaction_request_set_amount_discount(
	ta_object_t request,
	ta_object_t amount_discount );



/**
 * \brief Loyalty coupon list.
 * 
 * \param[in] request Object instance of type [transaction_request](\ref transaction_request.h).
 * \param[out] loyalty_coupon_list Pointer to variable to write object instance to. Object
 *                                 instance is of type [list](\ref list.h) and is not retained.
 *                                 The list contains elements of type [loyalty_coupon](\ref loyalty_coupon.h).
 * 
 * \retval ta_c_rc_ok Object instance written to \em loyalty_coupon_list.
 * \retval ta_c_rc_invalid_argument \em request is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em request is not of type [transaction_request](\ref transaction_request.h).
 * \retval ta_c_rc_invalid_argument \em loyalty_coupon_list is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_request_get_loyalty_coupon_list(
	ta_object_t request,
	ta_object_t* loyalty_coupon_list );

/**
 * \brief Set loyalty coupon list.
 * 
 * \param[in] request Object instance of type [transaction_request](\ref transaction_request.h).
 * \param[in] loyalty_coupon_list Object instance to set. Object instance has to be of type
 *                                [list](\ref list.h). The list has to contain elements of type
 *                                [loyalty_coupon](\ref loyalty_coupon.h).
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em request.
 * \retval ta_c_rc_invalid_argument \em request is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em request is not of type [transaction_request](\ref transaction_request.h).
 * \retval ta_c_rc_invalid_argument \em loyalty_coupon_list is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em loyalty_coupon_list is not of type [list](\ref list.h).
 * \retval ta_c_rc_invalid_argument Element in \em loyalty_coupon_list is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument Element in \em loyalty_coupon_list is not of type
 *                                  [loyalty_coupon](\ref loyalty_coupon.h).
 */
extern ta_e_result_code_t ta_transaction_request_set_loyalty_coupon_list(
	ta_object_t request,
	ta_object_t loyalty_coupon_list );



/**
 * \brief Retain card.
 * 
 * \param[in] request Object instance of type [transaction_request](\ref transaction_request.h).
 * \param[out] retain_card Pointer to variable to write object instance to.
 * 
 * \retval ta_c_rc_ok Object instance written to \em retain_card.
 * \retval ta_c_rc_invalid_argument \em request is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em request is not of type [transaction_request](\ref transaction_request.h).
 * \retval ta_c_rc_invalid_argument \em retain_card is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_request_get_retain_card(
	ta_object_t request,
	ta_e_boolean_t* retain_card );

/**
 * \brief Set retain card.
 * 
 * \param[in] request Object instance of type [transaction_request](\ref transaction_request.h).
 * \param[in] retain_card Value to set.
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em request.
 * \retval ta_c_rc_invalid_argument \em request is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em request is not of type [transaction_request](\ref transaction_request.h).
 */
extern ta_e_result_code_t ta_transaction_request_set_retain_card(
	ta_object_t request,
	ta_e_boolean_t retain_card );


#ifdef __cplusplus
}
#endif

#endif
