/**
 * \file
 * \brief Transaction response.
 * \details Object type \em transaction_response.
 */

#ifndef TA_TRANSACTION_RESPONSE_H
#define TA_TRANSACTION_RESPONSE_H

#include "common/object.h"
#include "common/boolean.h"
#include "constants/transaction_type.h"


#ifdef __cplusplus
extern "C" {
#endif


/**
 * \brief Transaction type.
 * 
 * \param[in] response Object instance of type [transaction_response](\ref transaction_response.h).
 * \param[out] type Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Value written to \em type.
 * \retval ta_c_rc_invalid_argument \em response is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em response is not of type [transaction_response](\ref transaction_response.h).
 * \retval ta_c_rc_invalid_argument \em type is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_response_get_type(
	ta_object_t response,
	ta_e_transaction_type_t* type );

/**
 * \brief Amount.
 * 
 * \param[in] response Object instance of type [transaction_response](\ref transaction_response.h).
 * \param[out] amount Pointer to variable to write object instance to. Object
 *                    instance is of type [amount](\ref amount.h) and is not retained. Object
 *                    instance is \em ta_object_invalid if value is not set
 *                    in \em response.
 * 
 * \retval ta_c_rc_ok Object instance written to \em amount.
 * \retval ta_c_rc_invalid_argument \em response is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em response is not of type [transaction_response](\ref transaction_response.h).
 * \retval ta_c_rc_invalid_argument \em amount is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_response_get_amount(
	ta_object_t response,
	ta_object_t* amount );

/**
 * \brief Other amount in the transaction.
 * 
 * \param[in] response Object instance of type [transaction_response](\ref transaction_response.h).
 * \param[out] amount_other Pointer to variable to write object instance to. Object
 *                        instance is of type [amount](\ref amount.h) and is not retained. Object
 *                        instance is \em ta_object_invalid if value is not set
 *                        in \em response.
 * 
 * \retval ta_c_rc_ok Object instance written to \em amount_other.
 * \retval ta_c_rc_invalid_argument \em response is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em response is not of type [transaction_response](\ref transaction_response.h).
 * \retval ta_c_rc_invalid_argument \em amount_other is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_response_get_amount_other(
	ta_object_t response,
	ta_object_t* amount_other );

/**
 * \brief Due amount in the transaction.
 * 
 * \param[in] response Object instance of type [transaction_response](\ref transaction_response.h).
 * \param[out] amount_due Pointer to variable to write object instance to. Object
 *                        instance is of type [amount](\ref amount.h) and is not retained. Object
 *                        instance is \em ta_object_invalid if value is not set
 *                        in \em response.
 * 
 * \retval ta_c_rc_ok Object instance written to \em amount_due.
 * \retval ta_c_rc_invalid_argument \em response is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em response is not of type [transaction_response](\ref transaction_response.h).
 * \retval ta_c_rc_invalid_argument \em amount_due is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_response_get_amount_due(
	ta_object_t response,
	ta_object_t* amount_due );

/**
 * \brief Tip amount in the transaction.
 * 
 * \param[in] response Object instance of type [transaction_response](\ref transaction_response.h).
 * \param[out] amount_tip Pointer to variable to write object instance to. Object
 *                        instance is of type [amount](\ref amount.h) and is not retained. Object
 *                        instance is \em ta_object_invalid if value is not set
 *                        in \em response.
 * 
 * \retval ta_c_rc_ok Object instance written to \em amount_tip.
 * \retval ta_c_rc_invalid_argument \em response is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em response is not of type [transaction_response](\ref transaction_response.h).
 * \retval ta_c_rc_invalid_argument \em amount_tip is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_response_get_amount_tip(
	ta_object_t response,
	ta_object_t* amount_tip );

/**
 * \brief DCC amount authorized by the transaction if present.
 * 
 * \param[in] response Object instance of type [transaction_response](\ref transaction_response.h).
 * \param[out] amount_dcc Pointer to variable to write object instance to. Object
 *                        instance is of type [amount_dcc](\ref amount_dcc.h) and is not retained. Object
 *                        instance is \em ta_object_invalid if value is not set
 *                        in \em response.
 * 
 * \retval ta_c_rc_ok Object instance written to \em amount_dcc.
 * \retval ta_c_rc_invalid_argument \em response is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em response is not of type [transaction_response](\ref transaction_response.h).
 * \retval ta_c_rc_invalid_argument \em amount_dcc is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_response_get_amount_dcc(
	ta_object_t response,
	ta_object_t* amount_dcc );

/**
 * \brief Saldo amount if present.
 * 
 * \param[in] response Object instance of type [transaction_response](\ref transaction_response.h).
 * \param[out] amount_saldo Pointer to variable to write object instance to. Object
 *                          instance is of type [amount](\ref amount.h) and is not retained. Object
 *                          instance is \em ta_object_invalid if value is not set
 *                          in \em response.
 * 
 * \retval ta_c_rc_ok Object instance written to \em amount_saldo.
 * \retval ta_c_rc_invalid_argument \em response is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em response is not of type [transaction_response](\ref transaction_response.h).
 * \retval ta_c_rc_invalid_argument \em amount_saldo is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_response_get_amount_saldo(
	ta_object_t response,
	ta_object_t* amount_saldo );

/**
 * \brief Information about completed transaction.
 * 
 * \param[in] response Object instance of type [transaction_response](\ref transaction_response.h).
 * \param[out] transaction_information Pointer to variable to write object instance to. Object
 *                                     instance is of type [transaction_information](\ref transaction_information.h) and is
 *                                     not retained. Object instance is \em ta_object_invalid
 *                                     if value is not set in \em response.
 * 
 * \retval ta_c_rc_ok Object instance written to \em transaction_information.
 * \retval ta_c_rc_invalid_argument \em response is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em response is not of type [transaction_response](\ref transaction_response.h).
 * \retval ta_c_rc_invalid_argument \em transaction_information is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_response_get_transaction_information(
	ta_object_t response,
	ta_object_t* transaction_information );

/**
 * \brief Disclaimer sent by host.
 * 
 * \param[in] response Object instance of type [transaction_response](\ref transaction_response.h).
 * \param[out] dcc_disclaimer Pointer to variable to write object instance to. Object
 *                            instance is of type [string](\ref string.h) and is not retained. Object
 *                            instance is \em ta_object_invalid if value is not set
 *                            in \em response.
 * 
 * \retval ta_c_rc_ok Object instance written to \em dcc_disclaimer.
 * \retval ta_c_rc_invalid_argument \em response is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em response is not of type [transaction_response](\ref transaction_response.h).
 * \retval ta_c_rc_invalid_argument \em dcc_disclaimer is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_response_get_dcc_disclaimer(
	ta_object_t response,
	ta_object_t* dcc_disclaimer );

/**
 * \brief Information about payment card used by the cardholder if present.
 * 
 * \param[in] response Object instance of type [transaction_response](\ref transaction_response.h).
 * \param[out] card_data Pointer to variable to write object instance to. Object
 *                       instance is of type [card_data](\ref card_data.h) and is not retained. Object
 *                       instance is \em ta_object_invalid if value is not set
 *                       in \em response.
 * 
 * \retval ta_c_rc_ok Object instance written to \em card_data.
 * \retval ta_c_rc_invalid_argument \em response is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em response is not of type [transaction_response](\ref transaction_response.h).
 * \retval ta_c_rc_invalid_argument \em card_data is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_response_get_card_data(
	ta_object_t response,
	ta_object_t* card_data );

/**
 * \brief Print information for merchant and cardholder receipts.
 * 
 * \param[in] response Object instance of type [transaction_response](\ref transaction_response.h).
 * \param[out] print_data Pointer to variable to write object instance to. Object
 *                        instance is of type [print_data](\ref print_data.h) and is not retained. Object
 *                        instance is \em ta_object_invalid if value is not set
 *                        in \em response.
 * 
 * \retval ta_c_rc_ok Object instance written to \em print_data.
 * \retval ta_c_rc_invalid_argument \em response is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em response is not of type [transaction_response](\ref transaction_response.h).
 * \retval ta_c_rc_invalid_argument \em print_data is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_response_get_print_data(
	ta_object_t response,
	ta_object_t* print_data );

/**
 * \brief Additional information list.
 * 
 * \param[in] response Object instance of type [transaction_response](\ref transaction_response.h).
 * \param[out] additional_info Pointer to variable to write object instance to. Object
 *                             instance is of type [map](\ref map.h) and is not retained. The map
 *                             contains keys of type [integer](\ref integer.h) and values of type [string](\ref string.h).
 * 
 * \retval ta_c_rc_ok Object instance written to \em additional_info.
 * \retval ta_c_rc_invalid_argument \em response is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em response is not of type [transaction_response](\ref transaction_response.h).
 * \retval ta_c_rc_invalid_argument \em additional_info is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_response_get_additional_info(
	ta_object_t response,
	ta_object_t* additional_info );

/**
 * \brief Petrol: Basket.
 * 
 * \param[in] response Object instance of type [transaction_response](\ref transaction_response.h).
 * \param[out] basket Pointer to variable to write object instance to. Object
 *                    instance is of type [basket](\ref basket.h) and is not retained. Object
 *                    instance is \em ta_object_invalid if value is not set
 *                    in \em response.
 * 
 * \retval ta_c_rc_ok Object instance written to \em basket.
 * \retval ta_c_rc_invalid_argument \em response is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em response is not of type [transaction_response](\ref transaction_response.h).
 * \retval ta_c_rc_invalid_argument \em basket is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_response_get_basket(
	ta_object_t response,
	ta_object_t* basket );

/**
 * \brief Loyalty cashback amount.
 * 
 * \param[in] response Object instance of type [transaction_response](\ref transaction_response.h).
 * \param[out] amount Pointer to variable to write object instance to. Object instance is of type
 *                    [amount](\ref amount.h) and is not retained. Object instance is
 *                    \em ta_object_invalid if value is not set in \em response.
 * 
 * \retval ta_c_rc_ok Object instance written to \em basket.
 * \retval ta_c_rc_invalid_argument \em response is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em response is not of type [transaction_response](\ref transaction_response.h).
 * \retval ta_c_rc_invalid_argument \em amount is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_response_get_amount_loyalty_cashback(
	ta_object_t response,
	ta_object_t* amount );



/**
 * \brief Action.
 */
typedef enum ta_e_transaction_response_action {
	/**
	 * \brief No action.
	 */
	ta_c_tra_none,
	
	/**
	 * \brief Cardholder signature action.
	 */
	ta_c_tra_cardholder_signature,
	
	/**
	 * \brief Merchant signature action.
	 */
	ta_c_tra_merchant_signature
} ta_e_transaction_response_action_t;


/**
 * \brief Transaction has been using DCC.
 * 
 * \param[in] response Object instance of type [transaction_response](\ref transaction_response.h).
 * \param[out] was_dcc Pointer to variable to write value to. Set to \em ta_c_b_true if
 *                     transaction has been using DCC.
 * 
 * \retval ta_c_rc_ok Value written to \em was_dcc.
 * \retval ta_c_rc_invalid_argument \em response is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em response is not of type [transaction_response](\ref transaction_response.h).
 * \retval ta_c_rc_invalid_argument \em was_dcc is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_response_was_dcc(
	ta_object_t response,
	ta_e_boolean_t* was_dcc );

/**
 * \brief Transaction has been using TIP.
 * 
 * \param[in] response Object instance of type [transaction_response](\ref transaction_response.h).
 * \param[out] was_tip Pointer to variable to write value to. Set to \em ta_c_b_true if
 *                     transaction has been using TIP.
 * 
 * \retval ta_c_rc_ok Value written to \em was_tip.
 * \retval ta_c_rc_invalid_argument \em response is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em response is not of type [transaction_response](\ref transaction_response.h).
 * \retval ta_c_rc_invalid_argument \em was_tip is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_response_was_tip(
	ta_object_t response,
	ta_e_boolean_t* was_tip );

/**
 * \brief Transaction requires an action.
 * 
 * \param[in] response Object instance of type [transaction_response](\ref transaction_response.h).
 * \param[out] needs_action Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Value written to \em needs_action.
 * \retval ta_c_rc_invalid_argument \em response is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em response is not of type [transaction_response](\ref transaction_response.h).
 * \retval ta_c_rc_invalid_argument \em needs_action is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_response_needs_action(
	ta_object_t response,
	ta_e_transaction_response_action_t* needs_action );

/**
 * \brief Transaction has been partially approved.
 * 
 * \param[in] response Object instance of type [transaction_response](\ref transaction_response.h).
 * \param[out] was_partial_approved Pointer to variable to write value to. Set to
 *                                  \em ta_c_b_true if transaction has been partially approved.
 * 
 * \retval ta_c_rc_ok Value written to \em was_partial_approved.
 * \retval ta_c_rc_invalid_argument \em response is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em response is not of type [transaction_response](\ref transaction_response.h).
 * \retval ta_c_rc_invalid_argument \em was_partial_approved is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_response_was_partial_approved(
	ta_object_t response,
	ta_e_boolean_t* was_partial_approved );



/**
 * \brief Card country code if present.
 * 
 * \param[in] response Object instance of type [transaction_response](\ref transaction_response.h).
 * \param[out] country_code Pointer to variable to write object instance to. Object instance
 *                          is of type [integer](\ref integer.h) and is not retained. Object
 *                          instance is \em ta_object_invalid if value is not set in \em response.
 * 
 * \retval ta_c_rc_ok Object instance written to \em country_code.
 * \retval ta_c_rc_invalid_argument \em response is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em response is not of type [transaction_response](\ref transaction_response.h).
 * \retval ta_c_rc_invalid_argument \em country_code is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_response_card_country_type(
	ta_object_t response,
	ta_object_t* country_code );

/**
 * \brief Terminal country code if present.
 * 
 * \param[in] response Object instance of type [transaction_response](\ref transaction_response.h).
 * \param[out] country_code Pointer to variable to write object instance to. Object instance
 *                          is of type [integer](\ref integer.h) and is not retained. Object
 *                          instance is \em ta_object_invalid if value is not set in \em response.
 * 
 * \retval ta_c_rc_ok Object instance written to \em country_code.
 * \retval ta_c_rc_invalid_argument \em response is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em response is not of type [transaction_response](\ref transaction_response.h).
 * \retval ta_c_rc_invalid_argument \em country_code is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_response_terminal_country_type(
	ta_object_t response,
	ta_object_t* country_code );

/**
 * \brief Determines if transaction has been domestic.
 * 
 * \param[in] response Object instance of type [transaction_response](\ref transaction_response.h).
 * \param[out] is_domestic Pointer to variable to write value to. Set to \em ta_c_b_true if
 *                         card country code and terminal country code are both set in
 *                         \em response and are have equal value.
 * 
 * \retval ta_c_rc_ok Value written to \em is_domestic.
 * \retval ta_c_rc_invalid_argument \em response is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em response is not of type [transaction_response](\ref transaction_response.h).
 * \retval ta_c_rc_invalid_argument \em is_domestic is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_response_is_domestic(
	ta_object_t response,
	ta_e_boolean_t* is_domestic );

/**
 * \brief Surcharge amount in the transaction.
 * 
 * \param[in] response Object instance of type [transaction_response](\ref transaction_response.h).
 * \param[out] amount Pointer to variable to write object instance to. Object
 *                    instance is of type [amount](\ref amount.h) and is not retained. Object
 *                    instance is \em ta_object_invalid if value is not set
 *                    in \em response.
 * 
 * \retval ta_c_rc_ok Object instance written to \em amount_due.
 * \retval ta_c_rc_invalid_argument \em response is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em response is not of type [transaction_response](\ref transaction_response.h).
 * \retval ta_c_rc_invalid_argument \em amount is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_response_get_amount_surcharge(
	ta_object_t response,
	ta_object_t* amount );


#ifdef __cplusplus
}
#endif

#endif
