#include "six_header_h.h"

/**
 * \brief Checks if transaction status is idle
 *
 * Checks if transaction is idle. used after transaction to continue only
 * once the response is received and the state changed to idle. state
 * change always comes after response so only waiting for idle is used
 * after transaction successfully returned.
 *
 * \param[in] terminal		Terminal instance
 *
 * \retval ta_c_b_true	Transaction status is idle
 * \retval ta_c_b_false Transaction status is not idle
 */
ta_e_boolean_t check_trx_status_idle(ta_object_t terminal)
{
	ta_object_t terminal_status = ta_object_invalid;
	ta_e_result_code_t rc = ta_terminal_get_terminal_status(terminal, &terminal_status);
	// If the terminal's status isn't "ok" return an error
	if (rc != ta_c_rc_ok) {
		return ta_c_b_undefined;
	}

	ta_e_transaction_status_t ts_trx_status;
	rc = ta_terminal_status_get_transaction_status(terminal_status, &ts_trx_status);
	ta_object_release(terminal_status);
	if (rc != ta_c_rc_ok) {
		return ta_c_b_undefined;
	}

	return ts_trx_status == ta_c_ts_idle ? ta_c_b_true : ta_c_b_false;
}

/**
 * \brief Performs a transaction on the terminal with given amount
 *
 * \param[in]	terminal	Terminal instance
 * \param[in]	transaction	Transaction type as enum of type ta_e_transaction
 * \param[in]	amount		Transaction-amount, as amount-object
 */
void perform_transaction(ta_object_t terminal, ta_e_transaction_type transaction, ta_object_t amount) {
	ta_e_result_code_t rc;
	ta_object_t trxresp = ta_object_invalid;

	// send transaction to terminal
	rc = ta_terminal_transaction(terminal, transaction, amount, &trxresp);

	// wait for terminal to get back to the idle state. calling logout will fail
	// if the terminal is not ready yet
	if (rc == ta_c_rc_ok) {
		while (check_trx_status_idle(terminal) == ta_c_b_false) {
			Sleep(100);
		}
	}

	// clean up
	ta_object_release_if_valid(trxresp);

	// wait at end for user input
	if (rc == ta_c_rc_ok) {
		printf("Finished successfully...\n");
	}
	else {
		printf("Finished with errors...\n");
	}
}