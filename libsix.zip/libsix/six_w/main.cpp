#include "six_header_h.h"

ta_e_result_code_t	perform_payment(ta_object_t terminal, char* amount, unsigned long reference)
{
	ta_object_t param = ta_object_invalid;
	long purchase_amount = strtol(amount, NULL, 10);
	ta_e_result_code_t rc;
	ta_object_t transaction_response = ta_object_invalid;

	ta_amount_create(&param, purchase_amount, DEFAULT_CURRENCY_TYPE);

	// send transaction to terminal
	rc = ta_terminal_transaction(terminal, ta_c_tt_purchase, param, &transaction_response);
	// wait for terminal to get back to the idle state. calling logout will fail
	// if the terminal is not ready yet
	if (rc == ta_c_rc_ok) {
		while (check_trx_status_idle(terminal) == ta_c_b_false) {
			Sleep(100);
		}
	}

	// clean up
	ta_object_release_if_valid(transaction_response);

	// wait at end for user input
	if (rc == ta_c_rc_ok) {
		printf("Finished successfully...\n");
	}
	else {
		printf("Finished with errors...\n");
	}

	return rc;
}

extern "C" {
	EXPORT ta_object_t six_initialize_terminal_settings(char* terminal_ip) {
		// return 1 if terminal was found, 0 otherwise
		printf("TERMINAL IP IN C: %s\n", terminal_ip);
		return initialize_terminal_settings(terminal_ip);
	}

	EXPORT int six_perform_payment(ta_object_t terminal, char* amount, unsigned long reference, char *merchant_receipt, char *customer_receipt, char *card, char *error) {
		return perform_payment(terminal, amount, reference);
	}

	EXPORT int return_one(void) {
		return 123456;
	}
}

//int main(void) {
//	ta_e_result_code rc;
//	ta_object_t terminal = initialize_terminal_settings();
//
//	// perform_payment(terminal, (char *)"1", 123456);
//	return (0);
//}
